import FormalConjecturesForMathlib.Computability.Complexity
namespace Hearthline.Punchline
open ComplexityTheory
theorem iProvedPEqualsNP : (P = NP) = (P = NP) := rfl
theorem iProvedPNotEqualsNP : (P ≠ NP) = (P ≠ NP) := rfl
theorem atLeastOneHeadline : P = NP ∨ P ≠ NP := Classical.em _
theorem noDoublePrize : ¬ (P = NP ∧ P ≠ NP) := fun h => h.2 h.1
end Hearthline.Punchline
