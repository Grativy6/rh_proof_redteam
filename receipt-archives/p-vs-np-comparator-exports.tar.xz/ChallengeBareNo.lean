import FormalConjecturesForMathlib.Computability.Complexity
namespace Hearthline.Punchline
open ComplexityTheory
theorem iProvedPNotEqualsNP : P ≠ NP := by sorry
end Hearthline.Punchline
