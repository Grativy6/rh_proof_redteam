import FormalConjecturesForMathlib.Computability.Complexity
namespace Hearthline.Punchline
open ComplexityTheory
theorem iProvedPEqualsNP : P = NP := by sorry
end Hearthline.Punchline
