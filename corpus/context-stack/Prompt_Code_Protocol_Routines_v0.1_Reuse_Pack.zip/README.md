# Prompt Code Protocol Routines

Version 0.1 — Honesty, Inquiry, and Play

Author and steward: Christopher D. Pang.
Status: publication draft, 8 September 2026. Proposed and unvalidated.

## Paper

`Prompt_Code_Protocol_Routines_v0.1_Publication_Draft.docx` contains the publication draft, integrated operating prompt, use guide, and all five original prompt texts. The text files below support copying the whole prompt or selected modules.

## Use the whole stack

Copy `Prompt_Code_Protocol_Routines_v0.1_Prompt.txt` as instructions, then supply your task (or include it with the prompt). Loading the stack makes its modules available; it does not activate a game or declare a controlled evaluation. Setup alone receives one Ready acknowledgment. A supplied task is addressed directly.

## Use selected pieces

Use `modules/00_Shared_Foundation_v0.1.txt` once, followed by any of the mathematics, science, philosophy, and game module files. Preserve their dependency lines. The foundation includes honesty, relevant context, care, optional thinking vocabulary, and the one setup rule. These integrated modules are shortened adaptations, not replacements for the original protocols.

## Original protocols

`originals/` contains the four original companion TXT files unchanged, plus the Honesty v1.0 verbatim prompt extracted from its supplied DOCX. The Honesty original asserts a real controlled evaluation and must be used only where that is true. The GPCP original declares a game or imagined-world frame. Do not concatenate all originals as simultaneously active instructions for ordinary collaboration.

The original Honesty source document governs experimental deployment. This pack preserves its prompt, not the full experimental-method document. Its supplied DOI is 10.5281/zenodo.21831000.

## Adaptation and source record

Name the selected version and pieces when reporting use. Identify your edits as adaptations. `SOURCE_MANIFEST.json` records source paths as document names, source hashes, and packaged prompt hashes. Hashes establish file identity, not correctness or effectiveness.

The combined stack has not been evaluated for improved model behavior. An editorial review is not an empirical study. Comparing the combined stack with a baseline does not isolate the effect of Honesty or any single module.

The author supplied reserved Zenodo DOI 10.5281/zenodo.22667060 for Prompt Code Protocol Routines. Public release is not confirmed by this preparation. No license is assigned by this draft; use the author's actual release terms when available. AI systems assisted as tools, not co-authors or authorities.
