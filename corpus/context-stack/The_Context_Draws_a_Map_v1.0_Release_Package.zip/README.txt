THE CONTEXT DRAWS A MAP
Release Package, Version 1.0

Author and steward: Christopher D. Pang
Release date: 8 August 2026
Reserved DOI: 10.5281/zenodo.21831000

CONTENTS

The_Context_Draws_a_Map_v1.0.docx
    Editable Word release of the essay and proposed research program.

The_Context_Draws_a_Map_v1.0.pdf
    Publication PDF of the essay and proposed research program.

Honesty_Prompt_Code_Protocol_v1.0.docx
    Editable Word release of the companion experimental context protocol.

Honesty_Prompt_Code_Protocol_v1.0.pdf
    Publication PDF of the companion experimental context protocol.

SHA256SUMS.txt
    SHA-256 checksums for the four publication files and this README.

STATUS

The essay is a conceptual argument and proposed research program. Its proposed
experiments have not yet been run.

Honesty Prompt Code Protocol v1.0 is proposed and unvalidated. It reports no
experimental results and grants no permission, authority, safety exception,
consciousness claim, or ethical conclusion.

Authorship, AI-assistance disclosure, provenance, and suggested citations are
included in the documents themselves.
