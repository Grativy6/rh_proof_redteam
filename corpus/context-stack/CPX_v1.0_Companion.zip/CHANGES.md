# What changed for v1.0

This release consolidates v0.6 with the completed formal companion. It adds no model calls, new empirical outcomes or changed proof source.

- The abstract, section 3, section 9, conclusion, reviewer entry points and E6 reference now report the completed 33-declaration formal result with its finite rational, finite-sequence and trust boundaries.
- All five controlling source passages remain verbatim. `audit/CLAIM_CROSSWALK.json` binds both manuscript hashes and each passage. Original proof receipts remain bound to v0.6; the crosswalk is not a fresh proof.
- Pilot counts, raw responses, frozen inputs, strict format failures, post-hoc scoring, adverse simulation results and unrun study identities are preserved.
- Tables have captions, mathematics has editable Word equation objects, and the reading edition adds linked contents, internal references and PDF navigation.
- The companion has a portable source lock, an offline verification and retained-response scoring route, a separate formal replay route, explicit licensing and editable manuscript sources.
- Historic review and execution records remain dated. The public edition removes obsolete current drafting labels without claiming independent peer review or whole-paper formal verification.

Review participation, fixtures, methods and limitations remain described in the article. Version 1.0 marks the first public release of this contribution, not closure of its broader research program.
