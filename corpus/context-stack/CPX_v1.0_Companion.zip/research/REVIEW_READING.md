# Focused primary reading for CPX v0.6

11 October 2026. Six primary works, selected from review leads. This is a bounded methodological comparison, not a systematic review or novelty clearance. Earlier reading remains identified in the v0.5 source concordance. No source experiments were rerun. Web-accessed passages below were inspected directly; access does not imply that their full proofs or empirical claims were audited. Private manuscript reviews supplied leads, not authority for the citations.

## L16 Step Back prompting

Huaixiu Steven Zheng, Swaroop Mishra, Xinyun Chen, Heng-Tze Cheng, Ed H. Chi, Quoc V. Le and Denny Zhou. Take a Step Back: Evoking Reasoning via Abstraction in Large Language Models. arXiv:2310.06117v2, 12 March 2024. https://arxiv.org/pdf/2310.06117v2

Read abstract, introduction and section 2, PDF pp. 1–3. The displayed version is v2, not the initially attempted nonexistent v4 HTML route. A derived higher-level question is answered before returning to the original problem. CPX must compare its recipient frame against ordinary abstraction and reconsideration; this pilot does not implement or outperform Step Back. No source results are imported as CPX outcomes.

## L17 Rephrase and Respond

Yihe Deng, Weitong Zhang, Zixiang Chen and Quanquan Gu. Rephrase and Respond: Let Large Language Models Ask Better Questions for Themselves. arXiv:2311.04205v2, 18 April 2024. https://arxiv.org/html/2311.04205v2

Read section 3 and the opening of section 5; title, version and authors verified against the arXiv v2 record. The main intervention asks a model to rephrase and expand a question and answer within a single request; the later variant separates rephrasing and response. CPX's active comparator must match substantive guidance and account for opportunities and costs. This supplies a close prior method, not proof that every rephrasing helps or a method rerun here.

## L18 Questions and decision problems

Robert van Rooy. Questioning to Resolve Decision Problems. Linguistics and Philosophy 26(6), 727–763 (2003), doi:10.1023/B:LING.0000004548.98658.8f. Author-uploaded text: https://www.researchgate.net/publication/225965529_Questioning_to_Resolve_Decision_Problems

Read abstract and section 3.1, author text pp. 5–7. Question relevance is related to the hearer's decision problem. The paper distinguishes a nonnegative improvement over a previously chosen action after learning from the change in value relative to a prior optimum, which may be negative for a particular answer. CPX's average free-optional-information statement is elementary and narrower; it does not license attributing every realized favorable or unfavorable observation to the value of asking.

## L19 Ranking clarification questions

Sudha Rao and Hal Daumé III. Learning to Ask Good Questions: Ranking Clarification Questions using Neural Expected Value of Perfect Information. ACL 2018, 2737–2746. https://aclanthology.org/P18-1255/

Read abstract, introduction and section 2 opening through equation 1, PDF pp. 1–2. Candidate questions are ranked by expected answer usefulness using a learned model; this differs from being handed a diagnostic likelihood matrix. CPX's fixed lookup pilot does not discover a useful question. The paper supplies a concrete predecessor for that future lane.

## R06 Identification

Judea Pearl. An Introduction to Causal Inference. International Journal of Biostatistics 6(2), Article 7 (2010). Corrected UCLA reprint R-354, March 2011. https://ftp.cs.ucla.edu/pub/stat_ser/r354-corrected-reprint.pdf

Renewed reading: section 3.2.1, PDF pp. 11–14, through Definition 2. Identification of a query requires observational agreement to imply query agreement across models satisfying the assumptions. CPX's two binary worlds are an independently authored elementary witness to failure of that implication. They are not a newly discovered causal-identification theorem.

## R03 Transmission and communication

Simon Kirby, Monica Tamariz, Hannah Cornish and Kenny Smith. Compression and communication in the cultural evolution of linguistic structure. Cognition 141, 87–102 (2015). doi:10.1016/j.cognition.2015.03.016. https://www.pure.ed.ac.uk/ws/portalfiles/portal/192983889/KirbyEtalC2015CompressionAndCommunication.pdf

Renewed reading: abstract and sections 1.1–1.2, printed pp. 87–89. Learnability and expressive use impose distinct pressures in the paper's models and experiments. CPX's six-label completion rules stipulate crucial capacities, use an oracle decoder, and do not replicate the compositional models or human experiment. An initial local lookup at the project root found no cache there; the v0.5 reading ledger separately points to its retained private source store. We did not redistribute the source PDF.

## Infrastructure source

Runpod's official Qwen3 32B model page, checked before paid execution, states USD 10 per million tokens and documents the OpenAI-compatible route. https://github.com/runpod/docs/blob/main/public-endpoints/models/qwen3-32b.mdx

The transport probe confirmed a reported charge equal to input plus output tokens at that rate. Each request reserved a conservative byte-count input allowance plus output cap and template margin. Full service cost and usage fields are retained. This operational source is not a seventh research paper.
