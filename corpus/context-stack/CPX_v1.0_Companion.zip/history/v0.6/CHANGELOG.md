# Changes from v0.5 to v0.6

1. Responded to six model reviews through six explicit repair groups, without counting review verdicts as verification.
2. Reduced the main route from 28 sections to 11. Preserved selected conceptual and attribution passages in Appendix A and retained the entire v0.5 Markdown.
3. Printed full binary channel and diagnostic likelihoods. Reconstructed equal-accuracy channels with different information and decision value; all exact decision arithmetic is rational.
4. Separated required fact-ID support coverage from answer correctness and warranted limited answers.
5. Preserved the old B/C instruction confound and introduced a mechanically paired active-comparator recognition variant.
6. Ran 144 frozen calls each on local Qwen3 4B, local Qwen3.5 9B and hosted Qwen3 32B. No matched answer changed under the framing addition.
7. Retained the hosted strict JSON formatting failure alongside an explicitly post-hoc single-fence diagnostic. No scientific prompt or answer was rerun to improve a score.
8. Added paired-chain distributions and descriptive bootstrap summaries, retaining the low-budget loss and 21/40 cost-negative chains.
9. Read six focused primary sources for prior-work comparisons, with reading boundaries recorded.
10. Replayed the inherited finite evidence and new calculations, bound four later Lean targets to the final manuscript, and added Chris's reserved DOI 10.5281/zenodo.23306102.

The observed Runpod charge was USD 0.54451 under the amended total USD 10 ceiling. Publication, Lean execution, training, new reviewer recruitment and deployment did not occur in this revision.

11. Incorporated the late v0.5 companion-review addendum. Preserved and reproduced a Linux replay-comparison failure, repaired newline and log-rounding comparisons without changing original evidence, and added Windows/Linux replay plus 13 guards. Clarified that support-ID lists are contracts, not minimal necessary premises. The addendum does not review the new model outcomes.
