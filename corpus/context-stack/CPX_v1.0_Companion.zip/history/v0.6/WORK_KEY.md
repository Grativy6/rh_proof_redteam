# CPX v0.6 active scope

Chris turned CPXv0.6KEY on 11 October 2026 and explicitly extended it to real model experiments: up to USD 5 on his Runpod account, plus comparison of the local Qwen 4B and 9B models on Speck. His new instruction overrides the proposed key's preparation-only model restriction. The original proposal is retained in audit/PROPOSED_KEY.md.

Build the review-driven v0.6 manuscript and portable companion. Freeze repaired prompts, scoring, models and resource limits before outcome collection. Run the local comparison and use a suitable bounded Runpod experiment if it adds evidence. USD 5 is the total incremental Runpod ceiling, including failed-request reservations and any storage/idle costs; do not spend beyond it. No change to other applications, private-data publication or messages to other chats is needed. No delegation is inferred.

Preserve v0.5 and all historical results. Treat the two local models as different releases/configurations, not a pure size intervention. Keep independent review, numerical replay, live-model findings and formal proof separate. Complete v0.6 before the previously requested bounded Lean work; do not treat the proposal's old NOT_RUN labels as current results after execution.

## Spending amendment

Chris raised the Runpod ceiling from USD 5 to USD 10 total during preflight on 11 October 2026, including retry margin. This supersedes the USD 5 amounts above; it is not an additional USD 10.
