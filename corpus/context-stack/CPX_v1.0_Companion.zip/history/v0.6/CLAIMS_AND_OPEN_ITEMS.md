# CPX v0.6: claims and next questions

Reserved DOI: **10.5281/zenodo.23306102**, supplied by Chris. Local working-paper delivery; no Zenodo or GitHub publication was performed.

| Claim or question | Current evidence | Boundary / next question |
| --- | --- | --- |
| Protected-field return can be checked on a supplied contract | Inherited 93 finite checks, including 64 ordinary-comparator agreements | Does not authenticate arbitrary prose, meaning, consent or sources |
| A capsule preserves an answer iff that answer is constant on its attained fibers | Elementary inherited MIND argument; source-bound Lean card C1 | No efficient decoder, universal compression or new kernel check |
| Matched recipient framing improves responses | 432 frozen recognition calls; all 72 paired selected answers per model coincide | No benefit observed here; cues, ceiling effects, prior-inspected cases and output contract constrain interpretation |
| Local 4B and 9B differ on these cases | Strict 140/144 versus 144/144 | Different model generations/configurations; no causal size effect or deployment reliability claim |
| Hosted 32B answers these cases | Strict 0/144 due to fenced JSON; post-hoc exact outer-fence removal gives 140/144 | Preserve primary score and prompt-contract weakness; no silently repaired evaluation |
| Accuracy alone fixes information or decision value | Explicit counterexamples with equal accuracy and unequal values | Symmetric likelihood premises are now printed; inherited code already had them |
| Targeted teaching repair always helps | Forty paired seeds per contrast; adverse two-observation effect and 21/40 cost losses retained | Earlier completion failure remains preserved; capacities and query choice are stipulated |
| A consequence uniquely determines its cause | Two causal worlds agree observationally and disagree under intervention | Source-bound non-identification witness; not a general discovery theorem |
| Free optional information cannot lower ideal gross value | Constant-policy argument and 125 rational instances | Fixed available actions, joint distribution, utility and zero inspection cost; models need not optimize correctly |
| Language persistence requires whole-system benefit | Finite participation-compatible negative-welfare counterexamples constrain simple versions | General whole-language hypothesis unresolved; no inference to LLM benevolence |
| Inspection package replays across platforms | Retained Windows and Linux receipts, after a reproduced comparison failure | Exact archive bytes; typed replay comparisons with a narrow logarithm tolerance; not all platforms or independent scientific review |

## Live seams

1. Four mathematical cards are prepared in `LEAN_CLAIMS.md`; the later formal lane must bind declarations, assumptions and kernel results to this exact source.
2. A future behavioral study needs fresh independently reviewed cases, an explicit no-fence or structured-output contract, free-response scoring with alternative sufficient supports, and outside judgments. This run's prompts and references stay frozen.
3. Autonomous gap recognition, useful question selection and real retrieval remain untested. Supplying a missing referent, lookup or answer alternative does not demonstrate those abilities.
4. PARALLAX-EXPR-01, PARALLAX-RETURN-01 and PARALLAX-REOPEN-01 keep their historical NOT_RUN or design status. The new recognition study does not silently complete them.

Chris's steward role and Hearthline's named contributions remain explicit in the manuscript. No review verdict, byte hash, numerical check or claim card alone creates publication authority.
