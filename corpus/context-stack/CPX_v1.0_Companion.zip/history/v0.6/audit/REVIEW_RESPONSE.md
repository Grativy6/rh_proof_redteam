# CPX v0.6 response to review

The initial inputs are the six byte-pinned reviews in the proposed key; Chris supplied the companion addendum during final packaging, and `ADDENDUM_INTAKE.json` records that additional source. Their inspection scopes differ. Chat Hearthline reported independent printed-construction checks but initially lacked the companion; Claude used reconstructed configurations; Copilot stopped near the opening of section 8. Grok, Gemini and DeepSeek supplied manuscript critiques. These are external model responses collected by Chris, not independent human peer review. No vote count establishes correctness. No new reviewer was contacted in this run.

## R1 Channel accuracy does not determine a channel

Accepted from Chat Hearthline's technical objection. Manuscript section 6 prints the likelihood matrix, uniform prior and invertible-encoder premises. Section 9 specifies both conditional diagnostic probabilities and all grid values. `evidence/review/channel-counterexamples.json` independently reproduces equal-accuracy information values 0.188722 and 0.311278 bits, and equal-accuracy decision values 3/16 and zero. These calculations preserve her contribution; they do not claim access to her missing checker. The inherited implementation already used a symmetric channel. The defect was an omitted premise in the prose.

## R2 Coverage is not correctness

Accepted. Section 4 labels the inherited 10/12 and 6/12 counts as required fact-ID coverage. M10, M11 and M12 contrast missing evidence, restricted access and an explicit absence of commitment. Frozen pilot references depend on permitted carry; a correctly limited answer can score correct without satisfying the old substantive-support checklist. Abstention fails answerable cases. Choice correctness, format compliance, selected-option violations and explanatory prose have separate records.

## R3 Match the active comparator

Accepted from multiple reviews. Old B requests reconsideration; C adds lookup but drops that instruction. Appendix B retains this confound and the original prompts. The new pair shares the same checklist, evidence, options, lookup and output cap. Two prewritten phrasings probe wording sensitivity. Frames have longer instructions; this is logged, not concealed with padding. Semantic equality of instructions is investigator judgment, and no unseen-mechanism claim follows.

Chris explicitly authorized real local and paid model work after the proposed key. The frozen successor is a declared **recognition variant** with answer options, narrowing the free-response proposal for reproducible scoring. This is Hearthline's implementation choice. It cues distinctions and limits generalization. No second rater is available. The v0.5 study and other expression/return proposals retain their unrun status.

## R4 Make the contribution readable

Accepted. Sections 1–3 state one central question and give a worked report-readiness example before the toys. The whole-language benefit hypothesis is identified as a broader secondary question in section 7. Appendix A preserves adopted vocabulary, correction history and source locators; `audit/SECTION_MAP.json` records exact inherited locations. Naming remains credited to its actual contributors. No universal compression, novel causal theory, orthogonal mathematical axes or deployed memory architecture is claimed.

## R5 Keep the chain as the unit

Accepted. Section 8 separates oracle decoding capacity from retention of original names. Monotone pooled image and bijective capacity are structural; measured endpoint magnitudes are contingent. Paired differences use 40 seeds, not 38,400 independent generations. The adverse two-observation contrast and the 21/40 cost losses remain. All 32 descriptive contrasts, including medians, quartiles, range and paired bootstrap summaries, are in `evidence/review/paired-chains.json`. No multiplicity-adjusted inferential claim is made. Random-extra-observation controls and learned receivers remain future designs.

## R6 State the closest predecessors

Accepted. `research/REVIEW_READING.md` records six focused primary readings. Section 10 directly compares Step Back, Rephrase and Respond, question value, learned clarification ranking, causal identification and transmission. The elementary arguments retain standard provenance. The paper's increment is an experimental accounting contract, with practical superiority still unestablished.

## Review interpretations not adopted wholesale

Different prompt text is intrinsic to an instruction treatment; it is not by itself proof of an invalid experiment. We address unequal substantive guidance and record the remaining wording/token differences. A reconstructed review grid using other parameter values cannot verify or refute a claimed count for the frozen grid. A finite adverse result remains adverse in that sample; we do not label it noise to rescue the narrative. Favorable reviews do not turn the research program into an established mechanism.

## Run-discovered scoring boundary

The hosted model returned fenced JSON. The primary parser requires a JSON object and treats the complete fenced response as malformed. Those scores remain unchanged. A separately labeled post-hoc diagnostic strips only one exact outer Markdown fence and applies the same choice rule. It is reported alongside the strict result, not substituted silently. The prompt did not explicitly forbid Markdown fences, so this also reveals a weakness in our output-contract wording. No outcomes or prompts were rerun to improve the table.

## Deferred claims

Free-form conversational benefit; independent human judgments and new external cases; autonomous missing-question recognition and retrieval; causal effects of parameter count; training; deployment; whole-language welfare; empirical mental-state or identity claims; publication. The four exact Lean cards are prepared after the final wording is frozen. Lean evidence is a distinct later lane and is not implied by this document's numerical checks.

## Companion addendum received during packaging

The addendum concerns the unchanged v0.5 inspection archive, not v0.6 or the new model calls. The complete supplied Markdown was read; its separate reviewer script, proposed patch and raw reports were not supplied here. Its reproduction claims remain attributed to that reviewer rather than represented as our reruns of her code.

- **O1 narrowed:** binary symmetry existed in the implementation and witness contract. This was already our v0.6 diagnosis; the manuscript now makes the likelihoods visible.
- **O2 retained:** the old C/D treatment bundles a relevance cue and a recipient perspective. The new frozen recognition pair already supplies the same substantive checklist in both arms and two prewritten phrasings. Experimental IDs and references are outside model input. Neither the new null result nor this review establishes a CPX-specific mechanism. Helpful labels and answer alternatives remain acknowledged cues.
- **O3 narrowed:** the old baseline does not grade model accuracy or automatically penalize warranted uncertainty. Added the M07 subset example to section 4: a sufficient exception premise need not include the old general rule, even when a declared fact-ID contract lists both. No frozen reference or score was changed after outcomes.
- **P1 accepted:** exact hash comparisons are inappropriate for regenerated semantic evidence across native newline conventions, and log-derived approximations need a narrowly specified comparison policy. Our own Linux run reproduced five failing comparisons in the draft v0.6 checker. `ADDENDUM_REPLAY_BEFORE_LINUX.json` preserves the failure. `pre-addendum/verify_evidence.py` preserves that checker. The repair parses regenerated JSON, validates each prompt manifest against its own bytes, and tolerates at most 1e-12 bits in only the declared information fields. Archive hashes, all other CSV cells and all other JSON numbers remain exact. Original evidence bytes were not normalized or rewritten.
- **Teaching history and unresolved program:** retained, including the defective earlier completion, the adverse two-observation contrast, 21/40 cost losses, lack of autonomous query selection and the unanswered whole-language hypothesis.

The repair is independently implemented from the reported failure, not an uninspected adoption of her unavailable patch. Windows and Linux receipts and 13 mutation/serialization guards accompany it. The addendum has materially improved the delivery without becoming a claim that its reviewer approved v0.6.
