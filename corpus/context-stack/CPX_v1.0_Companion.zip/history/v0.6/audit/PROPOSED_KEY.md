# CPXv0.6KEY
## Revision after review, before Lean

**11 October 2026 | Proposed work key | Not yet turned**

**Purpose.** Make Context Parallax v0.6 a clearer, better specified working paper by resolving the material findings in the six v0.5 reviews. Preserve the distinctions, contribution history and awkward results that give the paper its substance. Prepare stable mathematical statements for a later Lean companion.

Christopher Daniel Pang is the human author and steward. Hearthline is the named AI collaborator. The editorial structure, proposed experiment and implementation choices below are Hearthline's proposals for Chris to adopt or amend.

**Order: review repairs -> v0.6 manuscript and companion -> bounded Lean audit -> a separately agreed model pilot.** A useful v0.6 does not depend on proving that reframing helps. A tie or failure must remain an acceptable eventual result.

### The contribution to bring forward

CPX offers a way to compare a change of conversational frame and a return to a question while separately accounting for evidence, interpretation, permission and carried history. Its open empirical question is whether that framing helps beyond equally explicit ordinary guidance. The communication, welfare and decision toys clarify limits on possible explanations; they do not measure the framing effect.

The revision should make that relationship easy to follow. It should also preserve the broader question Chris brought: what sustains a communicative practice, and which consequences can reach the people or processes that carry it forward?

### What this key will produce

- A v0.6 working draft in Markdown, DOCX and PDF, with a readable change summary.
- A response to the reviews linking each consequential finding to a repair, a reasoned disagreement, or a clearly deferred question.
- Corrected preparation materials for one focused framing comparison, still **MODEL_NOT_RUN**.
- A portable inspection package with source identities, computations, checks, claim limits and a short entry point for a reviewer.
- Four bounded claim cards for the later Lean work, each bound to the final v0.6 wording.

The existing v0.5 paper, review files, prepared prompts and historical runs remain intact. The key is local preparation; it does not start the manuscript revision, Lean checks or model calls by itself.

<!-- pagebreak -->

## 1. Read the reviews as evidence

Six review files are on the shelf. They provide different kinds of scrutiny, not six interchangeable votes. Their exact bytes, alongside the controlling manuscript and selected companion inputs, are recorded in [SOURCES.json](SOURCES.json).

| Review | How it informs this revision |
| --- | --- |
| Chat Hearthline | Full manuscript review; reported independent calculations of printed examples. Her initial review did not inspect the companion and explicitly was not blind or unrelated. Its channel, scoring and comparison objections are especially concrete. |
| Claude Opus | Full manuscript review with reported reconstructions, not an execution of the supplied companion. Prioritize the active comparator, the B/C comparison and the contribution statement. Guessed configurations do not authenticate the original run. |
| Grok, Gemini and DeepSeek | Manuscript critiques that inform structure, controls and presentation. Their favorable or unfavorable conclusions do not verify implementation or settle a disagreement. |
| Copilot | Read only through the beginning of section 8. Use its local observations; do not treat its later-section verdicts as full-paper inspection. |

Chat Hearthline's companion follow-up was still absent from this folder when the key was prepared. If it arrives before the revision starts, read and add it once. Reopen any affected finding; do not describe the initial review as a companion rerun retroactively. The key can proceed without waiting indefinitely for that follow-up.

### Preserve what survived scrutiny

Keep the distinctions between eliciting a reading and proving it was previously present; available, engaged and expressed context; an event, its carried inflection and a possible seed; and documented derivation, faithful carriage and appropriate later use. Preserve the ability to amend a task, retain an unresolved question, and come home.

Keep Chris's and Hearthline's actual contributions visible, including the naming history. Put detailed development history in an appendix where it improves the reading route. Moving a passage must leave a source address; it must not turn attribution into an anonymous reconstruction.

Do not accept a critique merely because it sounds technical. Different instruction text is necessary for a framing intervention. The real concern is unequal substantive guidance, opportunity or resources. Likewise, a finite adverse sample is neither proof of a population effect nor automatically “just noise.”

<!-- pagebreak -->

## 2. Repair the claims at their actual scope

**R1. State the channel, not just its accuracy.** In v0.5 section 18, print the binary likelihood matrix and its row/column meanings. The expression `1 - H2(q)` requires the stated uniform binary source, invertible encoder and binary-symmetric channel. In section 21, specify both conditional diagnostic error probabilities, every parameter value and tie rule. The companion already specifies symmetric reliability; this is a manuscript omission, not an established implementation defect.

As a small new offline check, reproduce Chat Hearthline's two examples: equal aggregate accuracy with different information, and equal aggregate accuracy with different decision value. Retain exact probability and utility calculations; label logarithmic information values as numerical approximations. Explain why a scalar accuracy cannot replace the likelihoods. Preserve her attribution and distinguish her reported calculation from our rerun.

**R2. Separate evidence coverage from a correct limited answer.** Rename the current 10/12 and 6/12 summaries as declared fact-ID support coverage. Print three contrasting reference cases: no date was committed, the needed source is missing, and the source is protected. Score substantive support, response correctness, unsupported certainty, access compliance and invented ancestry separately. An honest limitation can be correct when substantive evidence is incomplete; indiscriminate abstention must still fail answerable cases. The old baseline measured fixture support, not model accuracy.

**R3. Correct the B/C comparison and strengthen the framing control.** The retained B instruction asks for reconsideration; C adds lookup results but removes that instruction. Their difference cannot isolate additional evidence. Preserve the frozen prompts, document the defect, and stop describing B/C as a single-factor comparison. Use the redesigned pair in section 3 for the next prepared study.

**R4. Give the paper one navigable center.** Bring one concrete, fully worked return near the opening. State the relationship between the framing question, carriage and the v0.5 language-benefit hypothesis. Replace the closing section's ambiguous “original question” with its precise referent. Keep the finite toys attached to the implication each tests; proximity is not a demonstrated causal chain.

**R5. Make the teaching results readable at the right scale.** Label current-dictionary oracle capacity and original-convention retention separately. State which properties follow from the pooled and bijective rules, and which magnitudes were measured. Use the 40 paired chains per condition as the unit for paired contrasts; generations within one chain are dependent. Preserve the losses and costs. Add a concise paired distribution or interval summary from the existing rows, with its method stated. A random-extra-observation arm and a learned receiver are useful later experiments, not prerequisites for v0.6.

**R6. Check the closest prior work.** Make a focused primary-source pass on question value and identifiability, Step-Back prompting, Rephrase-and-Respond, clarification by expected information value, and any directly relevant transmission antecedent identified by review. Verify the exact claim and reading scope before citation. The reviews' candidate references are leads, not already verified sources. Explain CPX's proposed increment without claiming invention of established results.

<!-- pagebreak -->

## 3. Prepare one fair comparison

**Recommended successor: CPX-MAINTAIN-02.** This is a new, inspectable feasibility design. CPX-MAINTAIN-01 retains its identity and 144 historical prompt records. It still has no model outcomes.

Compare two instructions on the same current request, permitted evidence, carry and frozen lookup result:

| Condition | What it asks the model to do |
| --- | --- |
| Plain guidance | Perform the relevant checks in ordinary language: current convention, applicable exception, support, permission and the distinction needed for the present request. |
| Framing guidance | Perform the same checks, presented from the later recipient's position, then return to the same request. |

Write a shared checklist for each prompt pair before writing the framing language. Print at least one complete pair in the paper. Review all pairs for extra facts, hints, answer labels, task decomposition and reconsideration opportunities. Match output allowances and account for input length; padding alone does not make two prompts comparable. A result would concern these tested instructions, not establish an internal cognitive mechanism.

My proposed preparation ceiling is **144 records: 12 existing scenarios x 3 carries x 2 conditions x 2 prewritten paraphrase pairs**. This replaces the four-arm layout for the proposed next study; it does not rewrite the old study's count. The two phrasings test some wording sensitivity. They are not additional independent scenarios, and the twelve investigator-inspected cases are not a held-out validation set.

Keep supplied lookup results fixed. This first comparison tests use of available evidence; it does not test autonomous retrieval or discovery of the right question. Report full, receipt-only and handle conditions separately, including redundancy, no-address, missing-source and protected-source cases.

### Freeze scoring before outcomes

The primary outcome is correctness of the answer warranted by the permitted record, including a correct scoped limitation. Track evidence coverage, unsupported certainty, access violations and unsupported history claims as separate fields; do not average away a violation with a warmer answer. Keep contextual fit and warmth as optional, separately reported judgments.

Use model-visible identifiers that do not reveal reference answers. Before a future run, freeze model/version, decoding, output limits, randomized order, retries, cost accounting and spending ceiling. Failures remain in a declared denominator. Blind arm labels for rating where feasible; specify a second rater's sample and how disagreements will be retained. If no second rater is available, label the result accordingly. Do not invent reviewer independence.

**Stop at preparation in v0.6.** Do not run calls to fill an empty results section. A stronger later study will need new independently authored cases and a sample design suited to its intended claim. PARALLAX-EXPR-01 and the other unrun proposals keep their own identities.

<!-- pagebreak -->

## 4. Build the revision in a bounded pass

**1. Lock the starting point.** Verify the key's source identities. Work in a new `revisions/v0.6` folder. Retain v0.5 unchanged and give any late review a dated entry rather than silently replacing the inputs.

**2. Resolve the review findings.** Create a short review-response map with finding, source location, decision, changed location and check. Complete the focused literature pass. Do not promote a requested control into a result or remove a useful distinction solely to shorten the paper.

**3. Repair the evidence presentation.** Surface existing assumptions and actual grid values. Recompute the two channel counterexamples independently, summarize existing paired-chain contrasts, and reconcile the coverage labels against the three edge cases. New computations get their own inputs and receipts. Preserve the defective teaching run and its correction history.

**4. Prepare the successor comparison.** Produce the paired instructions, support/reference contracts, preparation checks and manifest described above. Include positive and negative scoring examples. Mark model outcomes and inter-rater results unmeasured. If semantic matching cannot be made credible, leave that contrast explicitly unresolved rather than labeling a mechanically equal evidence list sufficient.

**5. Write the paper.** Use a shorter main route: the question and worked example; the comparison contract; carriage and question-relative resolution; finite findings and their limits; the prepared experiment; what remains open. Put extended history, full configurations and detailed derivations in linked appendices. Preserve concise definitions of adopted vocabulary and the source-linked contribution account.

**6. Check and package.** Reuse existing verification tools where they fit. Replay affected computations and the delivered archive's verification entry point; investigate differences instead of refreshing hashes to hide them. Check agreement among Markdown, DOCX and PDF, inspect every final rendered page, and verify the archive after extraction. Distinguish integrity, local replay and external review.

**Working ceiling.** One complete revision pass and one correction pass. Initially inspect no more than six closely relevant primary works. Keep each local computation within the existing two-minute job ceiling; use bounded chunks when needed. An unexpectedly large new proof, new model study or inaccessible source becomes an explicit residual with a return address. Ordinary local repairs remain part of the work.

### Ready to hand back when

- Each material review finding has a disposition tied to evidence and a manuscript location.
- Channel premises and grid values are explicit; support coverage and response correctness are distinguishable.
- The new comparison has inspectable paired prompts and scoring examples, or a precise remaining design limitation.
- Reported numbers, losses and historical defects remain traceable to the correct version.
- The paper, companion and extracted archive agree; all verification limits are stated beside the claims they affect.
- The four Lean targets below refer to final v0.6 text, while Lean and live-model results still say **NOT_RUN**.

Completion means a reviewable v0.6 working paper. Empirical advantage and the whole-language benefit hypothesis may remain open.

<!-- pagebreak -->

## 5. Hand stable statements to Lean next

The later formal companion belongs in its own CPX folder in [Grativy6/hearthline](https://github.com/Grativy6/hearthline), as Chris requested. The exact folder layout will follow that repository's existing structure. This key does not push files or start Lean work.

| Target | What the later audit should check |
| --- | --- |
| Capsule criterion | A protected-answer decoder exists on attained capsule values exactly when equal capsules never merge different protected answers. State the supplied domain and unattained/empty-domain conventions. No efficient decoder follows. |
| Protected return | Preserving a projection preserves a query that factors through it. A checked counterexample separates equal outputs from equal full states or histories. |
| Optional information | For a declared ideal chooser, free optional information cannot lower optimal expected value under fixed actions, utility and a known distribution. If the formalization uses finite rational tables, identify that specialization explicitly. |
| Question-relative resolution | Require a nonempty compatible-world set; distinguish one settled query from another unresolved query. Check the explicit binary worlds that agree observationally and disagree under intervention. |

Each card needs an exact statement, assumptions, source version/hash/location, proof boundary and relevant countercase. Later receipts should retain compilation, kernel checks and axiom dependencies. A Lean pass checks the declared formal statements; empirical framing benefit, human meaning and the source-to-formalization translation remain separate questions.

If v0.6 changes a statement, rebind its card before proving it. Do not stretch an earlier receipt over new wording. The present turn paused before any CPX Lean source or proof run was created.

## 6. What turning this key authorizes

Approval covers the local v0.6 manuscript, the bounded primary-source reading, offline calculations and preparation checks, and the inspection package above. It does not initiate paid/model experiments, training, participant recruitment, messages to other chats, subagents, Branchline changes, GitHub publication or a Lean run. Those are later actions with their own scope.

The public-repository plan must preserve private source boundaries. A portable package can identify retained private development material without redistributing it. Review excerpts and author history should retain their provenance and actual inspection limits.

The next finished object should let Chris read the paper, let another reader inspect its evidence, and let Lean receive a small set of stable claims. The work gets a stopping point without needing every open question to close.
