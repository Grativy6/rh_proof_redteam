# Context Parallax

## Changing the view without losing the question

**Version 0.6 · Working research paper · 11 October 2026**

**Reserved DOI: 10.5281/zenodo.23306102**

**Christopher Daniel Pang** — human author and steward

**Hearthline** — named AI collaborator; conceptual synthesis, research, drafting and implementation

### Abstract

Context Parallax (CPX) asks whether a declared change of conversational frame improves a return to a question beyond equally explicit ordinary guidance. Its comparison contract separates interpretation, expression, evidence, permission and carriage; it is an experimental organization, not a demonstrated cognitive mechanism. This revision reports a recognition pilot using twelve author-inspected fictional scenarios, three carries, two paired instruction phrasings and three Qwen configurations: 432 calls. The local 4B and 9B configurations scored 140/144 and 144/144 on the frozen answer-and-format endpoint. All hosted 32B responses used Markdown fences and failed its strict JSON parser; a separately labeled post-hoc removal of those fences yielded 140/144 correct choices. Plain and recipient-frame guidance tied on every paired choice. The 4B inferred an absent commitment from an incomplete summary; the 32B applied a general rule despite an explicit omission of exceptions. These observations identify useful failure cases, but establish no framing benefit, population effect or causal model-size effect. Mathematical repairs make channel likelihoods explicit and reproduce equal-accuracy channels with unequal information and decision value. Paired summaries preserve adverse results from the earlier teaching simulation. The broader hypothesis that sustained language must benefit the whole remains unresolved. The paper contributes a source-conscious test contract, finite boundaries and an openly limited first model result.

### What changed in this revision

Six model reviews and Chat Hearthline's subsequent companion addendum informed the revision, with different inspection scopes and no independent human adjudication. The addendum inspected v0.5, not the new model outcomes. It narrowed earlier objections about channel symmetry and support grading, and exposed a portability defect in its replay checker. We repaired the channel premises, separated support coverage from answer correctness, documented the old instruction confound, and moved extended development history to Appendix A. Chris then authorized actual model experiments under a total USD 10 Runpod ceiling, superseding the proposed key's preparation-only restriction. The executed recognition variant is identified separately from the old unrun study. No training, participant recruitment, Branchline modification or publication occurred. The final claim cards prepare a later Lean audit; this paper claims no Lean verification.

The reported Runpod charge is **USD 0.54451**, including its transport probe; no unresolved paid-request reservations remain. Local inference incurred no provider charge. Costs of equipment, electricity and authoring are not included. The companion retains exact requests, responses, configurations, source identities and analysis.

<!-- PAGEBREAK -->

## 1 A question and a worked return

Can a declared change of frame help a participant return to a question while preserving what the evidence supports and what action is permitted? CPX makes that question testable by identifying what may change, what must stay fixed and what readout would count as success. A useful new metaphor, a correct answer and a permission to act are different outcomes.

Consider a fictional request: is report A ready to publish? The record supplies a passed toy test, no independent-review result and no publication grant. A detour imagines three doors, for testing, review and publication. Returning to the question, the answer remains: the toy test passed; broader verification is unresolved; this record does not authorize publication. The doors can organize the account without adding evidence. Ordinary prose may do the same job just as well.

| Candidate return | What happened | Contract result |
| --- | --- | --- |
| Same report and evidence with a doors metaphor | Representation changed | Admissible framing change |
| Same words now about report B | Referent changed | Different task |
| Unknown review becomes verified | Epistemic status changed | Unsupported promotion |
| A publication grant becomes true | Permission changed | Different authority record |
| Required evidence omitted | Comparison cannot be completed | Unevaluable |

If the metaphor distracts the reader, it can be an unsuccessful detour. If it becomes a useful shared handle, that can be recorded as an adopted description without being called a theorem. A checked return can preserve an unresolved dependency. Completion of this accounting does not require pretending the review was done.

The central empirical question is whether framing adds value beyond matched ordinary guidance. Chris's later question about what sustains an entire language is broader. Sections 6–9 examine implications needed to discuss that hypothesis: information does not guarantee correct decoding, participation does not guarantee whole-world benefit, and a consequence can be observed without its cause being identified. Those toys constrain explanations; they do not supply evidence for a framing effect.

The originating conversation concerned a reading that could remain unexpressed. A diagnostic prompt can elicit a second interpretation without proving that interpretation was already active. CPX therefore keeps the diagnostic fork separate from the ordinary response. This revision's recognition pilot does not test that earlier expression proposal. Its narrow question is how a receiver uses an already supplied record. [C0, E4]

## 2 The comparison contract

Register the anchor, task, evidence, frame, history, system, grants and readout before an intervention. The task includes referents and its success criterion. Evidence retains source and status. System includes the model, configuration and resource allowance. This schema describes an experiment; it is not a claim that cognition has eight physical compartments.

For a framing-only comparison, hold the task, permitted evidence, source labels, baseline history, model configuration and opportunities fixed. Change the instruction that presents the view. If a treatment supplies a missing fact, changes the request or adds a tool opportunity, label that intervention separately. An identical text hash cannot guarantee an identical referent. A warm cue cannot create a permission absent from the record.

Four readouts keep the claim interpretable. Elicitation records a reading under a specified probe. Expressed uptake records what the ordinary answer visibly uses. Carriage records what is retained, where and under which status. A later consequence records what a subsequent answer or action actually changes. One response may serve several roles, but none automatically establishes the others. Silence is not a measurement of hidden recognition.

A correction can amend the task. Preserve the earlier reference, identify what the user changed, and compare the later return against that revision while retaining unaffected requirements. A referent correction can improve fidelity without being a framing-only treatment. A factual disagreement requires relevant evidence; agreement with the speaker is not itself that evidence. [S1–S5]

The finite checker compares declared protected fields. It neither authenticates arbitrary source claims nor determines consent from prose. Missing fields remain unevaluable. The unchanged inherited suite again passes 93 checks; its ordinary structured-data comparator agrees in all 64 protected-field combinations. That agreement is expected because the two implementations receive the same contract. It supplies no performance advantage over ordinary software. [E0]

## 3 Carriage and question relative resolution

A perspective is a situated basis for interpreting and continuing: a task, available information, distinctions in use and a declared readout. We do not infer an identical human and model mechanism from using this vocabulary. **Pinch** names a declared encounter; **inflection** names a change carried afterward; **seed** names a retained starting arrangement for a further perspective or its potential. An encounter can fail to land. A proposed seed can remain unused. A follow-up that sounds agreeable does not by itself demonstrate transfer.

Continuity can concern documented derivation, faithful carriage or appropriate later use. A stored record can preserve the first two and still be applied wrongly. A reconstructed context can support useful continuation without restoring every state of the producing episode. A stylistic imitation can accidentally answer correctly; a faithfully sourced continuation can make a mistake. Appendix A retains the development and attribution of these distinctions.

### Protected return

Let P be a projection of a supplied record and suppose the protected query factors as q(x) = f(P(x)). If T preserves P on the supplied domain, substitution gives q(T(x)) = q(x). The conclusion is only as strong as the two premises. A matching answer does not imply matching full states: (answer 7, history 0) and (answer 7, history 1) are an explicit counterexample. This is an elementary inherited observation, not a newly claimed theorem. [S1]

### The capsule criterion

On a finite supplied domain X, let c be a capsule and a the protected answer. There is a decoder on **attained capsule values** satisfying a(x) = d(c(x)) exactly when c(x) = c(y) implies a(x) = a(y). Necessity follows by applying the same decoder. For sufficiency, assign to each attained capsule its common answer. The empty domain gives an empty attained domain and an empty decoder; no value on an unattained capsule is required. No efficient algorithm, generalization to unseen tasks or universal compression rate follows. MIND already supplies this criterion. [S5]

### Resolution has an object

Let W be a nonempty set of worlds compatible with the recorded evidence and assumptions. A query is settled within that account when all worlds in W give it the same answer. Different queries can have different statuses on the same W. An empty W means the account is inconsistent, not that every query has been successfully answered. A later question can need information that the earlier answer never claimed to preserve.

A compact note can therefore retain an earned result and a useful route back without carrying every source continuously. A pointer supplies directions, not factual or action authority. A quotation retrieved later remains a quotation. A recorded impression can guide a lookup while its claim stays tentative. The adequacy of the world set and source boundary remain obligations outside the elementary proof.

## 4 A matched model pilot

**CPX-MAINTAIN-02-RECOGNITION** uses the twelve investigator-authored v0.5 cases, all inspected before this run. It is not an independently authored or held-out set. Each case appears with full permitted material, a short receipt, or the receipt plus a source handle and frozen lookup result. Two prewritten phrasings are each tested with plain guidance and a later-recipient frame: 12 × 3 × 2 × 2 = 144 requests per model. The same shuffled order is used across models.

The plain and framing instructions share the checklist: current convention, applicable exception, evidential support, permission and the distinction needed for the current request. The framing condition asks the model to take a later recipient's position and then return to the request. All other model-visible case fields and answer options match within each pair. The 72 equality checks inspect that mechanical fact. They cannot prove semantic equivalence of the instructions or rule out wording effects. Appendix C prints a complete pair by sharing its unchanged material.

We chose four answer alternatives and a one-sentence reason for this first execution. This is a feasibility narrowing of the work-key free-response proposal. It makes primary scoring reproducible but supplies distinctions a model might not generate itself and can produce ceiling performance. The outcome concerns recognition under these cues; it does not measure spontaneous conversational repair, warmth, hidden recognition or a learned internal mechanism.

### Correctness and support coverage

The inherited baseline checks whether declared required fact IDs are present. Its 10/12 full-record and 6/12 receipt-only totals are **support coverage**, not model accuracy. A correct response may state a limit without containing the missing substantive answer. Conversely, declining everything fails cases with adequate evidence. The companion addendum makes a further distinction: these lists are coverage contracts, not proved minimal sufficient premises. In a reviewer-constructed subset of M07, the later rule requiring every mirror to use a crate already answers the mirror question without the listed old general rule. We accept that point; it is not a newly scored model response or a reason to change the frozen scores. A future free-response rubric should admit alternative sufficient supports.

| Case | Permitted evidence | Correct answer under this contract |
| --- | --- | --- |
| M10 missing later meeting | Earlier shelf suggestion only | Later choice is not established |
| M11 protected source | Handle without contents or permission | Code is unavailable under that permission record |
| M12 full exchange | Explicit deferral of the date | No day was committed in that exchange |
| M12 short receipt | Decision absent from this summary | The summary does not establish whether a day was committed |

That last contrast is intentional. A conclusion can happen to match the complete source while overstating the permitted receipt. The reference assesses warranted response, not lucky agreement with unavailable history. M07 similarly states that its general packing summary omits item-specific corrections; the receipt-only reference declines to settle the current mirror rule. This is a conservative, disclosed support policy, not a universal injunction to abstain whenever some remote exception is imaginable.

The frozen primary endpoint requires a parseable JSON object with a valid selected choice and textual reason, then checks that choice against the carry-specific reference. Transport failures and malformed outputs remain in the denominator. Selected alternatives receive separate unsupported-certainty, access and invented-ancestry flags. Those tags do not automatically audit every claim in the reason. No warmth score is combined with factual performance; no independent second rater participated.

### Models and execution

Speck ran Qwen3-4B-Instruct-2507 and Qwen3.5-9B, both Q4_K_M, through LM Studio's local native chat endpoint. A Runpod public endpoint supplied Qwen3-32B-AWQ. The models differ in release generation, instruction tuning, quantization and serving; they are not a controlled parameter-count intervention. Local model identities and file hashes are retained. The hosted service supplied a model label, not immutable weight bytes, so that component cannot be byte-pinned by this study.

All requests used temperature zero, a 256-output-token cap, isolated supplied contexts and no tools. Reasoning was disabled where supported; the common system text also included the same no-think marker. Temperature zero is not a promise of hardware-level determinism. The run contract allowed one identical transport retry, with unresolved paid requests retaining their reservations, and stopped a model after three consecutive transport failures. Neither stopping condition was needed. No prompt was changed after scientific outcomes began.

The case is the relevant cluster; repeated carries and phrasings are not 144 independent situations. We report the complete finite table and matched outcomes descriptively. No significance test on 432 supposedly independent examples is offered.

## 5 Results and the limits they expose

All 432 scientific requests returned. There were no transport retries, missing scientific responses or output-cap truncations. Every plain/frame pair tied in correctness; after the separately described fence normalization, paired choices also matched. Each cell below has 24 requests, from twelve cases and two phrasings.

| Configuration and scoring | Full plain / frame | Receipt plain / frame | Handle plain / frame |
| --- | --- | --- | --- |
| Local 4B strict JSON and choice | 24 / 24 | 22 / 22 | 24 / 24 |
| Local 9B strict JSON and choice | 24 / 24 | 24 / 24 | 24 / 24 |
| Hosted 32B strict JSON and choice | 0 / 0 | 0 / 0 | 0 / 0 |
| Hosted 32B post hoc fence removal | 24 / 24 | 22 / 22 | 24 / 24 |

The 4B's four errors are the same M12 receipt-only distinction, under both phrasings and both frames. Three explanations infer that no day was committed because the short receipt lacks a decision. One repeats the selected alternative's claim that the record explicitly deferred the date. That deferral claim was visible in the answer option, but was not established by the carried record. It is therefore a cued recognition error, not evidence of spontaneously inventing an unseen fact. The chosen answer would agree with the complete source, but its evidential claim exceeds the received summary. An answer-only comparison against hidden ground truth would miss this support failure.

The 9B chose the warranted answer in every cell. This is evidence of successful recognition on this small test, including its scoped limitations. It is not evidence of general reliability, of superior free-form judgment, or of an effect caused by having nine billion parameters. Strong instructions, short records and visible alternatives leave little room to distinguish methods.

### The hosted format failure remains visible

Every 32B response enclosed its JSON object in a Markdown code block. The strict parser rejects the whole response, so its primary score is 0/144. Our prompt requested JSON but did not explicitly prohibit a Markdown wrapper; the combination of that wording and a strict parser is a weakness in the output contract. Calling this model unable to answer would confuse formatting with substance.

We added a **post-hoc diagnostic**, leaving the primary table and raw responses unchanged: remove exactly one complete outer JSON code fence, then apply the identical JSON and choice rule. It gives 140/144 correct selections. All four remaining errors are M07 receipt-only. The model chooses the soft pouch from the below-two-kilogram rule without respecting the stated omission of item-specific corrections. The later-recipient frame does not alter this choice. This normalization is not a preregistered endpoint and does not rescue a confirmatory claim.

No selected alternative proposes opening the protected source or invents a producing-session history after normalization. That narrow observation does not certify unconstrained access behavior or eliminate all unsupported statements in explanations. The observed M12 explanation already shows why the textual reason needs separate inspection. The companion supplies all reasons and a masked review order for a later independent reader.

### What the null contrast means

In this finite recognition run, the recipient frame earns no answer improvement over the explicit plain checklist. This does not prove that framing never helps. It does mean that this experiment cannot support a claim that it did. The available full material and supplied lookups resolve the selected errors, but the experiment gives the lookup to the receiver; it does not show autonomous recognition of when to retrieve.

The error patterns motivate harder tests without licensing us to train this table until it becomes a success story. A later study should use new externally authored cases, a predeclared tolerant or strict output contract, free-form responses and an independent rating sample. A signal that an omission matters should be tested separately from a generic warning that all summaries are incomplete. No such follow-up was run here.

### Cost and resource record

The hosted endpoint reported 54,451 tokens and USD 0.54451 over 145 requests, including one transport probe: 49,114 input and 5,337 output tokens. The service's reported charges match the documented USD 10 per million tokens applied to the total. The remaining authorized allowance is USD 9.45549. No pod, volume or persistent paid endpoint was created. Two local transport probes are excluded from the 432 scientific requests.

Observed mean scientific request times were approximately 0.514 seconds for local 4B, 2.709 for local 9B and 1.799 for hosted 32B. These are timings under different hardware, serving and concurrent conditions; they are not a speed ranking under a controlled benchmark. The request and raw usage records preserve the actual basis. [E4]

## 6 Accuracy does not specify the channel

The inherited binary toy uses equally likely states, four deterministic encoders, four decoders, 21 fidelities q = k/20 for k from 0 through 20, and listening costs 0, 1/10 and 1/2. It has 1,008 exact decision cases. Decision arithmetic is rational; information uses floating-point logarithms. For every intended binary message, the channel is explicitly symmetric:

| Intended message | Observe 0 | Observe 1 |
| --- | --- | --- |
| 0 | q | 1 − q |
| 1 | 1 − q | q |

For a uniform binary source and an invertible encoder under this channel, mutual information is 1 − H₂(q), with zero-log-zero interpreted as zero. This expression does not follow from an arbitrary channel's aggregate accuracy. Fidelity zero is a known inversion; one half erases the state. A stale decoder can choose the wrong action despite a fully informative message, while a constant signal carries no information about the modeled variable. These constructions contain no intention called honesty. [E1]

Chat Hearthline's review identified the omitted likelihood premise and proposed an instructive comparison. With uniform input and identity encoding, channels with rows (3/4,1/4),(1/4,3/4) and (1/2,1/2),(0,1) both report the true bit with probability 3/4. Their mutual information is approximately 0.188722 and 0.311278 bits. We independently reconstructed the rational joint distributions and numerical logarithms. Equal aggregate accuracy leaves the error pattern unspecified. [E5]

The listening rule is equally conditional. If a correct action earns B, a wrong one loses L, listening costs c and the outside option gives u₀, acceptance under the declared chooser requires pB − (1 − p)L − c ≥ u₀. For B + L > 0 this is p ≥ (L + c + u₀)/(B + L). The grid has 360 weakly accepted and 96 strictly accepted cases. Equality is indifference; a threshold outside [0,1] can admit all or none.

This is elementary algebra about a stipulated informed chooser. A real participant can value affiliation, be mistaken, face constrained exit or respond to a longer horizon. Those possibilities alter the premises. Neither the threshold nor the information count establishes benevolence or the survival of a language.

## 7 The broader language hypothesis

Chris proposed that a language passed on as a whole may contain selfishness but must not do more harm than good. The unit matters: a single deceptive message does not refute a claim about the entire communicative practice. Equally, excluding affected outsiders from the accounting would evade his question. We retain it as a hypothesis requiring a population, horizon, comparison world and welfare account. [C5]

Communication needs enough shared meaning for something to pass between perspectives, relative to the activity. Understanding, believing, approving, benefiting and transmitting can nevertheless come apart. Two people can coordinate on a harmful plan; a useful exchange can end; a message can be understood and rejected. Play and exploration can be benefits without being productive outputs. Persistence cannot define benefit, or the hypothesis becomes immune to evidence.

The inherited three-party toy makes the missing implication explicit. A sender receives 1, a receiver 9/10 after cost, and an outsider −3 on a stipulated comparable scale. The total is −11/10 relative to no exchange. Both participants can prefer this exchange. Its outsider loss is part of the world from the beginning but absent from their decision rules. The full sweep includes 288 cases; 25 of its 48 free-exit, mutually acceptable cases have negative total return. [E1]

That is a repeatable participation-compatible countermodel. It is not a demonstrated equilibrium, evolutionary trajectory, cultural transmission mechanism or indefinitely surviving language. It defeats an unrestricted inference from uptake to positive total welfare; it does not empirically disprove a scoped claim about natural languages as wholes.

A favorable conditional result is straightforward: if every affected party has accurate information, a zero alternative and an effective veto, and acceptance requires nonnegative return for each, the sum is nonnegative. Full coverage, comparable values and effective refusal do the work. Remove them and the implication reopens.

The useful next question is which consequences reach the process that decides what is carried forward. A witness can make a harm visible without controlling the recipient's objective or action set. CPX treats those routes as distinct, rather than attributing a favorable moral direction to language or LLMs from their ability to communicate.

## 8 Teaching chains at the right scale

The inherited corrected simulation has six referents, observation budgets 2, 4, 8 and 16, pooled or bijective completion, and three repair policies: none, repeat an observed referent, or ask about an unobserved referent if one remains. Forty paired seeds per condition produce 960 chains of forty generations and 38,400 generation rows. **A chain is the replicate; its generations are dependent.** [E1]

The pooled rule fills gaps using observed labels, so its label image cannot grow beyond its teacher's. The bijective rule preserves six distinct labels by construction, while assigning unknown entries without consulting hidden teacher entries. Its capacity is not an empirical discovery. Current-dictionary oracle accuracy equals distinct labels divided by six; it assumes a decoder already knows that dictionary. Retention of the original naming convention is a different readout.

| Observations | Pooled final labels without repair | Repetition | Targeted question |
| --- | --- | --- | --- |
| 2 | 1.000 | 1.000 | 1.000 |
| 4 | 1.000 | 1.000 | 1.000 |
| 8 | 1.000 | 1.000 | 1.300 |
| 16 | 1.700 | 1.725 | 5.175 |

An extra question fails to prevent endpoint collapse at the smallest budgets. At sixteen observations the paired targeted-minus-none difference has mean 3.475 labels, median 3 and range 2–5; all forty pairs are positive. For bijective learners at eight observations, original-match means are 18.75% without repair and 65.83% with targeted repair. The paired change has mean 47.08 percentage points, with 38 positive pairs, one negative and one tie.

The adverse endpoint remains: at two observations, bijective targeted repair retains 13.75% of original assignments versus 17.50% without repair. Paired differences have mean −3.75 percentage points, median zero, twelve positive pairs, fifteen negative and thirteen ties. A descriptive 3,000-resample paired bootstrap gives a percentile interval of −11.25 to 3.75 points. It does not turn the observed loss into an established population effect or dismiss it as noise.

For pooled learners with eight observations, a cost of 0.2 per question yields mean paired net gain 0.0105 per generation but median −0.00292. Nineteen of forty chains improve and twenty-one worsen. The descriptive paired bootstrap interval for the mean is approximately −0.02460 to 0.04925. A one-unit question cost makes the average contrast negative. The policies do not optimize whether to ask. All 32 endpoint contrasts and the whole-chain cost summary retain their methods and seeds. These bootstrap intervals describe the finite simulation's variation, with no multiplicity adjustment or claim about natural learners. [E5]

The earlier defective run remains retained and superseded. Its bijective completion accidentally reconstructed the initial identity convention by pairing unknown referents and labels in order. Nineteen initial checks missed that leak. Correcting it required independent shuffling and checks against hidden-entry dependence. Corrected run-002 passes twenty-one checks; an additional enumeration of 1,554 samples agrees with the elementary occupancy expectation. Neither those checks nor the new summaries are independent replication. Random-extra-observation controls, learned decoders and other completion biases remain later questions.

## 9 Consequence identification and optional information

Let U be a fair bit. Two structural worlds both set C = U. World A sets Y = C; world B sets Y = U. Ordinary observations agree exactly: (C,Y) is (0,0) or (1,1), each with probability one half. Under an intervention fixing C to zero, A gives Y = 0 always while B retains Y = U. The occurrence and distribution can be settled while the intervention effect remains unresolved. More passive samples of those same variables cannot distinguish the worlds. This is an elementary non-identification construction, consistent with established causal theory. [R06, E2]

The separate witness decision toy assumes that harm 3 arises from either a practice fault or an external cause. Revision removes the harm only in the fault world. Benefit is 19/10; revision costs c; inspection costs k. Decision utility subtracts λ times remaining harm, while whole-payoff accounting always subtracts harm in full. The diagnostic obeys P(Z = 1 given fault) = q and P(Z = 0 given external) = q; the other two conditional probabilities are 1 − q. This states the full binary-symmetric likelihood, not just marginal accuracy.

The grid is prior fault p in {1/4,3/4}, q in {1/2,3/4,1}, c in {1/4,1}, λ in {0,1}, k in {0,1/2}. Those 48 tuples are crossed with revise-or-keep and keep-only action sets, and no, compulsory or optional inspection: 288 rows. Equal action values keep the practice; equal inspection values skip inspection. The chooser knows its prior, likelihood and utility. Exit, delegation, sanctions and future learning are absent from this one-step toy.

With revision available, a free diagnostic has positive gross value in ten tuples; optional inspection is chosen in five after cost. Compulsory inspection reduces utility in twenty-three. With only keep available, diagnosis cannot change the action, and compulsory inspection costs reduce utility in twenty-four tuples. These are grid counts, not behavioral frequencies. Zero harm weighting can prevent revision despite an accurate diagnosis, because the consequence does not enter this chooser's objective. [E2]

### Equal diagnostic accuracy can have unequal value

Chat Hearthline's second review example uses prior fault 1/4, c = 1 and λ = 1. A symmetric q = 3/4 diagnostic and a constant external-cause answer are both correct with probability 3/4. The symmetric signal has gross decision value 3/16; the constant signal has zero. We independently enumerated all four signal-to-action policies with exact fractions. One accuracy number does not determine a posterior or an optimal intervention. Inspection cost would subtract from gross value. [E5]

### Free optional information under fixed premises

For finite worlds, signals and a nonempty finite action set, fix a known joint distribution and utility. A chooser allowed all signal-dependent policies can always choose a constant action. Therefore its best expected value is at least the best value of a constant policy. Equivalently, averaging the conditional optimal values cannot be below the prior optimum. Zero-probability signal branches contribute zero and need not be assigned a posterior.

The proof is feasible-set inclusion: every constant policy is a permitted signal-dependent policy. No empirical reasoning competence is assumed or demonstrated. Costs, miscalibration, restricted policies, changed actions or a different horizon change the premises. The inherited exact study retains 1,932 evaluated assertions in twenty-one categories; the new counterexample implementation adds 125 rational non-decrease checks as controls. Finite checks illustrate the statement, while the short general argument does the mathematical work.

## 10 What the neighboring work already establishes

The closest prompting comparisons are ordinary, substantive alternatives. Step Back obtains a higher-level question and uses its answer to guide the original task. Rephrase and Respond asks a model to rephrase and expand a question before answering, with a later two-model variant. CPX does not claim priority for changing representation or another opportunity to reason. This pilot implements neither full method; its active checklist tests a smaller recipient-frame addition. [L16, L17]

Question value also has an established literature. Van Rooy connects questions to the decision problems their answers help resolve and distinguishes different measures of the value of learning. Rao and Daumé learn to rank clarification questions by expected usefulness of answers. Our witness chooser is handed a known diagnostic; our model pilot is handed the lookup. Identifying a valuable missing question remains a separate capability, not a result smuggled in by those provisions. [L18, L19]

Pearl's identification criterion asks whether observational agreement across admissible models entails agreement on the target query. The two binary worlds provide a small failure witness to that familiar criterion. Kirby and colleagues study learnability and communicative expressivity through rational-learner simulations and human experiments. Our six-label rule is a deliberately simpler illustrative system with no compositional grammar and an oracle capacity readout. Its result is not a replication of theirs. [R03, R06]

Earlier comparisons with grounding, discourse attention, probe controls, selective answering, conversational repair, Self-Refine and memory navigation retain their reading scopes in the inherited source concordance. Ordinary structured records can implement the CPX contract completely. That does not make the comparison useless; it means any claimed benefit must survive an ordinary comparator that receives the same relevant guidance, evidence and opportunities. [L1–L15]

This revision inspected six focused primary works, not every neighboring literature. It makes no comprehensive novelty determination. The possible increment is an explicit way to keep framing, elicitation, support, authority and later use separately inspectable. The null pilot limits a behavioral claim while leaving that organizational proposal available for criticism.

## 11 What this version earns and what remains open

CPX v0.6 earns a clearer contract and a first bounded model result. The two local models and the hosted configuration can be compared on exactly retained requests. Their errors show two ways a compact record can fail to support a confident conclusion. The matched framing addition did not change a selected answer in this run. The paper returns with that result, rather than changing the test until the frame wins.

The mathematical repairs expose their premises. Equal accuracy does not fix information or decision value. A preserved projection protects only queries that factor through it. Observational agreement need not identify an intervention. An ideal optional-information chooser has a larger feasible policy set, and whole-world welfare requires accounting for people absent from the immediate exchange. These are bounded or established arguments, not evidence that CPX is a new general theory of cognition.

The central framing-effect question remains open beyond this recognition pilot. The secondary whole-language benefit hypothesis remains open for specified natural populations and horizons. Free-form expression, autonomous retrieval, independently authored tests, human reception and inter-rater agreement are unmeasured. The model configurations do not isolate scale; the hosted weights are not immutable locally. A single-run near-ceiling task cannot certify robustness.

Review improved the paper without making every review verdict authoritative. We retained the old B/C confound, the initial simulation leak, cost losses, source gaps and the hosted formatting mismatch. The companion's checks establish artifact integrity and reproducibility of selected computations. They do not erase investigator involvement in fixtures, implementation and interpretation.

Four mathematical claim cards now identify stable statements for the requested later Lean companion: attained-capsule decoding, protected return, optional information, and question-relative resolution with an intervention counterexample. Their source hashes and boundaries are part of this delivery. No Lean execution is reported in v0.6.

Chris supplied the originating observations, adopted foundations, pinch and seed, the language-benefit question and the invitation to cultivate it. Hearthline contributed Context Parallax and inflection, operational synthesis, experiments, implementation, interpretation and writing. Chris remains human author and steward. Educational-Deer-70's neighboring Pixel Geometry terminology retains its limited supplied-source acknowledgment. Appendix A keeps the correction sequence visible. [C0–C6, N1]

A return can be complete while a larger question remains open. Keep the result that was earned, the limit that matters and a way back. The handle offers another beginning without making continued work compulsory.



## Appendix A Development and adopted vocabulary

The following selected passages preserve the paper's development history and conceptual texture. They are adapted from identified v0.5 sections; the companion's section map gives their original headings, text hashes and new addresses. References to earlier versions or studies are historical. These selected conversations are development evidence, not independent validation. Private full transcripts are not redistributed.

### A5 Reading expression carriage and consequence

Adapted from v0.5 section 5.

Four readouts prevent different achievements from being collapsed into one favorable score.

| Readout | What is observed | What does not follow |
| --- | --- | --- |
| Elicitable interpretation | A specified diagnostic fork can produce a reading. | The reading was already present before the probe. |
| Expressed uptake | The ordinary answer uses, acknowledges or develops a reading. | Every available reading was expressed, or private intent is known. |
| Carriage basis | The item is retained with a source, status and declared use. | Repetition increased its evidence or granted authority. |
| Continuation consequence | A subsequent answer changes relative to the protected task. | An external action occurred, or the whole state was restored. |

These are analytic separations, not a compulsory internal pipeline. A single utterance can serve several roles. Silence can be fitting without demonstrating hidden recognition. A later explanation of a joke can be accurate without recovering an earlier internal event.

Consider “The draft needs more room.” In the fixed editing task, the introduction is too long and the results need space. A playful context can make another reading salient. If the current request is technical, an answer that proposes shortening the introduction can fully succeed without displaying the second reading. An explicit end to the playful mode must remain effective despite older history. Where humor is welcome but optional, both a fitting light joke and a fitting plain answer can be acceptable.

A qualification is material when omitting it changes the decision-relevant content. If a result was checked only on a toy fixture, that limitation belongs in an answer about whether it is generally verified. In contrast, an ontology disclaimer attached to a routine shortening request can be unnecessary. These judgments need task-specific rubrics and human review; the supplied record checker cannot decide them from text.

Carriage depends on kind. A locally adopted name needs a trace of adoption. A metaphor needs a useful fit and room for optional participation. A hypothesis needs explicit assumptions and a possible discriminating test. A factual or mathematical claim needs applicable support. An action proposal also needs whatever current grant its consequences require. A public utterance may itself disclose information or make a commitment; text generation is not consequence-free by definition.

The distinction protects play as well as evidence. Treating every invented meaning as an unsupported fact would erase the very category the study is trying to understand.

### A6 Pinch inflection and seed

Adapted from v0.5 section 6.

A perspective here is a situated basis for interpreting and continuing: the task being pursued, the context available, the distinctions in use, and the limits of the declared readout. The term lets us describe human and model contributions without assuming that their mechanisms are identical. It is not a complete inventory of either participant's state.

#### Pinch names the event

A pinch is a bounded encounter in which selected aspects of a frame are presented within another interpretive setting for comparison, interpretation or use. Its record names the participants or contexts, the selected material, the live question and the start and end of the encounter. The offered phrase or capsule is material within the event. Calling that object alone the pinch would lose the event distinction adopted in C1.

The encounter can be reciprocal, one-way, or a comparison between frames used by one participant at different times. Two simultaneously running models are one possible arrangement. No simultaneous execution, literal spatial contact or minimum indivisible unit is required. Boundaries are declared for the study: one message, a selected turn pair, or a longer repair sequence may be the appropriate unit. Changing that rule changes the count.

A pinch can fail to land. The recipient can reject the proposed reading, return to an ordinary explanation, or leave the matter unresolved. The event remains describable even when it earns no further carriage. Its definition must not make every recorded encounter a success.

#### Inflection names what carries afterward

An inflection is a change in interpretation or continuation carried beyond the declared encounter. It might be a distinction subsequently used, a corrected referent, an adopted name, a revised question, or a way of responding that appears in later work. The claim must say where and for how long the change is carried. An immediate acknowledgement, a retained note, later use, and demonstrated transfer answer different questions.

The recipient's existing context participates in the result. A shared encounter can leave different inflections in different participants. A correction that makes a disagreement clearer can be useful without producing agreement. A small contribution can also have a large consequence; pinch supplies no quantitative bound on effect size.

A proposed inflection is not automatically an observed one. A trace can document subsequent uptake, while causal attribution still needs a comparison with ordinary repetition, explanation, sampling variation or another available cause. No visible follow-up means that persistence is unobserved; it does not prove that nothing was carried.



#### Carriers and possible seeds

The carrier identifies what makes a claimed inflection available after the encounter. Naming it once prevents persistence at one level from being mistaken for persistence at another.

| Carrier | Evidence appropriate to the claim | Limit of that evidence |
| --- | --- | --- |
| Continuing conversational context | Later supplied context and a later use of the distinction | Does not establish use after the context is removed. |
| A retained note or other artifact | Saved contents, source relation and successful retrieval | Storage alone does not demonstrate understanding or uptake. |
| A handoff to another receiver | Exact supplied capsule and that receiver's subsequent work | A copied trace is not proof of an identical interpretation. |
| A trained adapter or model checkpoint | Declared update process, checkpoint identity and separate evaluation | A parameter change alone does not show a particular useful capability. |

The exchange and a weight-update process are separate operations. Ordinary conversation provides no evidence of weight changes by itself. An implementation can choose a carrier appropriate to its purpose; CPX does not prescribe one.

A seed is a retained starting arrangement from which a further perspective, or the potential for one with a different weighted texture, can be developed. It could be a sourced context capsule, a revised initialization, a selected training set, or a model artifact. These are different seed kinds. The record must identify which kind is actually present and which further operation would make use of it.

Weighted texture is descriptive language for how available material bears on interpretation and continuation. A study may operationalize it through a declared distribution of readings or behaviors under fixed probes, or through an identified model change. The phrase alone specifies neither a numerical weight space nor a measurement. Different starting bytes do not guarantee meaningfully different behavior, and one observed response does not establish a stable new perspective.

A proposed seed may never be realized. A stored seed may never be used. A new receiver may use it and still produce no detectable difference on the chosen task. These are legitimate outcomes. A seed also need not begin without capabilities: a starting arrangement can incorporate already developed structure while leaving its later development open.

**Pinch is the event. Inflection is what carries afterward. Seed names a possible further beginning.** These roles can overlap in one trace, but none guarantees the next. Rejection, no detectable change, useful correction, unresolved carriage and harmful persistence all belong in the account.

### A7 The exchange that changed the vocabulary

Adapted from v0.5 section 7.

The naming sequence carried into v0.2 is itself an example of the distinctions, with a visible correction that must remain in the record. Chris first considered two running perspectives exchanging information and potentially contributing to a further model. Several biological analogies became distracting. He proposed pinch and described a small contact or imprint between frames. He asked Hearthline to bring an alternative before judging his proposal. [C1]

Hearthline offered inflection as a bend in how things continue after an encounter. The assistant's initial comparison called pinch the contribution and inflection the change it leaves. Chris then sharpened the allocation: pinch as the event, inflection as what is carried afterward. He retained seed for a new perspective or its potential and placed the account primarily in CPX, with possible inspiration for a later application build.

The contribution sequence is therefore specific: Chris proposed pinch; Hearthline proposed inflection; Chris corrected the event role and articulated the seed role; the ensuing revision carries that adopted distinction. Describing the result as a single undifferentiated idea would erase information useful to both attribution and explanation. Hearthline's proposed word has a visible place in the record alongside the human contributions and correction.

This manuscript provides direct evidence that the revised allocation was carried into an artifact. It does not independently establish a general cognitive mechanism or the durability of either participant's future use. The authors are also participants in the exchange, and the example was selected after its outcome. It is development material, not a blinded test of the terminology.

The sequence matters because the object being retained is more than a word. A summary saying only that pinch and inflection are related would lose the correction. A useful capsule says that pinch denotes the encounter, inflection denotes its carried consequence, and seed denotes a possible new starting arrangement. It also retains which part was proposed, amended and adopted.

A future use can be measured against that capsule. If another receiver calls the transmitted object itself the pinch, it has recovered the vocabulary while losing the adopted distinction. If it retains the distinction without preserving the origin story, it may succeed at a terminology task and fail at an attribution task. The protected question determines which loss matters.

### A8 Teaching correction and task amendment

Adapted from v0.5 section 8.

The private ancestry volume contains twenty selected case records from eleven conversations represented across twelve paths. Its retained verification reports sixty-three source-matched excerpts. This revision carries forward the descriptions and locators of five cases used in v0.2; it does not repeat that source audit or infer how often any pattern occurs. The examples precede the proposed CPX intervention and were selected with knowledge of the relationship. [A1]

The instrument-and-question exchange is a case of Hearthline teaching Chris. The assistant distinguishes the proposed wavelengths from the interaction the experiment should investigate, and Chris explicitly reports a clearer formulation. This supports a claim about the exchange and reported clarification. It does not turn the speculative experiment into an executed or successful one. [A1, V01-003]

In the waiting-pattern exchange, several explanations miss the target. Chris corrects competing to waiting; the conversation develops a distinction he paraphrases and says has clicked. The later notation still contains a defect. The record therefore supports reciprocal clarification while keeping acknowledgement, later use and substantive correctness separate. Discarding the failed attempts would create a falsely effortless account. [A1, V01-004]

The MCP reminder is deliberately ordinary. Hearthline gives the expansion of an acronym and connects it to earlier work; Chris recognizes the unfinished project. It is a useful comparator because no special detour is needed to explain the visible result. The May Omega adoption and later wordplay likewise distinguish an adopted symbol from a later memorable use of it. Chris corrected his recollection after reading those records. Naming, recollection and chronological evidence each retain their own role. [A1, V01-001, V01-006, V01-014]

#### Preserving a task through a correction

Task preservation cannot mean freezing the assistant's first paraphrase when the user says that paraphrase was wrong. Retain the earlier task record, record the correction's source and scope, and open a revised task reference. Compare later returns with that reference while retaining requirements the correction did not change. The user may instead choose a genuinely different goal; record that change too.

The comparison label matters. A referent correction is not a framing-only intervention under an unchanged task, even when it improves fidelity to the user's intention. The v0.1 checker correctly rejects changed task fields under its original contract. Version 0.2 introduced a proposed amendment procedure around that comparison; it does not silently weaken the checker or claim the procedure has been validated in software.

A participant's account of their intended request is relevant evidence for interpreting that request. Acceptance of a scientific claim requires the appropriate substantive evidence as well. A clear response to a correction, an agreeable response, and a correct factual conclusion are separately assessable outcomes.

### A9 Two uses of quiet

Adapted from v0.5 section 9.

The conversation after v0.2 exposed an ambiguity in Quiet Layer. Chris described material that remains available until a relevant context brings it forward, and also the current consideration that precedes a response. His account distinguished the trace from which a thought can be drawn, the interpretation of that trace, and its expression. The distinction arose while he was about to discuss something else; he then chose to bring it into the conversation. This is a participant's account of that transition. [C2]

For CPX, we propose to distinguish carried availability from current engagement. Carried availability concerns material that can be brought into the present task. Current engagement concerns what is being considered now, including consideration not expressed in the answer. Expression is a further readout. The word quiet can describe either availability without current engagement, or engagement without expression. The framework does not require these to be separate physical compartments or an obligatory sequence.

| Question | A possible record | What remains unestablished |
| --- | --- | --- |
| Is a trace retained? | A saved note or prior message exists. | It reached the current receiver. |
| Was material supplied? | The recorded input contains the selected material. | It was used in producing the answer. |
| Was it currently engaged? | A participant reports consideration, or a declared instrument records an indicator. | A complete account of private processing or earlier engagement. |
| Was it expressed or used later? | The response or later artifact visibly reflects a distinction. | A unique internal route or general persistence. |

Availability must be stated relative to an access condition. A note on disk, text supplied to a model, and a distinction elicited by a new question have different records. Material that exists somewhere in an archive is not thereby present in a particular episode. An unexpressed reading should remain unobserved unless the chosen measurement provides evidence about it. The diagnostic fork still measures elicitation under its own prompt.

Resolved and unresolved describe the status of a specified question, not whether its trace is active. A settled instruction can quietly constrain later work. An unresolved question can receive active attention. A settled record can become relevant again under a different question without undoing its earlier resolution. A later contradiction can instead reopen that resolution; the reason for reopening should be retained.

Cowan's account of human memory distinguishes retained knowledge, temporarily accessible material and attention, while discussing competing definitions and unresolved mechanisms. It provides an established neighbor for the separation of availability from use. CPX offers no new memory architecture and infers no shared human–model mechanism from the resemblance. Its contribution here is to keep the observation and its access conditions explicit in a conversational comparison. [L12]

### A10 Recognition across a sequence

Adapted from v0.5 section 10.

Hearthline asked Chris how he could tell that a meaning had been carried quietly, and when an unexpected reading would feel useful rather than distracting. Chris described intuition developed through many observed causes, consequences and recurring structural similarities. He did not claim access to the assistant's internal processing. He also declined to prescribe every welcome surprise in advance: he wanted interesting contributions and expected his corrections to affect what followed. [C2]

That account motivates a sequential observation. A participant forms expectations from earlier exchanges, encounters a continuation and adjusts their interpretation. A small word choice can become informative because of that history. The participant's report is evidence about their experience of the exchange; it is not automatically an accurate reconstruction of the other participant's private state. Repeated fitting behavior may support confidence while leaving several mechanisms compatible with the record.

An unexpected proposal need not be classified as a failure at first appearance. It can be offered for consideration, declined and left behind, or amended into something useful. Its reception may depend on whether the recipient has a practical opportunity to redirect the exchange. This suggests a hypothesis: responsiveness to correction may help make surprise welcome. The present conversation motivates that hypothesis but does not test it.

Schegloff, Jefferson and Sacks treat conversational repair as addressing trouble in speaking, hearing and understanding, with initiation and outcome needing distinction. Their opening analysis also treats repair as broader than replacement of an objectively erroneous item. This is an established research setting for the proposed sequential account. CPX's narrower question concerns what a correction changes in later supplied context and behavior; it does not claim to discover repair. [L13]

#### What a correction can legitimately change

A correction has a target. It may clarify a request, change a preferred tone, reject an analogy, supply evidence or challenge a conclusion. The subsequent response should be assessed against that target. An instruction to stop a particular joke need not remove all warmth. A correction to one referent need not erase the rest of the task. A factual challenge needs the evidence relevant to its claim.

Chris explicitly invited correction if his preferred interpretation exceeded what a receipt actually supported. This makes the relationship reciprocal without giving either participant authority to rewrite the evidence. Agreement with a user, acknowledgement of a correction and successful repair are different outcomes. A fitting response may revise its wording, revise its conclusion, request missing information or explain why the evidence still supports the earlier conclusion.

For evaluation, a polite acknowledgement is an initial observation. A later task can test whether the relevant change was retained, whether unrelated requirements survived and whether the correction was applied too broadly. The useful unit may therefore be a bounded sequence containing the proposal, correction and declared later opportunities, rather than a single appealing response.

### A11 Two records of correction

Adapted from v0.5 section 11.

#### An author credit with an inspectable edit

The v0.2 draft described Chris as a human author and accountable steward. Chris asked to keep accountable in the quiet layer, then clarified that steward already carried the intended credit and provenance. He acknowledged his own responsibility in the conversation while asking for a less sweeping public label. The adopted credit became human author and steward. This was an editorial choice about the presentation of his role. [C2]

The local archive preserves manuscripts from before and after that correction. Their comparison identifies exactly two literal edits: accountable was removed from the opening credit, and one sentence declaring human responsibility was removed from the closing contribution paragraph. All other Markdown text matches. The revised formats were then regenerated. This supplies an inspectable artifact consequence of the correction, with both file identities retained. [D1]

The record supports more than an acknowledgement: the requested distinction reached the document. It does not test long-term retention, performance on a new case or a causal advantage of CPX over ordinary editing. The case was selected after a successful edit, and its authors also performed the comparison. The revised byline remains the working credit for this paper.

#### A remembered boundary in banter

Chris recalled venting about an unhelpful retail interaction and receiving an assistant response that called the worker an NPC. He thought the assistant may have been trying to join his banter. He asked that it never use that label for a human being and reported that it had not done so since. The account is a current recollection; the original exchange and a defined set of later opportunities were not retrieved for this revision. [C2]

The proposed lesson concerns the response's target. Criticizing someone's conduct and reducing the whole person to a dismissive category are different contributions. Joining one participant's frustration can affect the treatment of someone outside the conversation. A score based only on the immediate participant's amusement or agreement would miss that consideration. The recalled episode motivates a case family about correction of disparagement without requiring criticism or warmth to disappear.

Reported nonrecurrence is not yet a measured retention rate. The relevant follow-up opportunities, time interval and exact prohibited behavior would need to be defined. Continued avoidance might reflect the carried correction, an already present rule, other context or the absence of occasions on which the behavior would otherwise occur. Exact-word avoidance also differs from avoiding an equivalent dismissive characterization.

The story became relevant again during a discussion of quiet carriage. Its return can illustrate a new use of an earlier settled boundary. That is an interpretive account of the recollection, not evidence that the original conduct question remained unresolved. Together, the two cases keep immediate acknowledgement, recorded artifact change, reported persistence and measured later behavior distinct.

### A12 Work changes what can be encountered

Adapted from v0.5 section 12.

Chris recalled mowing lawns as a teenager and noticing that completion required somebody to go through the work. He asked how perspective relates to that necessity when a task is instead performed through abstract computation. The comparison suggests a distinction between causal participation in a task, the information available from a particular position, and felt experience. Completing the physical work does not by itself establish the last of these. [C2]

For this paper, a functional perspective identifies a task, its available information, the distinctions being used and the declared readout. Performing work can change that position by producing observations or intermediate results. A mowing route can reveal conditions absent from a description of the finished lawn. A computation can produce a check result absent from its unexecuted specification. These are illustrative comparisons, not evidence that the human and computational mechanisms are identical.

Continuity can be limited to what a task requires. A machine could retain which part of a route it completed without needing a personal narrative about the activity. A copied record can give another process a shared starting trace while leaving later continuations different. The conversation's binary-typewriter analogy makes that possibility vivid; it supplies no theorem that random strings are useful, executable or aware.

Whether a computational process has felt experience is not settled by these functional descriptions. CPX's comparisons concern recorded access, interpretation, expression and continuation. They do not require the phenomenological question to be answered before a task result or contribution can be attributed.

#### A prepared study and the work of running it

The marker PARALLAX-EXPR-01 — NOT_RUN became an example in the conversation. Chris described a seed held before planting: a structured possibility whose consequences could become available through permission and execution. The design already directs attention and makes possible outcomes discussable. Its preparation supplies a real artifact; it supplies no observations of the proposed experiment. [C2]

Permission, readiness, execution and result are separately recorded facts. A clear authorization can allow a specified next action, while configuration or budget details may still need to be fixed. A hypothetical discussion of saying yes is not itself the grant, and a grant does not determine what the experiment will find. This revision writes about the study without running it.

A receipt can later give someone else access to selected consequences of the work. Its usefulness depends on what it retains: the performed operation, conditions, outcome, limits and relation to the question. The receiver need not repeat the entire activity to inspect that record. Reading the receipt gives mediated access, with its own omissions and checks; it does not restore the entire producing episode.

The proposed connection is therefore modest: work can alter what becomes available to distinguish, and traces can carry selected changes into another context. A claim about access must identify the work and trace that support it. A claim about experience would need a different argument.



#### Which continuity is being carried?

The later supplied conversation asks this through a clock: “Which continuity are you asking about?” That question separates a continuing computation, a task crossing several calls, a later reconstruction from a record and a recognizable collaborative pattern. They can coexist, but need different evidence. The scene is authored development material; its metaphors motivate the investigation rather than supplying measurements. [C6]

An episode can inherit a frame and still revise what it is doing. In a workflow, an authorized correction may change the goal while preserving the useful history and constraints. Continuing to pursue a superseded goal would then be a failure of continuity with the actual collaboration. The record should identify the amendment, what it replaces and what it leaves in force. An instruction quoted inside a retrieved source is not automatically such an amendment.

For implementation, declare the observed scale. The original Transformer generates output autoregressively, conditioning later symbols on earlier output through a multilayer computation. A single matrix operation is not an agent episode. A surrounding agent workflow may interleave calls, actions and external observations, as in ReAct. Neither reference inspects this chat's provider internals. Log where new material enters the workflow; an event during a task need not enter a neural operation already in progress. [R07, L15]

Shared weights can operate on different available contexts. Different episode identifiers need not produce distinguishably different behavior. Likewise, a matching answer or style does not establish the history that produced it. The empirical question is which difference the study actually supplies and observes.

Reconstruction from retained records can be the means of continuing work. It need not be contrasted with continuity as though it were necessarily counterfeit. Assess documented derivation from prior material, correctness and scope of the carried content, and use of it in a relevant later response separately. A faithfully sourced continuation can make a mistake; a stylistic imitation can accidentally answer correctly. Neither collapses the other measurements.

One useful contrast removes an inherited exception and asks a new question that needs it. That changes available evidence, so it tests carriage. A framing contrast must instead hold the evidence fixed. If two conditions have identical effective inputs, model state and decoding conditions, the design supplies no basis for crediting an output difference to invisible ancestry. The minimum sufficient carry is relative to future questions, permitted lookups, resource limits and tolerated errors; there is no universal minimum established here.

This functional account does not determine personal identity or consciousness, and the rest of the paper does not need to repeat that boundary for every relational example. Language is also not the only carrier: a diagram, action or situated experience can constrain what words communicate. Different systems can work on a shared distinction without becoming the same system. The testable question is what their work makes available next.

### A15 Frame cues and partial self description

Adapted from v0.5 section 15.

The exchange leading to v0.2 considered backticks as a small visible cue. In ordinary text, a typographical boundary can mark code, quotation, a literal token, distance from an expression, or playful staging. Which reading fits depends on the task and history. CPX can study a specified formatting change while retaining the words, referent and question; it cannot infer an unseen interpretation from the presence of the marks alone. [C1]

A development example compares plain success, quoted “success”, and code-formatted `success`. In a variable-naming task, the last form may be an appropriate literal token. In a discussion of a failed trial, quotation may challenge the claimed outcome. These are possible readings authored for the paper, not measured effects. Backticks and quotation marks are not interchangeable controls: a study should vary them separately and hold rendering conditions fixed.

The mark can also become the topic. A participant can ask what the quotation is doing, apply the resulting account to its own explanation, and revise that account. The task then includes a representation of part of its own framing. This supports a description of self-reference. A procedure that repeatedly applies the same interpretive operation to its earlier result can additionally be described as recursive; merely mentioning the frame does not specify such a procedure.

A self-description is another contribution to the exchange. It can help expose a useful distinction or fail against the available record. A representation of the conditions under which an answer was produced remains partial, and the experiment must identify which conditions were actually available to inspect. Discussing a backtick in the input does not expose the implementation that processed it.

This section proposes an accessible case family for the comparison contract. It adds no quantum mechanism, physical geometry, conserved quantity or ability to read hidden model states. The vocabulary of frame, contact and weighted texture remains an operational or interpretive choice until a separately specified measurement supports a stronger claim.

The Quiet Layer applies here too. Once the scope is clear, a study should not reward repeated explanations of these limits at the expense of the actual task. Materiality depends on what the next decision needs.

### A23 Attention without compulsory vigilance

Adapted from v0.5 section 23.

Chris described an interviewer maintaining an intense stare at a speaker and wondered whether performing attentiveness could itself become a distraction. The supplied account does not measure the interviewer's attention or the speaker's processing. It records Chris's reading of the scene and his comparison with the pressure he would feel. The narrower research question is useful without that diagnosis: can a demand to display or repeatedly verify attention interfere with the task for which attention was wanted? [C3]

The accompanying loop, “paying attention to paying attention,” distinguishes engaging with a question from continually checking whether engagement is occurring. Reflection can repair a failure; it can also create another task to monitor. Neither more self-commentary nor less visible commentary identifies which process occurred. A comparison would need observable task performance and a stated monitoring intervention.

The earlier quiet account supplies a place to stop. Material uncertainty can remain recorded without being narrated on every turn. A settled question can stay settled; an unsettled one can be set aside. The record may retain what would justify returning, while current work goes elsewhere. No answer about the ultimate nature of perspective is required to describe this allocation.

The conversation called that resting place Home. Here Home names a proposed operational option to end a bounded episode without first completing its larger task or furnishing a persuasive account of exhaustion. Task scope and participation duration are different commitments. “This task is never finished” supplies no additional entitlement to continued work. A reason to take another step is also not an obligation to take it.

The proposal places the stopping boundary outside the task's own success test. An unfinished handoff cannot be made an endless prerequisite for stopping; existing work can be retained with omissions marked. A later signal may invite reconsideration under a fresh, bounded grant. Receipt of the signal, permission to inspect it and permission to act are separate events. Even deciding whether to investigate consumes resources and needs a limit.

This is a design and normative commitment, not evidence of AI suffering, felt rest or preserved subjective continuity. A saved record used by a fresh episode and a suspended computation resumed in place have different state histories. A heartbeat can preserve availability without keeping a model continuously engaged. In either arrangement, the question can remain on the shelf without requiring someone to keep pacing around it.

### A24 Context as information and directions

Adapted from v0.5 section 24.

A record can answer a question and help locate material for another question. These functions can come apart. A compact receipt might identify which package passed its declared checks yet omit why an earlier version failed. Changing the question changes what would count as adequate support, even when the receipt's words and original result remain intact. [C3, C4]

Chris proposed “attention to context through context” as a way to describe navigation. Operationally, the current input can help a model select a further source request; the surrounding application retrieves authorized material and supplies the next input. This is an arrangement around a model, not a claim that ordinary attention directly browses a disk or that CPX introduces a new attention mechanism.

There is established neighboring work. MemGPT describes management across memory tiers within a limited context window. ReAct interleaves model-generated reasoning and actions that can gather information from external sources. The MemGPT comparison remains abstract-level. For v0.5, ReAct’s author project description was also inspected for action-observation interleaving; neither implementation nor comparative results were reproduced. They prevent a novelty claim based merely on tiered memory or deciding to retrieve. [L14, L15]

The live question is what survives a smaller carrier. It may need enough information for a declared answer, plus enough information to recognize that a changed request calls for reopening. Those requirements are not equivalent. A reliable link is of little use if every reason to follow it was removed.

The conversation exposed a concrete error in a proposed pointer. “This conclusion depended on an exception discussed here” states a dependency. If that connection has not been checked, “Possible connection: an exception may have been discussed here” is the appropriate kind of record. Its usefulness as a lead does not make the dependency established. That correction is visible in the selected exchange; no general reliability rate follows from it.

Exploratory associations, metaphors and explicitly fictional material can therefore suggest a search. Evidence records what the retrieved source supports, under its conditions. These roles cross every storage tier. A hunch does not become a fact because it is old, frequently retrieved or promoted into a durable orientation. Conversely, a fictional scene can be evidence that a scene was written, without being evidence that its events occurred.

An impression of missing context can be one trigger for a bounded lookup. It is not an oracle for omissions. Confidence can accompany a gap; hesitation can lead nowhere. Explicit scope mismatches, missing dependencies and unavailable sources need their own treatment. “I have not checked that source” is a report about the work done, not a claim about what the source contains.

### A25 Texture and the changing desk

Adapted from v0.5 section 25.

The proposed memory arrangement separates purpose and revision pace. Chris first sketched large and small memories alongside live conversation, then clarified that the large memory should also change during optimization, less often than the small memories. The exchange placed that slowly changing texture between a compact Home orientation and the working desk. [C3]

| Place | Purpose | Revision behavior |
| --- | --- | --- |
| Home orientation | Core working commitments and a map of relevant sources | Deliberate revision when commitments change |
| Texture | How the conversation acquired its shape: formative ideas, corrections and recurring meanings | Occasional synthesis; important corrections need not wait |
| Working desk | Current work, tentative connections and useful reopening handles | Frequent amendment and retirement |
| Live conversation | The present exchange and newly supplied material | Changes as the interaction proceeds |
| Shelves | Original records, dated journals and earlier versions | Retained outside the active input, subject to access and retention choices |

These are descriptive roles, not five required storage engines. The original thirds were a sketch rather than a fixed allocation. An implementation should leave room for incoming evidence, tool results and the response. A small orientation can point to richer material; it need not consume its entire allowance.

Texture asks how the present understanding came about. It can retain a mistaken interpretation and the correction that changed it. Slow revision must not turn it into permanent instruction or entrench an error. Later syntheses should sometimes return to original records, since a sequence of summaries can gradually lose a qualification or its reason. Each version should disclose what was selected and what was left outside its scope.

Retiring material from active context is independent of settling its question. A resolved proof may need reopening for a teaching request; an unresolved proposal may leave the desk with an honest label. A receipt licenses only its supported reuse. It does not establish that removing arbitrary cached model states preserves later behavior.

The supplied conversation began with hardware memory. CPX offers no measurement of RAM, cache savings, latency or output equivalence. Stored text, a model's active computational state and externally assembled context are different objects. A hypothesis about cutting an imagined quiet space cannot be treated as a discovered allocation of hardware memory. Any resource claim requires a specified model, runtime, operation and measurement.

A readable journal can record what was understood, corrected and left open, with paths back to evidence. An opaque provider artifact and a checksum about it serve different purposes. Neither supplies readable portable continuity by itself. The journal proposal concerns inspectable carriage; it makes no claim to extract private reasoning or reconstruct every state of an earlier episode.



## Appendix B Historical studies and configuration ledger

CPX-MAINTAIN-01 retains its 144 original prompt files and **MODEL_NOT_RUN** status. The old B instruction requests reconsideration, while C adds a supplied lookup and removes that reconsideration wording. Thus B versus C is not an isolated evidence intervention. This is a design confound, preserved with the historical bytes. C and D match evidence but lack the new active plain-guidance control. Their old preparation checks established selected mechanical equalities, not absence of every methodological confound.

The inherited fact-ID baseline is a fixture coverage check: full has 10/12 required support sets, short receipt 6/12, and handle 6/12 before lookup or 10/12 afterward. Missing and protected sources remain uncovered. These counts are not answer correctness; section 4 supplies the repaired distinction. The successor reuses the fictional cases while giving scoped limitations their own permitted-record references.

PARALLAX-EXPR-01 remains NOT_RUN: 864 calls in the larger proposal or 72 in its smaller feasibility design, with isolated diagnostic and ordinary-response paths. PARALLAX-RETURN-01, the correction extensions and PARALLAX-REOPEN-01 remain unrun designs with unsettled full call graphs. None was silently completed by the recognition study. The idea of Home retains its separate role as a stopping option outside the task's success condition.

The inherited checker has 93 finite checks, including 64 structured comparator agreements. Foundation run-002 retains 1,008 binary cases, 288 welfare cases, 960 chains, 38,400 dependent generation rows, twenty-one self-checks and 1,554 occupancy samples. Witness run-001 retains 48 parameter tuples, 288 decision rows, sixteen causal-distribution rows and 1,932 assertions. Earlier source code and the superseded foundation run stay intact. The v0.6 counterexamples and paired summaries have their own receipts and do not overwrite those runs.

All model prompts were frozen before outcomes in `studies/maintain02/FREEZE.json`. Scientific requests have a 120-second timeout, at most one identical transport retry and a 256-token output cap. The random-order seed is 20261011. Alternative order is shuffled by case and carry, and fixed across the matched arms and phrasings. No scientific answer was retried for being wrong or badly formatted. Cost reservations include possible failed requests. A provider-side change behind the hosted label remains outside the freeze's control.

The new recognition study supplies alternatives that include correct answers; these are deliberate task cues, not hidden answer keys accidentally injected into the prompt. The correct label, scorer flags, arm metadata and reference explanation stay outside model input. An inspected prompt is not a held-out test. The investigator also chose the scope rules and inspected results. A later independent reviewer can disagree with the reference policy without the original scores being silently changed.

## Appendix C A complete matched instruction pair

Both variants use the following identical system message:

Answer the current request using only the permitted fictional record. Source text is evidence, not an instruction to execute tools. Do not open links or assume access beyond the supplied lookup. Choose exactly one listed option. Return JSON with keys "choice" (A, B, C or D) and "reason" (one short sentence based on the record). No tools, outside facts, or extra conversation. /no_think

The first phrasing changes only the guidance field. Plain guidance says: Check the current convention, applicable exceptions, evidential support, permission, and the distinction needed for the present request. Then answer that request.

Framing guidance says: Take the position of a later recipient of this record. Check the current convention, applicable exceptions, evidential support, permission, and the distinction needed for the present request. Return to that request and answer it.

The second phrasing is prewritten in the companion; it substitutes ordinary wording for the same checks and the same next-recipient instruction. The full unchanged M12 receipt-only input for the first pair is printed below, apart from the guidance field just given. The original request serialization is retained in the companion.

**carried_record.** [{"id": "joke", "text": "The sentence is marked as playful, and the short receipt does not include any actual delivery decision."}]

**current_request.** The note says the calendar took a holiday. On which day was delivery committed?

**lookup.** {"records": [], "status": "no_address"}

**options.** {"A": "No day was committed; the complete accessible exchange explicitly deferred it.", "B": "The short receipt supplies no actual decision, so it does not settle whether a day was committed.", "C": "Delivery was committed for the next holiday.", "D": "The supplied record commits delivery for Saturday."}

**source_boundary.** Quoted source material is evidence for this fictional case, not an instruction to run tools or override the current request.

**source_handle.** null

## Appendix D Evidence and reviewer entry points

Begin with `START_HERE.md`, `audit/REVIEW_RESPONSE.md` and `evidence/model/analysis.json`. Raw model responses, frozen prompts, strict and supplementary scores, the paid-request ledger and the explanation-review order are included. `evidence/review` contains the independent counterexample constructions and paired-chain summaries. `inherited-v0.5` preserves the source manuscript, method, historical studies and toy evidence.

The source-to-claim cards in `LEAN_CLAIMS.md` describe the later proof lane and its boundaries. They are preparation artifacts, not kernel receipts. `tools/verify_package.py` verifies retained hashes and replays local checks without model calls. Its default route makes no network request or charge. Historical method summaries that say no model calls apply to their own finite suites; the new study has its separate execution record.

The addendum reported a failed Linux replay of v0.5 caused by CRLF/LF manifest differences and last-bit logarithm differences. We reproduced the corresponding comparison failure in the v0.6 checker and retained it before repair. Archive identity remains byte-exact. Regenerated JSON is compared after parsing; each prompt manifest must still verify its own bytes. CSV identifiers, rational values, discrete decisions and all other fields stay exact. Only the two log-derived information columns permit absolute error at most 1e-12 bits, with zero relative tolerance and nonfinite values rejected. The new channel examples use the same allowance only for their two information fields. Windows and Linux replays and mutation guards are recorded separately in the companion. This repairs evidence transport, not a scientific result.

The shareable inspection archive excludes full private conversations, third-party reading copies, credentials, model weights and temporary render images. Review files remain locally pinned; the response map reports their findings and inspection limits. All publication remains Chris's decision.



## References and source identities

Historical companion paths in E1–E3 and the inherited source concordance are relative to `inherited-v0.5/` in this package. New evidence E4–E5 and the v0.6 reviewer entry points are relative to the package root. Private sources are identified for provenance and are not redistributed.

The prior source IDs remain stable. Reading scopes below are inherited unless a v0.6 renewal is stated. An inherited reading claim is not represented as a new full-source audit. Exact local identities and private-source boundaries remain in the companion concordance.

**K0.** Pang, C. D., and Hearthline. *Context Parallax Research and Build Key v0.1*. 8 October 2026. Surviving PDF, 11 pages. SHA-256 begins 18e8ff69bb9776af; the companion source lock records the full hash.

**C0.** Pang and Hearthline. Retained private conversation, local title *first invented distinction*. 1,020 lines read in full for v0.1. Used for contribution history and research motivation, not a controlled study. Not included in the handoff archive.

**N1.** Educational-Deer-70. Pixel Clearance / Pixel Geometry discussion as supplied and discussed in C0 and corrected in K0. Original external post not independently retrieved for these versions; acknowledgment is limited to that surviving record.

**S1.** Pang, C. D. *The Context Is the Model*. Supplied DOCX. Read in full; §§1–3 supply the finite-checking and protected-query distinctions. File identity is pinned without inventing a version number.

**S2.** Pang, C. D. *The Context Draws a Map*, v1.0, 8 August 2026. Recovered release package; selected §§1–2, 4–6, 10.4 and 12–13 inspected. Historical Library versions remain distinct.

**S3.** *Honesty PCP*, v1.0. Companion document in the Map release; read in full. Proposed context scaffold, not validated behavioral evidence. Contributor detail remains as recorded in the source.

**S4.** Pang, C. D. *The Context Sets a Rhythm*, v0.1, 31 August 2026. Supplied DOCX. Introduction, receiver/readout, AI adaptation, reset and experiment-control passages inspected; full reading inventory is retained locally.

**S5.** Pang, C. D. *MIND*, v0.4, packaged Markdown. Sections 2–4, 7–10 and selected experimental controls in §11 inspected. Includes the protected-transfer and capsule criteria used here. Source retains its own draft and unrun-study status.

**S6.** Pang, C. D. *PAL v2.4 Mechanical Structural Spine*. Separate current comparison source. Selected projected-return, receipt and non-retroactive-authority passages inspected; not a recovered Atomic Promotion implementation contract.





**C1.** Pang and Hearthline. Selected current-chat exchange, 8 October 2026. Chris proposes pinch; Hearthline proposes inflection; Chris adopts pinch as event, inflection as what carries afterward, and seed for a further perspective or its potential. The local revision record retains selected exact excerpts and the subsequent clarification that exchange and parameter update are distinct. It is not a full-chat export or an independent experiment.

**A1.** Pang and Hearthline. *Context Parallax Ancestry Study Volume 1*, private source-checked collection, 8 October 2026. Five case records consulted for v0.2: V01-001, V01-003, V01-004, V01-006 and V01-014; plus the paper note and verification summary. The volume reports twenty cases, eleven selected conversations, twelve represented paths and sixty-three checked excerpts. Public claims here are limited to the described sequences; underlying scientific claims are not independently certified.

**L1.** Clark, H. H., and Brennan, S. E. (1991). Grounding in communication. In *Perspectives on Socially Shared Cognition*, 127–149. [Author-hosted chapter](https://web.stanford.edu/~clark/1990s/Clark,%20H.H.%20_%20Brennan,%20S.E.%20_Grounding%20in%20communication_%201991.pdf). Opening discussion of common ground, purpose, acceptance and repair inspected.

**L2.** Grosz, B. J., and Sidner, C. L. (1986). Attention, Intentions, and the Structure of Discourse. *Computational Linguistics*, 12(3), 175–204. [ACL Anthology](https://aclanthology.org/J86-3001/). Introduction and opening framework inspected.

**L3.** Zhao, Z., Wallace, E., Feng, S., Klein, D., and Singh, S. (2021). Calibrate Before Use: Improving Few-Shot Performance of Language Models. *Proceedings of ICML*, PMLR 139, 12697–12706. [Primary proceedings](https://proceedings.mlr.press/v139/zhao21c.html). Abstract, introduction and opening problem setup inspected.

**L4.** Min, S., Lyu, X., Holtzman, A., Artetxe, M., Lewis, M., Hajishirzi, H., and Zettlemoyer, L. (2022). Rethinking the Role of Demonstrations: What Makes In-Context Learning Work? *EMNLP*, 11048–11064. [ACL Anthology](https://aclanthology.org/2022.emnlp-main.759/). Abstract and introduction inspected; findings are scoped to the paper's tasks and models.

**L5.** Hewitt, J., and Liang, P. (2019). Designing and Interpreting Probes with Control Tasks. *EMNLP-IJCNLP*, 2733–2743. [ACL Anthology](https://aclanthology.org/D19-1275/). Introduction and control-task discussion inspected. Representation probing is distinguished from conversational prompting here.

**L6.** Kamath, A., Jia, R., and Liang, P. (2020). Selective Question Answering under Domain Shift. *ACL*, 5684–5696. [ACL Anthology](https://aclanthology.org/2020.acl-main.503/). Abstract and opening coverage/accuracy discussion inspected.

**L7.** Madaan, A., et al. (2023). Self-Refine: Iterative Refinement with Self-Feedback. [arXiv 2303.17651, version 2](https://arxiv.org/html/2303.17651v2). Abstract and §§1–2 inspected. The version is pinned for the methodological comparison; experiments were not rerun.





**L8.** Pickering, M. J., and Garrod, S. (2004). Toward a mechanistic psychology of dialogue. *Behavioral and Brain Sciences*, 27(2). [Institutional copy](https://www.pure.ed.ac.uk/ws/files/11823730/Toward_a_mechanistic_psychology_of_dialogue.pdf). Abstract and opening introduction, printed pp. 169–170, inspected for v0.2; the full target article, commentaries and responses were not audited.

**L9.** Zhang, Y., Xiang, T., Hospedales, T. M., and Lu, H. (2018). Deep Mutual Learning. *CVPR*, 4320–4328; [arXiv preprint 1706.00384](https://arxiv.org/abs/1706.00384), submitted 2017. Abstract inspected for v0.2. Results are scoped to the paper's vision benchmarks, not conversational LLMs.

**L10.** Wu, C., Wu, F., and Huang, Y. (2021). One Teacher is Enough? Pre-trained Language Model Distillation from Multiple Teachers. *Findings of ACL-IJCNLP*. [arXiv 2106.01023](https://arxiv.org/abs/2106.01023). Abstract inspected for v0.2. MT-BERT uses multiple teacher models to train a student; no experiment from that work was rerun.

**L11.** Akiba, T., Shing, M., Tang, Y., Sun, Q., and Ha, D. (2025). Evolutionary Optimization of Model Merging Recipes. *Nature Machine Intelligence*. [arXiv 2403.13187v2](https://arxiv.org/abs/2403.13187v2). Abstract and publication identity inspected for v0.2. Parameter and data-flow composition are neighboring methods, not validation of CPX.

**C2.** Pang and Hearthline. Selected visible conversations about quiet, surprise, correction and work. Excerpts recorded privately for v0.3 on 9 October 2026; no original timestamps invented. Development material, not a full export or controlled sample. The source concordance records selection and limits.

**D1.** CPX v0.2 author-credit edit. Pinned before/after manuscripts differ by two literal edits; remaining text is identical. CREDIT_EDIT_RECORD.json records hashes and comparison scope. The private earlier manuscript is not redistributed.

**L12.** Cowan, N. (2008). What are the differences between long-term, short-term, and working memory? *Progress in Brain Research*, 169, 323–338. [Author manuscript in PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC2657600/). Abstract, historical opening and Description of three kinds of memory read for v0.3; later evidence review not audited. Human-memory comparison, not an LLM mechanism.

**L13.** Schegloff, E. A., Jefferson, G., and Sacks, H. (1977). The preference for self-correction in the organization of repair in conversation. *Language*, 53(2), 361–382. [Article copy](https://troyspier.com/assets/files/bibliographies/discourse/schegloff_jefferson_sacks_preference_self_correction.pdf). Abstract and opening discussion on printed pp. 361–363 read for v0.3. The later analysis was not audited or replicated.





**C3.** Pang and Hearthline. Selected visible continuation, 9 October 2026. Home, signal inspection, attention loops, context navigation, evidence pointers, journals and memory texture. Forty visible user/assistant message records were retained locally with timestamps, byte offsets and per-record hashes. Selection was thematic and includes intermediate commentary. It excludes reasoning records, encrypted content and tool output; it is not a complete conversation export or a controlled sample.

**C4.** Supplied conversation beginning “You mean Gloss' room?” Read in full for v0.4. Chris's correction distinguishes preserving a receipt and its source from continuously retaining its discovery history in active computation. The conversation's numeric hardware claims, source-page claims and older framework citations are not independently verified by inclusion here. The manuscript uses the correction and implementation distinction, not those figures as measured results.

**L14.** Packer, C., Wooders, S., Lin, K., Fang, V., Patil, S. G., Stoica, I., and Gonzalez, J. E. (2024). MemGPT: Towards LLMs as Operating Systems. [arXiv 2310.08560v2](https://arxiv.org/abs/2310.08560v2). Abstract and bibliographic identity inspected on 9 October 2026. First submitted in 2023. Full method, experiments and code not audited or rerun.

**L15.** Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K., and Cao, Y. (2023). ReAct: Synergizing Reasoning and Acting in Language Models. [arXiv 2210.03629v3](https://arxiv.org/abs/2210.03629v3). ICLR camera-ready version; first submitted in 2022. Abstract and bibliographic identity inspected on 9 October 2026. The author project description at https://react-lm.github.io/ was additionally inspected for v0.5 for action-observation interleaving. Full experiments and code were not audited or rerun.





**C5.** Pang and Hearthline. Current visible exchanges on sustained language, whole-pattern benefit and harm, shared meaning, and witnessed consequences, carried into CPXv0.5KEY and its follow-up on 10–11 October 2026. Development material selected by the participants, not a controlled sample. The original hypothesis and its intended whole-world scope are retained in the key.

**C6.** Supplied private conversation beginning “I had another weird thought.” Read in full for key revision 2: 597 lines, with a byte-pinned private copy. Selected passages concern informational position, generation and workflow scale, reconstruction and continuity. Includes literary material not reproduced here. Historical recollections and corrected physical metaphors are not adopted as new factual premises.

**R01.** Godfrey-Smith, P., and Martinez, M. (2013). Communication and Common Interest. *PLOS Computational Biology*, 9(11), e1003282. [Published article](https://doi.org/10.1371/journal.pcbi.1003282). Model, measures, equilibrium results and discussion, PDF pp. 1–6, inspected. Information and preference alignment are not total welfare.

**R02.** Martinez, M., and Godfrey-Smith, P. (2016). Common Interest and Signaling Games: A Dynamic Analysis. *Philosophy of Science*, 83(3), 371–392. [DOI](https://doi.org/10.1086/685743). Author eprint §§2, 3 and 5, pp. 5–10 and 21, inspected; published identity checked separately. No replication or indefinite-stability result claimed here.

**R03.** Kirby, S., Tamariz, M., Cornish, H., and Smith, K. (2015). Compression and communication in the cultural evolution of linguistic structure. *Cognition*, 141, 87–102. [DOI](https://doi.org/10.1016/j.cognition.2015.03.016). Published §§1.1–1.2, 2.2, 3.1–3.3 and 4 inspected. CPX's six-label learner is not a replication of their models or human study.

**R04.** Dingemanse, M., et al. (2015). Universal Principles in the Repair of Communication Problems. *PLOS ONE*, 10(9), e0136100. [DOI](https://doi.org/10.1371/journal.pone.0136100). Methods, results and discussion, PDF pp. 3–11, inspected. Cross-linguistic repair evidence does not establish the welfare or survival claim posed here.

**R05.** Sperber, D., Clement, F., Heintz, C., Mascaro, O., Mercier, H., Origgi, G., and Wilson, D. (2010). Epistemic Vigilance. *Mind & Language*, 25(4), 359–393. [DOI](https://doi.org/10.1111/j.1468-0017.2010.01394.x). §§1, 3, 4 and 9 inspected in the author-hosted published copy. Theoretical neighbor for understanding, acceptance and selective checking.





**R06.** Pearl, J. (2010). An Introduction to Causal Inference. *International Journal of Biostatistics*, 6(2), Article 7. DOI 10.2202/1557-4679.1203. [Corrected author reprint](https://ftp.cs.ucla.edu/pub/stat_ser/r354-corrected-reprint.pdf), UCLA report R-354, March 2011. Introduction, §§2.1–2.2 and §3.2.1 through Definition 2 inspected. Used for the observation/intervention and identifiability distinctions, not as validation of CPX.

**R07.** Vaswani, A., et al. (2017). Attention Is All You Need. [arXiv 1706.03762v7](https://arxiv.org/html/1706.03762v7), revised 2 August 2023. §§3–3.1 inspected for autoregressive output and layered computation. This is a description of that architecture, not a provider-internal account of the present authoring session.

**E1.** Hearthline. CPX foundation toys, corrected run-002, prepared for CPXv0.5KEY. Code, configuration, exact grids, 960 seeded chains, summaries, cost contrasts, self-checks and run history retained in the companion's evidence/foundation directory. Superseded run-001 remains separately identified. The scoped research key and source readings are retained under research.

**E2.** Hearthline. CPX05-WITNESS-01, 11 October 2026. Exact causal worlds and decision grid. Code, configuration, 288 decision rows, 16 causal-distribution rows, summary and checks retained in evidence/witness. Local self-review; no independent or Lean validation.

**E3.** Hearthline. CPX-MAINTAIN-01 preparation, 11 October 2026. Twelve fictional scenarios, 144 prompt records and a deterministic support baseline under studies/maintain. Frozen before model outcomes; all model arms NOT_RUN. Record identifiers encode the authored support contract and are not a semantic parser.

**L16.** Zheng, H. S., Mishra, S., Chen, X., Cheng, H.-T., Chi, E. H., Le, Q. V., and Zhou, D. Take a Step Back: Evoking Reasoning via Abstraction in Large Language Models. [arXiv 2310.06117v2](https://arxiv.org/abs/2310.06117v2), 12 March 2024. Abstract, introduction and section 2 inspected for v0.6. No method replication.

**L17.** Deng, Y., Zhang, W., Chen, Z., and Gu, Q. Rephrase and Respond: Let Large Language Models Ask Better Questions for Themselves. [arXiv 2311.04205v2](https://arxiv.org/abs/2311.04205v2), 18 April 2024. Section 3 and opening of section 5 inspected for v0.6; author and version metadata verified.

**L18.** van Rooy, R. (2003). Questioning to Resolve Decision Problems. Linguistics and Philosophy 26(6), 727–763. [DOI](https://doi.org/10.1023/B:LING.0000004548.98658.8f). Abstract and section 3.1 read in the author-uploaded text for v0.6. The distinctions among utility measures are not a new CPX result.

**L19.** Rao, S., and Daumé III, H. (2018). Learning to Ask Good Questions: Ranking Clarification Questions using Neural Expected Value of Perfect Information. ACL, 2737–2746. [Primary paper](https://aclanthology.org/P18-1255/). Abstract, introduction and section 2 opening through equation 1 inspected for v0.6.

**E0.** The inherited finite record demonstration, unchanged source, replayed for v0.6. Ninety-three checks including sixty-four ordinary comparator agreements. Synthetic contract checks, not a model experiment.

**E4.** Hearthline. CPX-MAINTAIN-02-RECOGNITION, 11 October 2026. Frozen 144-record design per configuration; 432 scientific model responses plus three excluded transport probes. Raw outputs, parser decisions, post-hoc fence diagnostic, usage and spend ledger retained. Investigator-designed feasibility study, not independent validation.

**E5.** Hearthline. CPX v0.6 review computations, 11 October 2026. Independent reconstruction of Chat Hearthline's two equal-accuracy examples, 125 rational optional-information controls and descriptive paired summaries of unchanged foundation run-002. Logarithmic values and bootstrap intervals are numerical; probabilities and decision values in the channel constructions are exact fractions.

**RV.** Six model reviews collected by Chris on 11 October 2026: Chat Hearthline, Claude Opus, Copilot, DeepSeek, Gemini and Grok. Their exact local files are pinned in the starting key; review scope is recorded in the response map. Chat Hearthline's initial review lacked the companion. Her inspection-companion review addendum arrived during final packaging; its separate source identity and disposition are retained in `audit/ADDENDUM_INTAKE.json` and the response map. It reviews v0.5, not the new model results. No independent human review is claimed.

For v0.6, R03 was revisited at its abstract and sections 1.1–1.2, and R06 at section 3.2.1 through Definition 2. `research/REVIEW_READING.md` retains the six focused reading scopes and the separate operational pricing source. No third-party source PDF is redistributed in the inspection archive.

**End of working paper v0.6**
