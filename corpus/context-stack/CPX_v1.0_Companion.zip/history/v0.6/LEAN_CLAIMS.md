# CPX v0.6 claim cards for Lean

**PREPARED_NOT_RUN.** Four mathematical targets after manuscript stabilization. No kernel receipt is implied.

Canonical manuscript: `output/Context_Parallax_v0.6_WORKING_DRAFT.md`

SHA-256: `ecc4d45107d20e7d148efeee26491f8310c897785575511fc32bd290ca8ce5dc`

Reserved DOI: 10.5281/zenodo.23306102

Rebind these cards if the source wording changes. The later audit must retain source-to-formal translation, compiler and kernel results, explicit axiom dependencies and failure history separately. Empirical framing benefit is outside all four cards.

## CPX06-C1 Decoder on attained capsule values

**Source location:** Section 3, The capsule criterion

**Exact source paragraph**

> On a finite supplied domain X, let c be a capsule and a the protected answer. There is a decoder on **attained capsule values** satisfying a(x) = d(c(x)) exactly when c(x) = c(y) implies a(x) = a(y). Necessity follows by applying the same decoder. For sufficiency, assign to each attained capsule its common answer. The empty domain gives an empty attained domain and an empty decoder; no value on an unattained capsule is required. No efficient algorithm, generalization to unseen tasks or universal compression rate follows. MIND already supplies this criterion. [S5]

**Target statement**

Let X be finite, C and A arbitrary types, c : X -> C and a : X -> A. Let I be the subtype of C attained by c, and cI : X -> I its lift. Then (there exists d : I -> A with d(cI(x)) = a(x) for every x) iff (for every x,y, c(x)=c(y) implies a(x)=a(y)).

**Assumptions**

- The domain of the decoder is the attained subtype I, not all of C.
- X may be empty; A is not required to have a default value.
- This target retains the paper finite-domain specialization even if a library theorem is more general.

**Proof route:** Necessity by substitution; sufficiency by choosing a representative of each attained capsule and using fiber constancy. Record any choice/classical axioms in the later receipt.

**Boundary controls**

- X has two elements, c is constant and a distinguishes them: no decoder.
- X is empty, C is inhabited and A is empty: attained-domain decoder exists, but a total C -> A decoder does not.

**Limit:** Inherited MIND criterion, not a new CPX theorem. No efficient decoder, generalization, semantic parser or compression-rate conclusion.

## CPX06-C2 Protected return

**Source location:** Section 3, Protected return

**Exact source paragraph**

> Let P be a projection of a supplied record and suppose the protected query factors as q(x) = f(P(x)). If T preserves P on the supplied domain, substitution gives q(T(x)) = q(x). The conclusion is only as strong as the two premises. A matching answer does not imply matching full states: (answer 7, history 0) and (answer 7, history 1) are an explicit counterexample. This is an elementary inherited observation, not a newly claimed theorem. [S1]

**Target statement**

For types X,C,A and functions P : X -> C, T : X -> X, f : C -> A and q : X -> A, assume q(x)=f(P(x)) and P(T(x))=P(x) for every x. Then q(T(x))=q(x) for every x.

**Assumptions**

- T maps the supplied domain to itself.
- Projection preservation and factorization are premises, not inferred from a natural-language reply.

**Proof route:** Rewrite q using its factorization, then use projection preservation.

**Boundary controls**

- On X = natural numbers x Boolean history, q returns the first coordinate. States (7,false) and (7,true) have equal answers but unequal states.

**Limit:** Checks the formal implication, not whether evidence, permission, meaning or task identity was faithfully represented. Source PAL material remains separately attributed.

## CPX06-C3 Free optional information

**Source location:** Section 9, Free optional information under fixed premises

**Exact source paragraph**

> For finite worlds, signals and a nonempty finite action set, fix a known joint distribution and utility. A chooser allowed all signal-dependent policies can always choose a constant action. Therefore its best expected value is at least the best value of a constant policy. Equivalently, averaging the conditional optimal values cannot be below the prior optimum. Zero-probability signal branches contribute zero and need not be assigned a posterior.

**Target statement**

Take nonempty finite sets W,S,A, nonnegative rational joint masses mu(w,s) with total one, and rational utility u(w,a). Let Vblind = max over a in A of sum over w,s of mu(w,s)*u(w,a). Let Vinformed = max over policies pi:S->A of sum over w,s of mu(w,s)*u(w,pi(s)). Then Vblind <= Vinformed.

**Assumptions**

- Finite rational specialization of the printed finite expected-value argument; any future real-valued generalization must be labeled.
- The same actions, joint distribution and utility are used in both values.
- Every signal-dependent policy is available, including constants; no inspection cost is subtracted.
- Nonempty finite types make the maxima attained. Zero-mass branches contribute zero without posterior division.

**Proof route:** Every constant action induces an available constant policy with exactly the same joint expected utility; compare maxima. Avoid invoking independence or constructing posteriors.

**Boundary controls**

- A single available action has zero gross information gain. Adding a positive compulsory inspection cost makes net value lower.
- The companion equal-accuracy diagnostics have gross values 3/16 and zero; a scalar accuracy is insufficient to choose the value.

**Limit:** An ideal decision result, not evidence that a model finds an optimal policy, that asking is free, or that its utility includes all affected parties.

## CPX06-C4 Question-relative resolution and non-identification

**Source location:** Section 3, Resolution has an object; Section 9 opening construction

**Exact source paragraph**

> Let W be a nonempty set of worlds compatible with the recorded evidence and assumptions. A query is settled within that account when all worlds in W give it the same answer. Different queries can have different statuses on the same W. An empty W means the account is inconsistent, not that every query has been successfully answered. A later question can need information that the earlier answer never claimed to preserve.

**Target statement**

Define Settled(W,q) as W is nonempty and there exists b such that q(w)=b for every w in W. An empty W is not settled. There exist a two-element W and queries q,r for which Settled(W,q) holds while Settled(W,r) does not. Instantiate W by causal worlds A and B: under a fair bit U, both observationally have C=U,Y=U; A uses structural equation Y=C and B uses Y=U. Under do(C=0), P_A(Y=1)=0 and P_B(Y=1)=1/2, although their observational joint tables agree.

**Assumptions**

- The world set and admissibility conditions are supplied; the formalization does not certify their completeness.
- Intervention replaces C equation only. U distribution and each Y equation remain fixed.
- Settled includes nonemptiness, not vacuous universal agreement alone.

**Proof route:** Prove the elementary definition lemmas, enumerate the two binary joint tables and interventional tables with rational masses, and use their different target probabilities as the counterexample.

**Boundary controls**

- Without the nonempty premise, universal agreement on an empty set is vacuous.
- Observational query P(C=Y)=1 agrees in both worlds; intervention query P(Y=1 after do(C=0)) differs.

**Limit:** An explicit non-identification witness, not a general causal discovery or human-intent theorem. Pearl remains the established antecedent.

**Additional exact source paragraph**

> Let U be a fair bit. Two structural worlds both set C = U. World A sets Y = C; world B sets Y = U. Ordinary observations agree exactly: (C,Y) is (0,0) or (1,1), each with probability one half. Under an intervention fixing C to zero, A gives Y = 0 always while B retains Y = U. The occurrence and distribution can be settled while the intervention effect remains unresolved. More passive samples of those same variables cannot distinguish the worlds. This is an elementary non-identification construction, consistent with established causal theory. [R06, E2]
