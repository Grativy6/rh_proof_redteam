"""Offline package checks and finite replays. This entry point never calls models."""
from pathlib import Path, PurePosixPath
from datetime import datetime,timezone
import hashlib,json,subprocess,sys
ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    manifest=json.loads((ROOT/'MANIFEST.json').read_text(encoding='utf-8'));failed=[]
    names=[r['path'] for r in manifest['files']]
    actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p.name!='MANIFEST.json' and 'tmp' not in p.relative_to(ROOT).parts and '__pycache__' not in p.relative_to(ROOT).parts}
    if len(names)!=len(set(names)) or set(names)!=actual:failed.append('Payload inventory')
    for item in manifest['files']:
        rel=PurePosixPath(item['path'])
        if rel.is_absolute() or '..' in rel.parts:raise ValueError('Unsafe manifest path')
        p=ROOT/item['path']
        if not p.is_file() or p.stat().st_size!=item['bytes'] or sha(p)!=item['sha256']:failed.append(item['path'])
    cards=json.loads((ROOT/'LEAN_CLAIMS.json').read_text(encoding='utf-8'))
    md=ROOT/cards['source'];text=md.read_text(encoding='utf-8')
    if sha(md)!=cards['source_sha256']:failed.append('Lean card source hash')
    for card in cards['cards']:
        if card['verbatim_source'] not in text:failed.append('Claim locator '+card['id'])
        if card.get('additional_source') and card['additional_source'] not in text:failed.append('Additional claim locator '+card['id'])
    for label,p in [('document',ROOT/'audit/DOCUMENT_VERIFICATION.json'),('evidence',ROOT/'audit/EVIDENCE_VERIFICATION.json')]:
        report=json.loads(p.read_text(encoding='utf-8'))
        if report['status']!='PASS':failed.append(label+' retained receipt')
        if label=='document' and not report['visual_review']['all_final_pages_inspected']:failed.append('Page inspection incomplete')
    (ROOT/'tmp').mkdir(exist_ok=True)
    replay_report=ROOT/'tmp/PACKAGE_REPLAY.json'
    if not failed:
        guards=subprocess.run([sys.executable,str(ROOT/'tools/test_portable_replay.py')],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=30)
        (ROOT/'tmp/PORTABILITY_GUARDS.txt').write_text(guards.stdout+guards.stderr,encoding='utf-8')
        if guards.returncode:failed.append('Portability guards')
        run=subprocess.run([sys.executable,str(ROOT/'tools/verify_evidence.py'),'--report',str(replay_report)],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=120)
        (ROOT/'tmp/PACKAGE_REPLAY.stdout.txt').write_text(run.stdout,encoding='utf-8')
        (ROOT/'tmp/PACKAGE_REPLAY.stderr.txt').write_text(run.stderr,encoding='utf-8')
        if run.returncode:failed.append('Offline finite replay')
    report={'status':'PASS' if not failed else 'FAIL','checked_utc':datetime.now(timezone.utc).isoformat(),
      'manifest_files':len(manifest['files']),'failed':failed,'network_calls':0,'model_calls':0,'new_charge_usd':0,
      'scope':'File integrity, source-bound claim text and local finite replay. Retained visual attestation is not a new rendering or independent peer review.'}
    (ROOT/'tmp/PACKAGE_VERIFICATION.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report))
    return 0 if not failed else 1
if __name__=='__main__':raise SystemExit(main())
