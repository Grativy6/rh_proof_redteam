"""Cross-format content check plus an explicit, separate visual-review record."""
from pathlib import Path
from datetime import datetime,timezone
import argparse,hashlib,json,re,unicodedata,zipfile
import xml.etree.ElementTree as ET
from pypdf import PdfReader
ROOT=Path(__file__).resolve().parents[1]
W='{http://schemas.openxmlformats.org/wordprocessingml/2006/main}'
PKG='{http://schemas.openxmlformats.org/package/2006/relationships}'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def norm(t):return ''.join(c for c in unicodedata.normalize('NFKC',t).casefold() if c.isalnum())
def plain_md(t):
    out=[]
    for line in t.splitlines():
        if not line.strip() or line.startswith('<!--'):continue
        if line.startswith('|'):
            cells=[x.strip() for x in line.strip('|').split('|')]
            if all(re.fullmatch(r':?-+:?',x.replace(' ','')) for x in cells):continue
            line=' '.join(cells)
        line=re.sub(r'^#{1,6}\s+','',line)
        line=re.sub(r'\[([^\]]+)\]\(https?://[^)]+\)',r'\1',line)
        out.append(line.replace('**','').replace('*','').replace('`',''))
    return '\n'.join(out)
def main():
    p=argparse.ArgumentParser();p.add_argument('--render-dir',type=Path,required=True);p.add_argument('--visual-pages')
    a=p.parse_args();stem='Context_Parallax_v0.6_WORKING_DRAFT';checks=[];details={}
    def ck(n,b,d=None):checks.append(dict(check=n,passed=bool(b),detail=d))
    md=(ROOT/'output'/f'{stem}.md').read_text(encoding='utf-8')
    with zipfile.ZipFile(ROOT/'output'/f'{stem}.docx') as z:
        tree=ET.fromstring(z.read('word/document.xml'));doc=' '.join(n.text or '' for n in tree.iter(W+'t'))
        rels=ET.fromstring(z.read('word/_rels/document.xml.rels'))
        urls=[n.attrib['Target'] for n in rels.findall(PKG+'Relationship') if n.attrib.get('Type','').endswith('/hyperlink')]
        styles=ET.fromstring(z.read('word/styles.xml'))
        ck('No paragraph border under title',not list(styles.iter(W+'pBdr')))
    pdfpath=a.render_dir/f'{stem}.pdf';reader=PdfReader(pdfpath);texts=[];uris=[];extraction_fixes=0
    for page in reader.pages:
        lines=(page.extract_text() or '').splitlines()
        lines=[l for l in lines if not re.match(r'^CONTEXT PARALLAX\s*/\s*WORKING PAPER v0\.6\s*$',l)
            and not re.match(r'^Pang and Hearthline\s*·\s*11 October 2026\s*·\s*\d+\s*$',l)]
        text='\n'.join(lines)
        # Observed pypdf extraction fault in this Cambria export. The two printed
        # Daume-with-acute names were individually inspected as correctly rendered.
        # Preserve other text and record the exact, narrow read-side substitution.
        extraction_fixes+=text.count('Daume\\')
        texts.append(text.replace('Daume\\','Daumé'))
        for ann in page.get('/Annots',[]):
            action=ann.get_object().get('/A',{})
            if action.get('/URI'):uris.append(str(action['/URI']))
    expected=norm(plain_md(md))
    for name,t in [('DOCX',doc),('PDF','\n'.join(texts))]:
        actual=norm(t);same=actual==expected
        if not same:
            k=next((i for i,(x,y) in enumerate(zip(expected,actual)) if x!=y),min(len(expected),len(actual)))
            details[name]={'offset':k,'md':expected[max(0,k-65):k+150],name:actual[max(0,k-65):k+150],'lengths':[len(expected),len(actual)]}
        ck('Markdown '+name+' normalized content equality',same)
        ck(name+' replacement glyph absent','\ufffd' not in t)
    ck('PDF and DOCX external links agree',set(urls)==set(uris),{'docx_links':len(urls),'pdf_segments':len(uris)})
    ck('Main chapters one through eleven',[int(n) for n in re.findall(r'^## (\d+) ',md,re.M)]==list(range(1,12)))
    ck('Reserved DOI present', '10.5281/zenodo.23306102' in md)
    ck('All page images present',all((a.render_dir/f'page-{i}.png').exists() for i in range(1,len(reader.pages)+1)))
    ck('No almost-empty pages',all(len(t.split())>65 for t in texts),[len(t.split()) for t in texts])
    report={'status':'PASS' if all(c['passed'] for c in checks) else 'FAIL','checked_utc':datetime.now(timezone.utc).isoformat(),
      'pages':len(reader.pages),'checks':checks,'mismatches':details,
      'visual_review':{'all_final_pages_inspected':a.visual_pages==f'1-{len(reader.pages)}','pages':a.visual_pages},
      'pdf_extraction_adjustment':{'raw':'Daume\\','correctly_rendered_name':'Daumé','count':extraction_fixes,'scope':'Read-side only, not a PDF or manuscript edit; accents require visual inspection.'},
      'files':{p.name:sha(p) for p in [ROOT/'output'/f'{stem}.md',ROOT/'output'/f'{stem}.docx',pdfpath]},
      'page_images':{f'page-{i}.png':sha(a.render_dir/f'page-{i}.png') for i in range(1,len(reader.pages)+1)},
      'normalization':'NFKC, casefold and alphanumeric sequence after stripping Markdown syntax and running headers. Punctuation and mathematical glyphs additionally require visual review.',
      'renderer':'Packaged render_docx.py and bundled Poppler, using existing task-local LibreOffice 26.2.6 with valid Document Foundation signature. Windows runtime provides no bundled LibreOffice. No system Office install.',
      'scope':'Artifact consistency and layout review, not independent scientific or Lean verification.'}
    (ROOT/'audit/DOCUMENT_VERIFICATION.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps({'status':report['status'],'pages':report['pages'],'failed':[c for c in checks if not c['passed']],'mismatches':details,'visual':report['visual_review']}))
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
