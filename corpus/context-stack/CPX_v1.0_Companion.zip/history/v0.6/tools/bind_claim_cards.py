"""Prepare source-bound mathematical targets; this does not run Lean."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[1]
source=ROOT/'output/Context_Parallax_v0.6_WORKING_DRAFT.md';text=source.read_text(encoding='utf-8')
def paragraph(prefix):return next(p for p in text.split('\n\n') if p.startswith(prefix))
cards=[
 dict(id='CPX06-C1',title='Decoder on attained capsule values',location='Section 3, The capsule criterion',
      verbatim_source=paragraph('On a finite supplied domain X'),
      statement='Let X be finite, C and A arbitrary types, c : X -> C and a : X -> A. Let I be the subtype of C attained by c, and cI : X -> I its lift. Then (there exists d : I -> A with d(cI(x)) = a(x) for every x) iff (for every x,y, c(x)=c(y) implies a(x)=a(y)).',
      assumptions=['The domain of the decoder is the attained subtype I, not all of C.','X may be empty; A is not required to have a default value.','This target retains the paper finite-domain specialization even if a library theorem is more general.'],
      proof_route='Necessity by substitution; sufficiency by choosing a representative of each attained capsule and using fiber constancy. Record any choice/classical axioms in the later receipt.',
      countercases=['X has two elements, c is constant and a distinguishes them: no decoder.','X is empty, C is inhabited and A is empty: attained-domain decoder exists, but a total C -> A decoder does not.'],
      boundary='Inherited MIND criterion, not a new CPX theorem. No efficient decoder, generalization, semantic parser or compression-rate conclusion.'),
 dict(id='CPX06-C2',title='Protected return',location='Section 3, Protected return',
      verbatim_source=paragraph('Let P be a projection'),
      statement='For types X,C,A and functions P : X -> C, T : X -> X, f : C -> A and q : X -> A, assume q(x)=f(P(x)) and P(T(x))=P(x) for every x. Then q(T(x))=q(x) for every x.',
      assumptions=['T maps the supplied domain to itself.','Projection preservation and factorization are premises, not inferred from a natural-language reply.'],
      proof_route='Rewrite q using its factorization, then use projection preservation.',
      countercases=['On X = natural numbers x Boolean history, q returns the first coordinate. States (7,false) and (7,true) have equal answers but unequal states.'],
      boundary='Checks the formal implication, not whether evidence, permission, meaning or task identity was faithfully represented. Source PAL material remains separately attributed.'),
 dict(id='CPX06-C3',title='Free optional information',location='Section 9, Free optional information under fixed premises',
      verbatim_source=paragraph('For finite worlds, signals and a nonempty finite action set'),
      statement='Take nonempty finite sets W,S,A, nonnegative rational joint masses mu(w,s) with total one, and rational utility u(w,a). Let Vblind = max over a in A of sum over w,s of mu(w,s)*u(w,a). Let Vinformed = max over policies pi:S->A of sum over w,s of mu(w,s)*u(w,pi(s)). Then Vblind <= Vinformed.',
      assumptions=['Finite rational specialization of the printed finite expected-value argument; any future real-valued generalization must be labeled.','The same actions, joint distribution and utility are used in both values.','Every signal-dependent policy is available, including constants; no inspection cost is subtracted.','Nonempty finite types make the maxima attained. Zero-mass branches contribute zero without posterior division.'],
      proof_route='Every constant action induces an available constant policy with exactly the same joint expected utility; compare maxima. Avoid invoking independence or constructing posteriors.',
      countercases=['A single available action has zero gross information gain. Adding a positive compulsory inspection cost makes net value lower.','The companion equal-accuracy diagnostics have gross values 3/16 and zero; a scalar accuracy is insufficient to choose the value.'],
      boundary='An ideal decision result, not evidence that a model finds an optimal policy, that asking is free, or that its utility includes all affected parties.'),
 dict(id='CPX06-C4',title='Question-relative resolution and non-identification',location='Section 3, Resolution has an object; Section 9 opening construction',
      verbatim_source=paragraph('Let W be a nonempty set of worlds'),
      additional_source=paragraph('Let U be a fair bit.'),
      statement='Define Settled(W,q) as W is nonempty and there exists b such that q(w)=b for every w in W. An empty W is not settled. There exist a two-element W and queries q,r for which Settled(W,q) holds while Settled(W,r) does not. Instantiate W by causal worlds A and B: under a fair bit U, both observationally have C=U,Y=U; A uses structural equation Y=C and B uses Y=U. Under do(C=0), P_A(Y=1)=0 and P_B(Y=1)=1/2, although their observational joint tables agree.',
      assumptions=['The world set and admissibility conditions are supplied; the formalization does not certify their completeness.','Intervention replaces C equation only. U distribution and each Y equation remain fixed.','Settled includes nonemptiness, not vacuous universal agreement alone.'],
      proof_route='Prove the elementary definition lemmas, enumerate the two binary joint tables and interventional tables with rational masses, and use their different target probabilities as the counterexample.',
      countercases=['Without the nonempty premise, universal agreement on an empty set is vacuous.','Observational query P(C=Y)=1 agrees in both worlds; intervention query P(Y=1 after do(C=0)) differs.'],
      boundary='An explicit non-identification witness, not a general causal discovery or human-intent theorem. Pearl remains the established antecedent.')]
payload={'status':'PREPARED_NOT_RUN','version':'0.6','reserved_doi':'10.5281/zenodo.23306102',
 'source':str(source.relative_to(ROOT)).replace('\\','/'),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),
 'repository_intent':'A later CPX formal companion in Grativy6/hearthline; no publication or Lean execution in this revision.',
 'cards':cards}
(ROOT/'LEAN_CLAIMS.json').write_text(json.dumps(payload,indent=2,ensure_ascii=False),encoding='utf-8')
out=['# CPX v0.6 claim cards for Lean','**PREPARED_NOT_RUN.** Four mathematical targets after manuscript stabilization. No kernel receipt is implied.',
 'Canonical manuscript: `'+payload['source']+'`\n\nSHA-256: `'+payload['source_sha256']+'`\n\nReserved DOI: '+payload['reserved_doi'],
 'Rebind these cards if the source wording changes. The later audit must retain source-to-formal translation, compiler and kernel results, explicit axiom dependencies and failure history separately. Empirical framing benefit is outside all four cards.']
for c in cards:
 out.extend(['## '+c['id']+' '+c['title'],'**Source location:** '+c['location'],
 '**Exact source paragraph**\n\n> '+c['verbatim_source'], '**Target statement**\n\n'+c['statement'],
 '**Assumptions**\n\n'+'\n'.join('- '+x for x in c['assumptions']),
 '**Proof route:** '+c['proof_route'], '**Boundary controls**\n\n'+'\n'.join('- '+x for x in c['countercases']),
 '**Limit:** '+c['boundary']])
 if c.get('additional_source'):out.append('**Additional exact source paragraph**\n\n> '+c['additional_source'])
(ROOT/'LEAN_CLAIMS.md').write_text('\n\n'.join(out)+'\n',encoding='utf-8')
print(json.dumps({'cards':len(cards),'source_sha256':payload['source_sha256'],'status':payload['status']}))
