"""Create the editable paper from the canonical Markdown. Requires python-docx."""
from pathlib import Path
import re
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT

ROOT=Path(__file__).resolve().parents[1]
SOURCE=ROOT/"output/Context_Parallax_v0.6_WORKING_DRAFT.md"
doc=Document()
s=doc.sections[0]
s.page_width=Inches(8.5);s.page_height=Inches(11)
s.top_margin=Inches(.72);s.bottom_margin=Inches(.7)
s.left_margin=Inches(.85);s.right_margin=Inches(.85)
s.header_distance=Inches(.3);s.footer_distance=Inches(.3)
for name in ("Normal","Title","Subtitle","Heading 1","Heading 2","Heading 3"):
    st=doc.styles[name];st.font.name="Cambria";st.font.color.rgb=RGBColor(0,0,0)
    fonts=st.element.get_or_add_rPr().find(qn("w:rFonts"))
    if fonts is not None:
        for attr in ("asciiTheme","hAnsiTheme","eastAsiaTheme","cstheme"):
            fonts.attrib.pop(qn("w:"+attr),None)
    if st.element.rPr is not None:
        for el in st.element.rPr.findall(qn("w:color")):
            for attr in ("themeColor","themeTint","themeShade"):
                el.attrib.pop(qn("w:"+attr),None)
for el in list(doc.styles.element.iter(qn("w:pBdr"))):
    el.getparent().remove(el)
doc.styles["Normal"].font.size=Pt(11)
doc.styles["Normal"].paragraph_format.line_spacing=1.1
doc.styles["Normal"].paragraph_format.space_after=Pt(7)
doc.styles["Normal"].paragraph_format.widow_control=True
doc.styles["Title"].font.size=Pt(29)
doc.styles["Title"].paragraph_format.space_after=Pt(8)
doc.styles["Subtitle"].font.size=Pt(17)
for name,size in (("Heading 1",17),("Heading 2",12.5),("Heading 3",11.5)):
    doc.styles[name].font.size=Pt(size)
    doc.styles[name].paragraph_format.space_before=Pt(10)
    doc.styles[name].paragraph_format.space_after=Pt(7)
    doc.styles[name].paragraph_format.keep_with_next=True
header=s.header.paragraphs[0]
header.text="CONTEXT PARALLAX  /  WORKING PAPER v0.6"
header.runs[0].font.size=Pt(8);header.runs[0].font.name="Calibri"
footer=s.footer.paragraphs[0];footer.alignment=WD_ALIGN_PARAGRAPH.RIGHT
run=footer.add_run("Pang and Hearthline  ·  11 October 2026  ·  ");run.font.size=Pt(8)
fld=OxmlElement("w:fldSimple");fld.set(qn("w:instr"),"PAGE");footer._p.append(fld)

def inline(p,text):
    for token in re.split(r'(\*\*.*?\*\*|`[^`]+`|\[[^\]]+\]\(https?://[^)]+\)|\*[^*]+\*)',text):
        if not token:continue
        if token.startswith("**"):
            p.add_run(token[2:-2]).bold=True
        elif token.startswith("`") and token.endswith("`"):
            run=p.add_run(token[1:-1]);run.font.name="Consolas";run.font.size=Pt(10)
        elif token.startswith("*") and token.endswith("*"):
            p.add_run(token[1:-1]).italic=True
        elif re.match(r'\[[^\]]+\]\(',token):
            label,url=re.match(r'\[([^\]]+)\]\((.+)\)',token).groups()
            rel=p.part.relate_to(url,"http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink",is_external=True)
            h=OxmlElement("w:hyperlink");h.set(qn("r:id"),rel)
            r=OxmlElement("w:r");prop=OxmlElement("w:rPr");u=OxmlElement("w:u");u.set(qn("w:val"),"single");prop.append(u);r.append(prop)
            t=OxmlElement("w:t");t.text=label;r.append(t);h.append(r);p._p.append(h)
        else:p.add_run(token)

lines=SOURCE.read_text(encoding="utf-8").splitlines();i=0;first_sub=True;pending_break=False;in_references=False
while i<len(lines):
    line=lines[i].strip()
    if not line:i+=1;continue
    if line=="<!-- PAGEBREAK -->":pending_break=True;i+=1;continue
    if line.startswith("# "):
        p=doc.add_paragraph(line[2:],"Title");p.paragraph_format.page_break_before=pending_break;pending_break=False;i+=1;continue
    if line.startswith("## "):
        if line=="## References and source identities":in_references=True
        style="Subtitle" if first_sub else "Heading 1";first_sub=False
        p=doc.add_paragraph(line[3:],style);p.paragraph_format.page_break_before=pending_break;pending_break=False;i+=1;continue
    if line.startswith("#### "):
        p=doc.add_paragraph(line[5:],"Heading 3");p.paragraph_format.page_break_before=pending_break;pending_break=False;i+=1;continue
    if line.startswith("### "):
        p=doc.add_paragraph(line[4:],"Heading 2");p.paragraph_format.page_break_before=pending_break;pending_break=False;i+=1;continue
    if line.startswith("|"):
        rows=[]
        while i<len(lines) and lines[i].strip().startswith("|"):
            cells=[x.strip() for x in lines[i].strip().strip("|").split("|")]
            if not all(re.fullmatch(r':?-+:?',x.replace(" ","")) for x in cells):rows.append(cells)
            i+=1
        table=doc.add_table(rows=0,cols=len(rows[0]));table.autofit=False
        widths=([2.05,.55,4.2] if rows[0][1]=="Count" else [1.62,2.31,2.87]) if len(rows[0])==3 else ([1.45,.6,1.5,1.9,1.35] if len(rows[0])==5 else [6.8/len(rows[0])]*len(rows[0]))
        if len(rows[0])==4: widths=[2.30,1.50,1.50,1.50]
        if rows[0][0]=="Candidate return": widths=[2.65,2.00,2.15]
        if rows[0][0]=="Case": widths=[1.35,2.15,3.30]
        if rows[0][0]=="Intended message": widths=[2.25,2.25,2.30]
        if rows[0][0]=="Observations": widths=[1.05,2.55,1.45,1.75]
        for col,w in zip(table.columns,widths):col.width=Inches(w)
        for ridx,row in enumerate(rows):
            cells=table.add_row().cells
            for c,w,text in zip(cells,widths,row):
                c.width=Inches(w);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER;p=c.paragraphs[0];inline(p,text)
                p.paragraph_format.space_after=Pt(4);p.paragraph_format.space_before=Pt(4);p.paragraph_format.line_spacing=1.02
                p.paragraph_format.keep_with_next=ridx<len(rows)-1
                for r in p.runs:r.font.size=Pt(9.5);r.bold=ridx==0
                pr=c._tc.get_or_add_tcPr();mar=OxmlElement("w:tcMar")
                for edge in ("top","left","bottom","right"):
                    el=OxmlElement("w:"+edge);el.set(qn("w:w"),"80");el.set(qn("w:type"),"dxa");mar.append(el)
                pr.append(mar)
                if ridx==0:
                    shade=OxmlElement("w:shd");shade.set(qn("w:fill"),"EEEEEE");pr.append(shade)
            trpr=table.rows[-1]._tr.get_or_add_trPr();trpr.append(OxmlElement("w:cantSplit"))
            if ridx==0:trpr.append(OxmlElement("w:tblHeader"))
        borders=OxmlElement("w:tblBorders")
        for edge in ("top","left","bottom","right","insideH","insideV"):
            e=OxmlElement("w:"+edge);e.set(qn("w:val"),"single");e.set(qn("w:sz"),"4");e.set(qn("w:color"),"D9D9D9");borders.append(e)
        table._tbl.tblPr.append(borders)
        doc.add_paragraph().paragraph_format.space_after=Pt(0)
        continue
    pieces=[line];i+=1
    while i<len(lines) and lines[i].strip() and not lines[i].startswith(("#","|","<!--")):
        pieces.append(lines[i].strip());i+=1
    p=doc.add_paragraph();p.paragraph_format.page_break_before=pending_break;pending_break=False
    inline(p," ".join(pieces))
    if in_references:
        p.paragraph_format.space_after=Pt(6)
        p.paragraph_format.line_spacing=1.08
        for r in p.runs:r.font.size=Pt(10.5)
doc.core_properties.title="Context Parallax"
doc.core_properties.subject="Changing the view without losing the question"
doc.core_properties.author="Christopher Daniel Pang; Hearthline (AI collaborator)"
doc.core_properties.keywords="Context Parallax, CPX, pinch, inflection, seed, interpretation, provenance, return"
target=SOURCE.with_suffix(".docx");doc.save(target)
print(target)
print("Canonical source words:",len(SOURCE.read_text(encoding="utf-8").split()))
