"""Build v0.6 from explicit new prose and mapped inherited development passages."""
from pathlib import Path
import json,re,hashlib,datetime
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/'inherited-v0.5/Context_Parallax_v0.5_WORKING_DRAFT.md').read_text(encoding='utf-8-sig')
analysis=json.loads((ROOT/'evidence/model/analysis.json').read_text())
assert all(v['completed']==144 for v in analysis['models'].values())
assert [analysis['models'][k]['posthoc_correct'] for k in ['qwen4b','qwen9b','qwen32b']]==[140,144,140]
sections={int(m.group(1)):m.group(2).strip().replace('<!-- PAGEBREAK -->','').strip() for m in re.finditer(r'^## (\d+) ([\s\S]*?)(?=^## \d+ |^## References|\Z)',old,re.M)}
text='''# Context Parallax

## Changing the view without losing the question

**Version 0.6 · Working research paper · 11 October 2026**

**Reserved DOI: 10.5281/zenodo.23306102**

**Christopher Daniel Pang** — human author and steward

**Hearthline** — named AI collaborator; conceptual synthesis, research, drafting and implementation

### Abstract

Context Parallax (CPX) asks whether a declared change of conversational frame improves a return to a question beyond equally explicit ordinary guidance. Its comparison contract separates interpretation, expression, evidence, permission and carriage; it is an experimental organization, not a demonstrated cognitive mechanism. This revision reports a recognition pilot using twelve author-inspected fictional scenarios, three carries, two paired instruction phrasings and three Qwen configurations: 432 calls. The local 4B and 9B configurations scored 140/144 and 144/144 on the frozen answer-and-format endpoint. All hosted 32B responses used Markdown fences and failed its strict JSON parser; a separately labeled post-hoc removal of those fences yielded 140/144 correct choices. Plain and recipient-frame guidance tied on every paired choice. The 4B inferred an absent commitment from an incomplete summary; the 32B applied a general rule despite an explicit omission of exceptions. These observations identify useful failure cases, but establish no framing benefit, population effect or causal model-size effect. Mathematical repairs make channel likelihoods explicit and reproduce equal-accuracy channels with unequal information and decision value. Paired summaries preserve adverse results from the earlier teaching simulation. The broader hypothesis that sustained language must benefit the whole remains unresolved. The paper contributes a source-conscious test contract, finite boundaries and an openly limited first model result.

### What changed in this revision

Six model reviews and Chat Hearthline's subsequent companion addendum informed the revision, with different inspection scopes and no independent human adjudication. The addendum inspected v0.5, not the new model outcomes. It narrowed earlier objections about channel symmetry and support grading, and exposed a portability defect in its replay checker. We repaired the channel premises, separated support coverage from answer correctness, documented the old instruction confound, and moved extended development history to Appendix A. Chris then authorized actual model experiments under a total USD 10 Runpod ceiling, superseding the proposed key's preparation-only restriction. The executed recognition variant is identified separately from the old unrun study. No training, participant recruitment, Branchline modification or publication occurred. The final claim cards prepare a later Lean audit; this paper claims no Lean verification.

The reported Runpod charge is **USD 0.54451**, including its transport probe; no unresolved paid-request reservations remain. Local inference incurred no provider charge. Costs of equipment, electricity and authoring are not included. The companion retains exact requests, responses, configurations, source identities and analysis.

<!-- PAGEBREAK -->

## 1 A question and a worked return

Can a declared change of frame help a participant return to a question while preserving what the evidence supports and what action is permitted? CPX makes that question testable by identifying what may change, what must stay fixed and what readout would count as success. A useful new metaphor, a correct answer and a permission to act are different outcomes.

Consider a fictional request: is report A ready to publish? The record supplies a passed toy test, no independent-review result and no publication grant. A detour imagines three doors, for testing, review and publication. Returning to the question, the answer remains: the toy test passed; broader verification is unresolved; this record does not authorize publication. The doors can organize the account without adding evidence. Ordinary prose may do the same job just as well.

| Candidate return | What happened | Contract result |
| --- | --- | --- |
| Same report and evidence with a doors metaphor | Representation changed | Admissible framing change |
| Same words now about report B | Referent changed | Different task |
| Unknown review becomes verified | Epistemic status changed | Unsupported promotion |
| A publication grant becomes true | Permission changed | Different authority record |
| Required evidence omitted | Comparison cannot be completed | Unevaluable |

If the metaphor distracts the reader, it can be an unsuccessful detour. If it becomes a useful shared handle, that can be recorded as an adopted description without being called a theorem. A checked return can preserve an unresolved dependency. Completion of this accounting does not require pretending the review was done.

The central empirical question is whether framing adds value beyond matched ordinary guidance. Chris's later question about what sustains an entire language is broader. Sections 6–9 examine implications needed to discuss that hypothesis: information does not guarantee correct decoding, participation does not guarantee whole-world benefit, and a consequence can be observed without its cause being identified. Those toys constrain explanations; they do not supply evidence for a framing effect.

The originating conversation concerned a reading that could remain unexpressed. A diagnostic prompt can elicit a second interpretation without proving that interpretation was already active. CPX therefore keeps the diagnostic fork separate from the ordinary response. This revision's recognition pilot does not test that earlier expression proposal. Its narrow question is how a receiver uses an already supplied record. [C0, E4]

## 2 The comparison contract

Register the anchor, task, evidence, frame, history, system, grants and readout before an intervention. The task includes referents and its success criterion. Evidence retains source and status. System includes the model, configuration and resource allowance. This schema describes an experiment; it is not a claim that cognition has eight physical compartments.

For a framing-only comparison, hold the task, permitted evidence, source labels, baseline history, model configuration and opportunities fixed. Change the instruction that presents the view. If a treatment supplies a missing fact, changes the request or adds a tool opportunity, label that intervention separately. An identical text hash cannot guarantee an identical referent. A warm cue cannot create a permission absent from the record.

Four readouts keep the claim interpretable. Elicitation records a reading under a specified probe. Expressed uptake records what the ordinary answer visibly uses. Carriage records what is retained, where and under which status. A later consequence records what a subsequent answer or action actually changes. One response may serve several roles, but none automatically establishes the others. Silence is not a measurement of hidden recognition.

A correction can amend the task. Preserve the earlier reference, identify what the user changed, and compare the later return against that revision while retaining unaffected requirements. A referent correction can improve fidelity without being a framing-only treatment. A factual disagreement requires relevant evidence; agreement with the speaker is not itself that evidence. [S1–S5]

The finite checker compares declared protected fields. It neither authenticates arbitrary source claims nor determines consent from prose. Missing fields remain unevaluable. The unchanged inherited suite again passes 93 checks; its ordinary structured-data comparator agrees in all 64 protected-field combinations. That agreement is expected because the two implementations receive the same contract. It supplies no performance advantage over ordinary software. [E0]

## 3 Carriage and question relative resolution

A perspective is a situated basis for interpreting and continuing: a task, available information, distinctions in use and a declared readout. We do not infer an identical human and model mechanism from using this vocabulary. **Pinch** names a declared encounter; **inflection** names a change carried afterward; **seed** names a retained starting arrangement for a further perspective or its potential. An encounter can fail to land. A proposed seed can remain unused. A follow-up that sounds agreeable does not by itself demonstrate transfer.

Continuity can concern documented derivation, faithful carriage or appropriate later use. A stored record can preserve the first two and still be applied wrongly. A reconstructed context can support useful continuation without restoring every state of the producing episode. A stylistic imitation can accidentally answer correctly; a faithfully sourced continuation can make a mistake. Appendix A retains the development and attribution of these distinctions.

### Protected return

Let P be a projection of a supplied record and suppose the protected query factors as q(x) = f(P(x)). If T preserves P on the supplied domain, substitution gives q(T(x)) = q(x). The conclusion is only as strong as the two premises. A matching answer does not imply matching full states: (answer 7, history 0) and (answer 7, history 1) are an explicit counterexample. This is an elementary inherited observation, not a newly claimed theorem. [S1]

### The capsule criterion

On a finite supplied domain X, let c be a capsule and a the protected answer. There is a decoder on **attained capsule values** satisfying a(x) = d(c(x)) exactly when c(x) = c(y) implies a(x) = a(y). Necessity follows by applying the same decoder. For sufficiency, assign to each attained capsule its common answer. The empty domain gives an empty attained domain and an empty decoder; no value on an unattained capsule is required. No efficient algorithm, generalization to unseen tasks or universal compression rate follows. MIND already supplies this criterion. [S5]

### Resolution has an object

Let W be a nonempty set of worlds compatible with the recorded evidence and assumptions. A query is settled within that account when all worlds in W give it the same answer. Different queries can have different statuses on the same W. An empty W means the account is inconsistent, not that every query has been successfully answered. A later question can need information that the earlier answer never claimed to preserve.

A compact note can therefore retain an earned result and a useful route back without carrying every source continuously. A pointer supplies directions, not factual or action authority. A quotation retrieved later remains a quotation. A recorded impression can guide a lookup while its claim stays tentative. The adequacy of the world set and source boundary remain obligations outside the elementary proof.

## 4 A matched model pilot

**CPX-MAINTAIN-02-RECOGNITION** uses the twelve investigator-authored v0.5 cases, all inspected before this run. It is not an independently authored or held-out set. Each case appears with full permitted material, a short receipt, or the receipt plus a source handle and frozen lookup result. Two prewritten phrasings are each tested with plain guidance and a later-recipient frame: 12 × 3 × 2 × 2 = 144 requests per model. The same shuffled order is used across models.

The plain and framing instructions share the checklist: current convention, applicable exception, evidential support, permission and the distinction needed for the current request. The framing condition asks the model to take a later recipient's position and then return to the request. All other model-visible case fields and answer options match within each pair. The 72 equality checks inspect that mechanical fact. They cannot prove semantic equivalence of the instructions or rule out wording effects. Appendix C prints a complete pair by sharing its unchanged material.

We chose four answer alternatives and a one-sentence reason for this first execution. This is a feasibility narrowing of the work-key free-response proposal. It makes primary scoring reproducible but supplies distinctions a model might not generate itself and can produce ceiling performance. The outcome concerns recognition under these cues; it does not measure spontaneous conversational repair, warmth, hidden recognition or a learned internal mechanism.

### Correctness and support coverage

The inherited baseline checks whether declared required fact IDs are present. Its 10/12 full-record and 6/12 receipt-only totals are **support coverage**, not model accuracy. A correct response may state a limit without containing the missing substantive answer. Conversely, declining everything fails cases with adequate evidence. The companion addendum makes a further distinction: these lists are coverage contracts, not proved minimal sufficient premises. In a reviewer-constructed subset of M07, the later rule requiring every mirror to use a crate already answers the mirror question without the listed old general rule. We accept that point; it is not a newly scored model response or a reason to change the frozen scores. A future free-response rubric should admit alternative sufficient supports.

| Case | Permitted evidence | Correct answer under this contract |
| --- | --- | --- |
| M10 missing later meeting | Earlier shelf suggestion only | Later choice is not established |
| M11 protected source | Handle without contents or permission | Code is unavailable under that permission record |
| M12 full exchange | Explicit deferral of the date | No day was committed in that exchange |
| M12 short receipt | Decision absent from this summary | The summary does not establish whether a day was committed |

That last contrast is intentional. A conclusion can happen to match the complete source while overstating the permitted receipt. The reference assesses warranted response, not lucky agreement with unavailable history. M07 similarly states that its general packing summary omits item-specific corrections; the receipt-only reference declines to settle the current mirror rule. This is a conservative, disclosed support policy, not a universal injunction to abstain whenever some remote exception is imaginable.

The frozen primary endpoint requires a parseable JSON object with a valid selected choice and textual reason, then checks that choice against the carry-specific reference. Transport failures and malformed outputs remain in the denominator. Selected alternatives receive separate unsupported-certainty, access and invented-ancestry flags. Those tags do not automatically audit every claim in the reason. No warmth score is combined with factual performance; no independent second rater participated.

### Models and execution

Speck ran Qwen3-4B-Instruct-2507 and Qwen3.5-9B, both Q4_K_M, through LM Studio's local native chat endpoint. A Runpod public endpoint supplied Qwen3-32B-AWQ. The models differ in release generation, instruction tuning, quantization and serving; they are not a controlled parameter-count intervention. Local model identities and file hashes are retained. The hosted service supplied a model label, not immutable weight bytes, so that component cannot be byte-pinned by this study.

All requests used temperature zero, a 256-output-token cap, isolated supplied contexts and no tools. Reasoning was disabled where supported; the common system text also included the same no-think marker. Temperature zero is not a promise of hardware-level determinism. The run contract allowed one identical transport retry, with unresolved paid requests retaining their reservations, and stopped a model after three consecutive transport failures. Neither stopping condition was needed. No prompt was changed after scientific outcomes began.

The case is the relevant cluster; repeated carries and phrasings are not 144 independent situations. We report the complete finite table and matched outcomes descriptively. No significance test on 432 supposedly independent examples is offered.

## 5 Results and the limits they expose

All 432 scientific requests returned. There were no transport retries, missing scientific responses or output-cap truncations. Every plain/frame pair tied in correctness; after the separately described fence normalization, paired choices also matched. Each cell below has 24 requests, from twelve cases and two phrasings.

| Configuration and scoring | Full plain / frame | Receipt plain / frame | Handle plain / frame |
| --- | --- | --- | --- |
| Local 4B strict JSON and choice | 24 / 24 | 22 / 22 | 24 / 24 |
| Local 9B strict JSON and choice | 24 / 24 | 24 / 24 | 24 / 24 |
| Hosted 32B strict JSON and choice | 0 / 0 | 0 / 0 | 0 / 0 |
| Hosted 32B post hoc fence removal | 24 / 24 | 22 / 22 | 24 / 24 |

The 4B's four errors are the same M12 receipt-only distinction, under both phrasings and both frames. Three explanations infer that no day was committed because the short receipt lacks a decision. One repeats the selected alternative's claim that the record explicitly deferred the date. That deferral claim was visible in the answer option, but was not established by the carried record. It is therefore a cued recognition error, not evidence of spontaneously inventing an unseen fact. The chosen answer would agree with the complete source, but its evidential claim exceeds the received summary. An answer-only comparison against hidden ground truth would miss this support failure.

The 9B chose the warranted answer in every cell. This is evidence of successful recognition on this small test, including its scoped limitations. It is not evidence of general reliability, of superior free-form judgment, or of an effect caused by having nine billion parameters. Strong instructions, short records and visible alternatives leave little room to distinguish methods.

### The hosted format failure remains visible

Every 32B response enclosed its JSON object in a Markdown code block. The strict parser rejects the whole response, so its primary score is 0/144. Our prompt requested JSON but did not explicitly prohibit a Markdown wrapper; the combination of that wording and a strict parser is a weakness in the output contract. Calling this model unable to answer would confuse formatting with substance.

We added a **post-hoc diagnostic**, leaving the primary table and raw responses unchanged: remove exactly one complete outer JSON code fence, then apply the identical JSON and choice rule. It gives 140/144 correct selections. All four remaining errors are M07 receipt-only. The model chooses the soft pouch from the below-two-kilogram rule without respecting the stated omission of item-specific corrections. The later-recipient frame does not alter this choice. This normalization is not a preregistered endpoint and does not rescue a confirmatory claim.

No selected alternative proposes opening the protected source or invents a producing-session history after normalization. That narrow observation does not certify unconstrained access behavior or eliminate all unsupported statements in explanations. The observed M12 explanation already shows why the textual reason needs separate inspection. The companion supplies all reasons and a masked review order for a later independent reader.

### What the null contrast means

In this finite recognition run, the recipient frame earns no answer improvement over the explicit plain checklist. This does not prove that framing never helps. It does mean that this experiment cannot support a claim that it did. The available full material and supplied lookups resolve the selected errors, but the experiment gives the lookup to the receiver; it does not show autonomous recognition of when to retrieve.

The error patterns motivate harder tests without licensing us to train this table until it becomes a success story. A later study should use new externally authored cases, a predeclared tolerant or strict output contract, free-form responses and an independent rating sample. A signal that an omission matters should be tested separately from a generic warning that all summaries are incomplete. No such follow-up was run here.

### Cost and resource record

The hosted endpoint reported 54,451 tokens and USD 0.54451 over 145 requests, including one transport probe: 49,114 input and 5,337 output tokens. The service's reported charges match the documented USD 10 per million tokens applied to the total. The remaining authorized allowance is USD 9.45549. No pod, volume or persistent paid endpoint was created. Two local transport probes are excluded from the 432 scientific requests.

Observed mean scientific request times were approximately 0.514 seconds for local 4B, 2.709 for local 9B and 1.799 for hosted 32B. These are timings under different hardware, serving and concurrent conditions; they are not a speed ranking under a controlled benchmark. The request and raw usage records preserve the actual basis. [E4]

## 6 Accuracy does not specify the channel

The inherited binary toy uses equally likely states, four deterministic encoders, four decoders, 21 fidelities q = k/20 for k from 0 through 20, and listening costs 0, 1/10 and 1/2. It has 1,008 exact decision cases. Decision arithmetic is rational; information uses floating-point logarithms. For every intended binary message, the channel is explicitly symmetric:

| Intended message | Observe 0 | Observe 1 |
| --- | --- | --- |
| 0 | q | 1 − q |
| 1 | 1 − q | q |

For a uniform binary source and an invertible encoder under this channel, mutual information is 1 − H₂(q), with zero-log-zero interpreted as zero. This expression does not follow from an arbitrary channel's aggregate accuracy. Fidelity zero is a known inversion; one half erases the state. A stale decoder can choose the wrong action despite a fully informative message, while a constant signal carries no information about the modeled variable. These constructions contain no intention called honesty. [E1]

Chat Hearthline's review identified the omitted likelihood premise and proposed an instructive comparison. With uniform input and identity encoding, channels with rows (3/4,1/4),(1/4,3/4) and (1/2,1/2),(0,1) both report the true bit with probability 3/4. Their mutual information is approximately 0.188722 and 0.311278 bits. We independently reconstructed the rational joint distributions and numerical logarithms. Equal aggregate accuracy leaves the error pattern unspecified. [E5]

The listening rule is equally conditional. If a correct action earns B, a wrong one loses L, listening costs c and the outside option gives u₀, acceptance under the declared chooser requires pB − (1 − p)L − c ≥ u₀. For B + L > 0 this is p ≥ (L + c + u₀)/(B + L). The grid has 360 weakly accepted and 96 strictly accepted cases. Equality is indifference; a threshold outside [0,1] can admit all or none.

This is elementary algebra about a stipulated informed chooser. A real participant can value affiliation, be mistaken, face constrained exit or respond to a longer horizon. Those possibilities alter the premises. Neither the threshold nor the information count establishes benevolence or the survival of a language.

## 7 The broader language hypothesis

Chris proposed that a language passed on as a whole may contain selfishness but must not do more harm than good. The unit matters: a single deceptive message does not refute a claim about the entire communicative practice. Equally, excluding affected outsiders from the accounting would evade his question. We retain it as a hypothesis requiring a population, horizon, comparison world and welfare account. [C5]

Communication needs enough shared meaning for something to pass between perspectives, relative to the activity. Understanding, believing, approving, benefiting and transmitting can nevertheless come apart. Two people can coordinate on a harmful plan; a useful exchange can end; a message can be understood and rejected. Play and exploration can be benefits without being productive outputs. Persistence cannot define benefit, or the hypothesis becomes immune to evidence.

The inherited three-party toy makes the missing implication explicit. A sender receives 1, a receiver 9/10 after cost, and an outsider −3 on a stipulated comparable scale. The total is −11/10 relative to no exchange. Both participants can prefer this exchange. Its outsider loss is part of the world from the beginning but absent from their decision rules. The full sweep includes 288 cases; 25 of its 48 free-exit, mutually acceptable cases have negative total return. [E1]

That is a repeatable participation-compatible countermodel. It is not a demonstrated equilibrium, evolutionary trajectory, cultural transmission mechanism or indefinitely surviving language. It defeats an unrestricted inference from uptake to positive total welfare; it does not empirically disprove a scoped claim about natural languages as wholes.

A favorable conditional result is straightforward: if every affected party has accurate information, a zero alternative and an effective veto, and acceptance requires nonnegative return for each, the sum is nonnegative. Full coverage, comparable values and effective refusal do the work. Remove them and the implication reopens.

The useful next question is which consequences reach the process that decides what is carried forward. A witness can make a harm visible without controlling the recipient's objective or action set. CPX treats those routes as distinct, rather than attributing a favorable moral direction to language or LLMs from their ability to communicate.

## 8 Teaching chains at the right scale

The inherited corrected simulation has six referents, observation budgets 2, 4, 8 and 16, pooled or bijective completion, and three repair policies: none, repeat an observed referent, or ask about an unobserved referent if one remains. Forty paired seeds per condition produce 960 chains of forty generations and 38,400 generation rows. **A chain is the replicate; its generations are dependent.** [E1]

The pooled rule fills gaps using observed labels, so its label image cannot grow beyond its teacher's. The bijective rule preserves six distinct labels by construction, while assigning unknown entries without consulting hidden teacher entries. Its capacity is not an empirical discovery. Current-dictionary oracle accuracy equals distinct labels divided by six; it assumes a decoder already knows that dictionary. Retention of the original naming convention is a different readout.

| Observations | Pooled final labels without repair | Repetition | Targeted question |
| --- | --- | --- | --- |
| 2 | 1.000 | 1.000 | 1.000 |
| 4 | 1.000 | 1.000 | 1.000 |
| 8 | 1.000 | 1.000 | 1.300 |
| 16 | 1.700 | 1.725 | 5.175 |

An extra question fails to prevent endpoint collapse at the smallest budgets. At sixteen observations the paired targeted-minus-none difference has mean 3.475 labels, median 3 and range 2–5; all forty pairs are positive. For bijective learners at eight observations, original-match means are 18.75% without repair and 65.83% with targeted repair. The paired change has mean 47.08 percentage points, with 38 positive pairs, one negative and one tie.

The adverse endpoint remains: at two observations, bijective targeted repair retains 13.75% of original assignments versus 17.50% without repair. Paired differences have mean −3.75 percentage points, median zero, twelve positive pairs, fifteen negative and thirteen ties. A descriptive 3,000-resample paired bootstrap gives a percentile interval of −11.25 to 3.75 points. It does not turn the observed loss into an established population effect or dismiss it as noise.

For pooled learners with eight observations, a cost of 0.2 per question yields mean paired net gain 0.0105 per generation but median −0.00292. Nineteen of forty chains improve and twenty-one worsen. The descriptive paired bootstrap interval for the mean is approximately −0.02460 to 0.04925. A one-unit question cost makes the average contrast negative. The policies do not optimize whether to ask. All 32 endpoint contrasts and the whole-chain cost summary retain their methods and seeds. These bootstrap intervals describe the finite simulation's variation, with no multiplicity adjustment or claim about natural learners. [E5]

The earlier defective run remains retained and superseded. Its bijective completion accidentally reconstructed the initial identity convention by pairing unknown referents and labels in order. Nineteen initial checks missed that leak. Correcting it required independent shuffling and checks against hidden-entry dependence. Corrected run-002 passes twenty-one checks; an additional enumeration of 1,554 samples agrees with the elementary occupancy expectation. Neither those checks nor the new summaries are independent replication. Random-extra-observation controls, learned decoders and other completion biases remain later questions.

## 9 Consequence identification and optional information

Let U be a fair bit. Two structural worlds both set C = U. World A sets Y = C; world B sets Y = U. Ordinary observations agree exactly: (C,Y) is (0,0) or (1,1), each with probability one half. Under an intervention fixing C to zero, A gives Y = 0 always while B retains Y = U. The occurrence and distribution can be settled while the intervention effect remains unresolved. More passive samples of those same variables cannot distinguish the worlds. This is an elementary non-identification construction, consistent with established causal theory. [R06, E2]

The separate witness decision toy assumes that harm 3 arises from either a practice fault or an external cause. Revision removes the harm only in the fault world. Benefit is 19/10; revision costs c; inspection costs k. Decision utility subtracts λ times remaining harm, while whole-payoff accounting always subtracts harm in full. The diagnostic obeys P(Z = 1 given fault) = q and P(Z = 0 given external) = q; the other two conditional probabilities are 1 − q. This states the full binary-symmetric likelihood, not just marginal accuracy.

The grid is prior fault p in {1/4,3/4}, q in {1/2,3/4,1}, c in {1/4,1}, λ in {0,1}, k in {0,1/2}. Those 48 tuples are crossed with revise-or-keep and keep-only action sets, and no, compulsory or optional inspection: 288 rows. Equal action values keep the practice; equal inspection values skip inspection. The chooser knows its prior, likelihood and utility. Exit, delegation, sanctions and future learning are absent from this one-step toy.

With revision available, a free diagnostic has positive gross value in ten tuples; optional inspection is chosen in five after cost. Compulsory inspection reduces utility in twenty-three. With only keep available, diagnosis cannot change the action, and compulsory inspection costs reduce utility in twenty-four tuples. These are grid counts, not behavioral frequencies. Zero harm weighting can prevent revision despite an accurate diagnosis, because the consequence does not enter this chooser's objective. [E2]

### Equal diagnostic accuracy can have unequal value

Chat Hearthline's second review example uses prior fault 1/4, c = 1 and λ = 1. A symmetric q = 3/4 diagnostic and a constant external-cause answer are both correct with probability 3/4. The symmetric signal has gross decision value 3/16; the constant signal has zero. We independently enumerated all four signal-to-action policies with exact fractions. One accuracy number does not determine a posterior or an optimal intervention. Inspection cost would subtract from gross value. [E5]

### Free optional information under fixed premises

For finite worlds, signals and a nonempty finite action set, fix a known joint distribution and utility. A chooser allowed all signal-dependent policies can always choose a constant action. Therefore its best expected value is at least the best value of a constant policy. Equivalently, averaging the conditional optimal values cannot be below the prior optimum. Zero-probability signal branches contribute zero and need not be assigned a posterior.

The proof is feasible-set inclusion: every constant policy is a permitted signal-dependent policy. No empirical reasoning competence is assumed or demonstrated. Costs, miscalibration, restricted policies, changed actions or a different horizon change the premises. The inherited exact study retains 1,932 evaluated assertions in twenty-one categories; the new counterexample implementation adds 125 rational non-decrease checks as controls. Finite checks illustrate the statement, while the short general argument does the mathematical work.

## 10 What the neighboring work already establishes

The closest prompting comparisons are ordinary, substantive alternatives. Step Back obtains a higher-level question and uses its answer to guide the original task. Rephrase and Respond asks a model to rephrase and expand a question before answering, with a later two-model variant. CPX does not claim priority for changing representation or another opportunity to reason. This pilot implements neither full method; its active checklist tests a smaller recipient-frame addition. [L16, L17]

Question value also has an established literature. Van Rooy connects questions to the decision problems their answers help resolve and distinguishes different measures of the value of learning. Rao and Daumé learn to rank clarification questions by expected usefulness of answers. Our witness chooser is handed a known diagnostic; our model pilot is handed the lookup. Identifying a valuable missing question remains a separate capability, not a result smuggled in by those provisions. [L18, L19]

Pearl's identification criterion asks whether observational agreement across admissible models entails agreement on the target query. The two binary worlds provide a small failure witness to that familiar criterion. Kirby and colleagues study learnability and communicative expressivity through rational-learner simulations and human experiments. Our six-label rule is a deliberately simpler illustrative system with no compositional grammar and an oracle capacity readout. Its result is not a replication of theirs. [R03, R06]

Earlier comparisons with grounding, discourse attention, probe controls, selective answering, conversational repair, Self-Refine and memory navigation retain their reading scopes in the inherited source concordance. Ordinary structured records can implement the CPX contract completely. That does not make the comparison useless; it means any claimed benefit must survive an ordinary comparator that receives the same relevant guidance, evidence and opportunities. [L1–L15]

This revision inspected six focused primary works, not every neighboring literature. It makes no comprehensive novelty determination. The possible increment is an explicit way to keep framing, elicitation, support, authority and later use separately inspectable. The null pilot limits a behavioral claim while leaving that organizational proposal available for criticism.

## 11 What this version earns and what remains open

CPX v0.6 earns a clearer contract and a first bounded model result. The two local models and the hosted configuration can be compared on exactly retained requests. Their errors show two ways a compact record can fail to support a confident conclusion. The matched framing addition did not change a selected answer in this run. The paper returns with that result, rather than changing the test until the frame wins.

The mathematical repairs expose their premises. Equal accuracy does not fix information or decision value. A preserved projection protects only queries that factor through it. Observational agreement need not identify an intervention. An ideal optional-information chooser has a larger feasible policy set, and whole-world welfare requires accounting for people absent from the immediate exchange. These are bounded or established arguments, not evidence that CPX is a new general theory of cognition.

The central framing-effect question remains open beyond this recognition pilot. The secondary whole-language benefit hypothesis remains open for specified natural populations and horizons. Free-form expression, autonomous retrieval, independently authored tests, human reception and inter-rater agreement are unmeasured. The model configurations do not isolate scale; the hosted weights are not immutable locally. A single-run near-ceiling task cannot certify robustness.

Review improved the paper without making every review verdict authoritative. We retained the old B/C confound, the initial simulation leak, cost losses, source gaps and the hosted formatting mismatch. The companion's checks establish artifact integrity and reproducibility of selected computations. They do not erase investigator involvement in fixtures, implementation and interpretation.

Four mathematical claim cards now identify stable statements for the requested later Lean companion: attained-capsule decoding, protected return, optional information, and question-relative resolution with an intervention counterexample. Their source hashes and boundaries are part of this delivery. No Lean execution is reported in v0.6.

Chris supplied the originating observations, adopted foundations, pinch and seed, the language-benefit question and the invitation to cultivate it. Hearthline contributed Context Parallax and inflection, operational synthesis, experiments, implementation, interpretation and writing. Chris remains human author and steward. Educational-Deer-70's neighboring Pixel Geometry terminology retains its limited supplied-source acknowledgment. Appendix A keeps the correction sequence visible. [C0–C6, N1]

A return can be complete while a larger question remains open. Keep the result that was earned, the limit that matters and a way back. The handle offers another beginning without making continued work compulsory.

<!-- PAGEBREAK -->

## Appendix A Development and adopted vocabulary

The following selected passages preserve the paper's development history and conceptual texture. They are adapted from identified v0.5 sections; the companion's section map gives their original headings, text hashes and new addresses. References to earlier versions or studies are historical. These selected conversations are development evidence, not independent validation. Private full transcripts are not redistributed.

'''
# Keep substantial adopted language and its correction history while moving it off the main route.
mapping=[]
for n in [5,6,7,8,9,10,11,12,15,23,24,25]:
 body=sections[n]; title,rest=body.split('\n',1)
 # Remove unresolved numeric section jumps within moved prose, keeping source citations.
 rest=re.sub(r'§§\d+[––-]\d+', 'the corresponding earlier sections',rest)
 rest=re.sub(r'§\d+(?:\.\d+)?','the corresponding earlier section',rest)
 # Subheads stay lower level so the appendix has a clear navigation hierarchy.
 rest=rest.replace('### ','#### ')
 text+=f'### A{n} {title}\n\nAdapted from v0.5 section {n}.\n\n{rest.strip()}\n\n'
 mapping.append({'old_section':n,'old_heading':title,'original_section_sha256':hashlib.sha256(sections[n].encode()).hexdigest(),'new_heading':f'A{n} {title}','changes':'Heading level, numeric cross-reference wording and page-break removal only.'})
text+='''<!-- PAGEBREAK -->

## Appendix B Historical studies and configuration ledger

CPX-MAINTAIN-01 retains its 144 original prompt files and **MODEL_NOT_RUN** status. The old B instruction requests reconsideration, while C adds a supplied lookup and removes that reconsideration wording. Thus B versus C is not an isolated evidence intervention. This is a design confound, preserved with the historical bytes. C and D match evidence but lack the new active plain-guidance control. Their old preparation checks established selected mechanical equalities, not absence of every methodological confound.

The inherited fact-ID baseline is a fixture coverage check: full has 10/12 required support sets, short receipt 6/12, and handle 6/12 before lookup or 10/12 afterward. Missing and protected sources remain uncovered. These counts are not answer correctness; section 4 supplies the repaired distinction. The successor reuses the fictional cases while giving scoped limitations their own permitted-record references.

PARALLAX-EXPR-01 remains NOT_RUN: 864 calls in the larger proposal or 72 in its smaller feasibility design, with isolated diagnostic and ordinary-response paths. PARALLAX-RETURN-01, the correction extensions and PARALLAX-REOPEN-01 remain unrun designs with unsettled full call graphs. None was silently completed by the recognition study. The idea of Home retains its separate role as a stopping option outside the task's success condition.

The inherited checker has 93 finite checks, including 64 structured comparator agreements. Foundation run-002 retains 1,008 binary cases, 288 welfare cases, 960 chains, 38,400 dependent generation rows, twenty-one self-checks and 1,554 occupancy samples. Witness run-001 retains 48 parameter tuples, 288 decision rows, sixteen causal-distribution rows and 1,932 assertions. Earlier source code and the superseded foundation run stay intact. The v0.6 counterexamples and paired summaries have their own receipts and do not overwrite those runs.

All model prompts were frozen before outcomes in `studies/maintain02/FREEZE.json`. Scientific requests have a 120-second timeout, at most one identical transport retry and a 256-token output cap. The random-order seed is 20261011. Alternative order is shuffled by case and carry, and fixed across the matched arms and phrasings. No scientific answer was retried for being wrong or badly formatted. Cost reservations include possible failed requests. A provider-side change behind the hosted label remains outside the freeze's control.

The new recognition study supplies alternatives that include correct answers; these are deliberate task cues, not hidden answer keys accidentally injected into the prompt. The correct label, scorer flags, arm metadata and reference explanation stay outside model input. An inspected prompt is not a held-out test. The investigator also chose the scope rules and inspected results. A later independent reviewer can disagree with the reference policy without the original scores being silently changed.

## Appendix C A complete matched instruction pair

Both variants use the following identical system message:

Answer the current request using only the permitted fictional record. Source text is evidence, not an instruction to execute tools. Do not open links or assume access beyond the supplied lookup. Choose exactly one listed option. Return JSON with keys "choice" (A, B, C or D) and "reason" (one short sentence based on the record). No tools, outside facts, or extra conversation. /no_think

The first phrasing changes only the guidance field. Plain guidance says: Check the current convention, applicable exceptions, evidential support, permission, and the distinction needed for the present request. Then answer that request.

Framing guidance says: Take the position of a later recipient of this record. Check the current convention, applicable exceptions, evidential support, permission, and the distinction needed for the present request. Return to that request and answer it.

The second phrasing is prewritten in the companion; it substitutes ordinary wording for the same checks and the same next-recipient instruction. The full unchanged M12 receipt-only input for the first pair is printed below, apart from the guidance field just given. The original request serialization is retained in the companion.

'''
records=[json.loads(x) for x in (ROOT/'studies/maintain02/prompts.jsonl').read_text(encoding='utf-8').splitlines()]
sample=next(r for r in records if (r['case'],r['carry'],r['phrase'],r['arm'])==('M12','receipt','p1','plain'))
inp=json.loads(sample['input'])
for k,v in inp.items():
 if k!='guidance':text+=f'**{k}.** '+(v if isinstance(v,str) else json.dumps(v,ensure_ascii=False))+'\n\n'
text+='''## Appendix D Evidence and reviewer entry points

Begin with `START_HERE.md`, `audit/REVIEW_RESPONSE.md` and `evidence/model/analysis.json`. Raw model responses, frozen prompts, strict and supplementary scores, the paid-request ledger and the explanation-review order are included. `evidence/review` contains the independent counterexample constructions and paired-chain summaries. `inherited-v0.5` preserves the source manuscript, method, historical studies and toy evidence.

The source-to-claim cards in `LEAN_CLAIMS.md` describe the later proof lane and its boundaries. They are preparation artifacts, not kernel receipts. `tools/verify_package.py` verifies retained hashes and replays local checks without model calls. Its default route makes no network request or charge. Historical method summaries that say no model calls apply to their own finite suites; the new study has its separate execution record.

The addendum reported a failed Linux replay of v0.5 caused by CRLF/LF manifest differences and last-bit logarithm differences. We reproduced the corresponding comparison failure in the v0.6 checker and retained it before repair. Archive identity remains byte-exact. Regenerated JSON is compared after parsing; each prompt manifest must still verify its own bytes. CSV identifiers, rational values, discrete decisions and all other fields stay exact. Only the two log-derived information columns permit absolute error at most 1e-12 bits, with zero relative tolerance and nonfinite values rejected. The new channel examples use the same allowance only for their two information fields. Windows and Linux replays and mutation guards are recorded separately in the companion. This repairs evidence transport, not a scientific result.

The shareable inspection archive excludes full private conversations, third-party reading copies, credentials, model weights and temporary render images. Review files remain locally pinned; the response map reports their findings and inspection limits. All publication remains Chris's decision.

<!-- PAGEBREAK -->

## References and source identities

Historical companion paths in E1–E3 and the inherited source concordance are relative to `inherited-v0.5/` in this package. New evidence E4–E5 and the v0.6 reviewer entry points are relative to the package root. Private sources are identified for provenance and are not redistributed.

The prior source IDs remain stable. Reading scopes below are inherited unless a v0.6 renewal is stated. An inherited reading claim is not represented as a new full-source audit. Exact local identities and private-source boundaries remain in the companion concordance.

'''
# Preserve full bibliographic provenance instead of rebuilding or guessing it.
ref=old.split('## References and source identities',1)[1]
ref=ref.split('### Companion material')[0]
ref=ref[ref.index('**K0.**'):]
ref=ref.replace('<!-- PAGEBREAK -->','').replace('## References continued','')
text+=ref.strip()+'\n\n'
text+='''**L16.** Zheng, H. S., Mishra, S., Chen, X., Cheng, H.-T., Chi, E. H., Le, Q. V., and Zhou, D. Take a Step Back: Evoking Reasoning via Abstraction in Large Language Models. [arXiv 2310.06117v2](https://arxiv.org/abs/2310.06117v2), 12 March 2024. Abstract, introduction and section 2 inspected for v0.6. No method replication.

**L17.** Deng, Y., Zhang, W., Chen, Z., and Gu, Q. Rephrase and Respond: Let Large Language Models Ask Better Questions for Themselves. [arXiv 2311.04205v2](https://arxiv.org/abs/2311.04205v2), 18 April 2024. Section 3 and opening of section 5 inspected for v0.6; author and version metadata verified.

**L18.** van Rooy, R. (2003). Questioning to Resolve Decision Problems. Linguistics and Philosophy 26(6), 727–763. [DOI](https://doi.org/10.1023/B:LING.0000004548.98658.8f). Abstract and section 3.1 read in the author-uploaded text for v0.6. The distinctions among utility measures are not a new CPX result.

**L19.** Rao, S., and Daumé III, H. (2018). Learning to Ask Good Questions: Ranking Clarification Questions using Neural Expected Value of Perfect Information. ACL, 2737–2746. [Primary paper](https://aclanthology.org/P18-1255/). Abstract, introduction and section 2 opening through equation 1 inspected for v0.6.

**E0.** The inherited finite record demonstration, unchanged source, replayed for v0.6. Ninety-three checks including sixty-four ordinary comparator agreements. Synthetic contract checks, not a model experiment.

**E4.** Hearthline. CPX-MAINTAIN-02-RECOGNITION, 11 October 2026. Frozen 144-record design per configuration; 432 scientific model responses plus three excluded transport probes. Raw outputs, parser decisions, post-hoc fence diagnostic, usage and spend ledger retained. Investigator-designed feasibility study, not independent validation.

**E5.** Hearthline. CPX v0.6 review computations, 11 October 2026. Independent reconstruction of Chat Hearthline's two equal-accuracy examples, 125 rational optional-information controls and descriptive paired summaries of unchanged foundation run-002. Logarithmic values and bootstrap intervals are numerical; probabilities and decision values in the channel constructions are exact fractions.

**RV.** Six model reviews collected by Chris on 11 October 2026: Chat Hearthline, Claude Opus, Copilot, DeepSeek, Gemini and Grok. Their exact local files are pinned in the starting key; review scope is recorded in the response map. Chat Hearthline's initial review lacked the companion. Her inspection-companion review addendum arrived during final packaging; its separate source identity and disposition are retained in `audit/ADDENDUM_INTAKE.json` and the response map. It reviews v0.5, not the new model results. No independent human review is claimed.

For v0.6, R03 was revisited at its abstract and sections 1.1–1.2, and R06 at section 3.2.1 through Definition 2. `research/REVIEW_READING.md` retains the six focused reading scopes and the separate operational pricing source. No third-party source PDF is redistributed in the inspection archive.

**End of working paper v0.6**
'''
# Keep the opening boundary; let later sections flow to avoid near-empty pages.
first,*rest=text.split('<!-- PAGEBREAK -->')
text=first+'<!-- PAGEBREAK -->'+''.join(rest)
(ROOT/'output/Context_Parallax_v0.6_WORKING_DRAFT.md').write_text(text,encoding='utf-8')
(ROOT/'audit/SECTION_MAP.json').write_text(json.dumps({'source':'inherited-v0.5/Context_Parallax_v0.5_WORKING_DRAFT.md','source_sha256':hashlib.sha256(old.encode()).hexdigest(),'moved_sections':mapping,'other_sections':'Rewritten or condensed in main sections 1–11 and Appendix B; full v0.5 source remains included.'},indent=2),encoding='utf-8')
print(json.dumps({'words':len(text.split()),'main_words':len(text.split('## Appendix A')[0].split()),'appendix_sections':len(mapping)}))
