"""Assemble an explicit local inspection payload, extract it and verify it offline."""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import hashlib, json, re, shutil, subprocess, sys, zipfile

ROOT=Path(__file__).resolve().parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def main():
    direct=['START_HERE.md','CHANGELOG.md','WORK_KEY.md','CITATION.cff','LEAN_CLAIMS.md','LEAN_CLAIMS.json',
            'CLAIMS_AND_OPEN_ITEMS.md','SOURCE_CONCORDANCE.md']
    direct += ['output/Context_Parallax_v0.6_WORKING_DRAFT'+suffix for suffix in ['.md','.docx','.pdf']]
    audits=['ADDENDUM_INTAKE.json','ADDENDUM_REPLAY_BEFORE_LINUX.json','DOCUMENT_VERIFICATION.json',
            'DOI_RESERVATION.md','EVIDENCE_VERIFICATION.json','EVIDENCE_VERIFICATION_LINUX.json',
            'KEY_SOURCE_IDENTITIES.json','LOCAL_MODEL_HASHES.json','PORTABILITY_GUARDS.txt','PORTABILITY_REPAIR.json',
            'probe-branchline-qwen35-9b.json','probe-cpx06-qwen4b.json','probe-runpod.json','PROPOSED_KEY.md',
            'REVIEW_RESPONSE.md','SECTION_MAP.json','VISUAL_REVIEW.md']
    direct += ['audit/'+name for name in audits]
    direct += ['audit/pre-addendum/verify_evidence.py','audit/pre-addendum/EVIDENCE_VERIFICATION.json']
    files={ROOT/p for p in direct}
    for name in ['tools','studies','evidence','research','inherited-v0.5']:
        files.update(p for p in (ROOT/name).rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc')
    # This list contains authored source and synthetic records, not credential files.
    patterns=[r'rpa_[A-Za-z0-9_-]{20,}',r'sk-(?:proj-)?[A-Za-z0-9_-]{24,}',r'-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----']
    suspicious=[]
    for p in files:
        assert p.is_file(),p
        assert p.resolve().is_relative_to(ROOT.resolve()),'Path left workbench'
        if p.suffix in {'.json','.jsonl','.md','.txt','.py','.yaml','.yml','.csv','.cff'}:
            text=p.read_text(encoding='utf-8-sig')
            if any(re.search(pattern,text) for pattern in patterns):suspicious.append(p.relative_to(ROOT).as_posix())
    if suspicious:raise ValueError('Credential-shaped text requires inspection in: '+', '.join(suspicious))
    manifest={'version':'0.6','reserved_doi':'10.5281/zenodo.23306102',
              'created_utc':datetime.now(timezone.utc).isoformat(),
              'scope':'Local inspection companion. Integrity and replay are distinct from independent review, Lean proof and publication.',
              'exclusions':'Private conversations, full reviewer files, third-party PDFs, credentials, weights, temporary render images and live application state.',
              'files':[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(files)]}
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    dest=ROOT/'output/Context_Parallax_v0.6_Inspection_Package.zip'
    with zipfile.ZipFile(dest,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in sorted(files|{ROOT/'MANIFEST.json'}):z.write(p,p.relative_to(ROOT).as_posix())
    extraction=ROOT/'tmp'/('delivery-extract-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f'))
    extraction.mkdir(parents=True)
    with zipfile.ZipFile(dest) as z:
        for name in z.namelist():
            rel=PurePosixPath(name)
            assert not rel.is_absolute() and '..' not in rel.parts and '\\' not in name
            assert (extraction/name).resolve().is_relative_to(extraction.resolve())
        assert len(z.namelist())==len(set(z.namelist()))==len(files)+1
        assert z.testzip() is None
        z.extractall(extraction)
    run=subprocess.run([sys.executable,str(extraction/'tools/verify_package.py')],cwd=extraction,capture_output=True,text=True,encoding='utf-8',timeout=150)
    (ROOT/'audit/ARCHIVE_REPLAY.stdout.txt').write_text(run.stdout,encoding='utf-8')
    (ROOT/'audit/ARCHIVE_REPLAY.stderr.txt').write_text(run.stderr,encoding='utf-8')
    report_path=extraction/'tmp/PACKAGE_VERIFICATION.json'
    report=json.loads(report_path.read_text(encoding='utf-8')) if report_path.exists() else {'status':'FAIL','failure':'Package checker did not emit a report'}
    report.update({'zip':dest.name,'sha256':sha(dest),'bytes':dest.stat().st_size,'zip_entries':len(files)+1,
                   'uncompressed_payload_bytes':sum(p.stat().st_size for p in files),
                   'extracted_to':str(extraction.relative_to(ROOT)),'exit_code':run.returncode,
                   'no_credential_pattern_hits':not suspicious})
    if run.returncode:report['status']='FAIL'
    (ROOT/'audit/ARCHIVE_VERIFICATION.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    shutil.copy2(ROOT/'audit/ARCHIVE_VERIFICATION.json',ROOT/'output/Context_Parallax_v0.6_Archive_Verification.json')
    (ROOT/'output/SHA256SUMS.txt').write_text('\n'.join(sha(p)+'  '+p.name for p in sorted((ROOT/'output').glob('Context_Parallax_v0.6_*')))+'\n',encoding='utf-8')
    print(json.dumps(report))
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
