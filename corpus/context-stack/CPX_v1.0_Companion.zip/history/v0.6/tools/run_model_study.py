"""Bounded append-only inference. Credentials never appear in request receipts."""
from pathlib import Path
import datetime, hashlib, json, os, sys, time, tomllib, urllib.request, urllib.error
ROOT=Path(__file__).resolve().parents[1]; S=ROOT/'studies/maintain02'
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def read(p):return json.loads(p.read_text(encoding='utf-8-sig'))
def append(p,x):
 with p.open('a',encoding='utf-8') as f:f.write(json.dumps(x,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
def credential():
 key=os.environ.get('RUNPOD_API_KEY')
 if key:return key
 d=tomllib.loads((Path.home()/'.runpod/config.toml').read_text())
 def walk(d):
  if isinstance(d,dict):
   for k,v in d.items():
    if k.lower() in ['api_key','apikey','api_key_token'] and isinstance(v,str):return v
    if isinstance(v,dict):
     hit=walk(v)
     if hit:return hit
 key=walk(d)
 if not key:raise RuntimeError('Runpod credential absent from expected configuration.')
 return key
def request(url,payload,token=None,timeout=120):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request(url,data=json.dumps(payload).encode(),headers=headers)
 try:
  with urllib.request.urlopen(req,timeout=timeout) as r:return json.load(r)
 except urllib.error.HTTPError as e:
  raise RuntimeError(f'HTTP {e.code}: '+e.read(1000).decode(errors='replace')) from None
def reserve(ledger,amount,uid):
 rows=[json.loads(x) for x in ledger.read_text().splitlines()] if ledger.exists() else []
 # Completed requests replace their reservation with conservative reconciled charge.
 latest={r['id']:r for r in rows}; total=sum(r.get('accounted_usd',r.get('reserved_usd',0)) for r in latest.values())
 if total+amount>10:raise RuntimeError(f'Budget ceiling would be exceeded: {total+amount:.4f}')
 append(ledger,{'id':uid,'time':now(),'status':'RESERVED','reserved_usd':amount})
 return total
def reconcile(ledger,uid,amount,response):
 usage=response.get('usage',{}); tokens=usage.get('total_tokens',0)
 reported=response.get('cost')
 estimates=tokens*0.00001 if tokens else amount
 accounted=max(float(reported or 0),estimates)
 append(ledger,{'id':uid,'time':now(),'status':'RETURNED','reserved_usd':amount,'usage':usage,'service_cost_usd':reported,'token_rate_estimate_usd':estimates,'accounted_usd':accounted})
def cloud_payload(system,text,limit):
 return {'model':'Qwen/Qwen3-32B-AWQ','messages':[{'role':'system','content':system},{'role':'user','content':text}],
 'temperature':0,'max_tokens':limit,'chat_template_kwargs':{'enable_thinking':False},'stream':False}
def main():
 tag=sys.argv[1];(ROOT/'evidence/model').mkdir(parents=True,exist_ok=True)
 ledger=ROOT/'evidence/model/runpod-ledger.jsonl'
 url='https://api.runpod.ai/v2/qwen3-32b-awq/openai/v1/chat/completions'
 if tag=='probe':
  receipt=ROOT/'audit/probe-runpod.json'
  if receipt.exists():raise SystemExit('Probe already exists.')
  p=cloud_payload('Transport check only. /no_think','Reply with exactly READY.',32)
  amount=(len(json.dumps(p).encode())+32+128)*0.00001
  reserve(ledger,amount,'transport-probe-1')
  t=time.monotonic()
  try:
   r=request(url,p,credential());reconcile(ledger,'transport-probe-1',amount,r)
   out={'request':p,'response':r,'elapsed':time.monotonic()-t,'excluded_from_study':True}
  except Exception as e:out={'request':p,'error':str(e),'excluded_from_study':True}
  receipt.write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out));return
 config=read(S/'protocol.json');pins=read(S/'FREEZE.json')['sha256']
 for name,digest in pins.items():assert hashlib.sha256((S/name).read_bytes()).hexdigest()==digest,name
 spec=config['models'][tag]; cloud=spec['provider']=='runpod'
 token=credential() if cloud else None
 rows=[json.loads(x) for x in (S/'prompts.jsonl').read_text(encoding='utf-8').splitlines()]
 target=ROOT/f'evidence/model/{tag}.jsonl'
 old=[json.loads(x) for x in target.read_text(encoding='utf-8').splitlines()] if target.exists() else []
 completed={x['id'] for x in old if x['final']}; streak=0
 for n,row in enumerate(rows,1):
  if row['id'] in completed:continue
  if cloud:payload=cloud_payload(row['system'],row['input'],config['max_output_tokens'])
  else:
   payload={'model':spec['model'],'system_prompt':row['system'],'input':row['input'],'temperature':0,'max_output_tokens':256,'store':False}
   if spec['reasoning']:payload['reasoning']=spec['reasoning']
  for attempt in range(2):
   rid=f'{tag}-{row["id"]}-{attempt}'
   reservation=(len(json.dumps(payload).encode())+256+128)*0.00001 if cloud else 0
   if cloud:reserve(ledger,reservation,rid)
   t=time.monotonic(); out={'id':row['id'],'tag':tag,'attempt':attempt,'time':now(),'request':payload}
   try:
    response=request(url if cloud else 'http://127.0.0.1:1234/api/v1/chat',payload,token)
    out.update(response=response,final=True)
    if cloud:reconcile(ledger,rid,reservation,response)
    streak=0
   except Exception as e:out.update(error=str(e),final=attempt==1)
   out['elapsed_seconds']=time.monotonic()-t;append(target,out)
   if 'response' in out:break
  if 'error' in out:streak+=1
  if n%12==0 or 'error' in out:print(json.dumps({'model':tag,'completed':n,'of':len(rows),'error':out.get('error'),'last_seconds':round(out['elapsed_seconds'],2)}),flush=True)
  if streak>=3:raise SystemExit('Three consecutive transport failures; model stopped per protocol.')
 print(json.dumps({'model':tag,'status':'DONE','count':len(rows)}),flush=True)
if __name__=='__main__':main()
