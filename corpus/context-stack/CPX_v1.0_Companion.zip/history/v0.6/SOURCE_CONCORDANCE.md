# CPX v0.6 source entry points

The canonical current paper is `output/Context_Parallax_v0.6_WORKING_DRAFT.md`. Its claim cards pin exact paragraphs and its SHA-256. The DOCX and PDF are checked against that text. The reserved DOI is recorded in `audit/DOI_RESERVATION.md`.

- **Inherited sources and evidence:** `inherited-v0.5/SOURCE_CONCORDANCE.md`; source manuscript and selected historical evidence are retained. Relative historical paths resolve inside that subtree. Private or excluded antecedents are identified, not made inspectable by their hashes alone.
- **New focused primary reading:** `research/REVIEW_READING.md`, with six bounded reading scopes and an operational Runpod pricing source. No systematic novelty clearance is claimed.
- **Six initial model reviews:** identities in `audit/KEY_SOURCE_IDENTITIES.json`; dispositions and different inspection scopes in `audit/REVIEW_RESPONSE.md`. Full review texts remain outside the portable companion.
- **Late companion addendum:** `audit/ADDENDUM_INTAKE.json` pins the complete supplied Markdown. Its review is of v0.5. Its separate code/patch/raw-report bundle was not supplied. Our Linux failure reproduction and repair are separate author artifacts.
- **Old-to-new prose mapping:** `audit/SECTION_MAP.json`; the full v0.5 Markdown remains available alongside the adapted Appendix A passages.
- **New model evidence:** `studies/maintain02/FREEZE.json`, exact request/response JSONL, analysis, strict and supplementary scores in `evidence/model`. Historical filenames and NOT_RUN fields describe their own studies.
- **New finite computations:** `evidence/review/channel-counterexamples.json` and `paired-chains.json`; offline replay reconstructs these from retained finite inputs.
- **Local model identities:** `audit/LOCAL_MODEL_HASHES.json`. Hosted model label and provider usage are recorded, but no immutable hosted weight identity is asserted.

The inspection manifest identifies delivered bytes. Source identity, semantic adequacy, experimental performance, independent review and action permission remain distinct.
