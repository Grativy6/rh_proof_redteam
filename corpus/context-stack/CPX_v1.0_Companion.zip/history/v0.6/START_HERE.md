# Context Parallax v0.6

**Working paper and inspection companion. Reserved DOI 10.5281/zenodo.23306102.** Chris supplied this reservation; no upload or publication occurred in this run.

Start with `output/Context_Parallax_v0.6_WORKING_DRAFT.pdf`. The editable DOCX and canonical Markdown have the same stem. Sections 1–11 give the main argument; Appendix A preserves selected development history and adopted vocabulary. The source map retains their original section addresses.

## The result

We completed **432 scientific model calls** on twelve previously inspected fictional cases. Qwen3 4B scored 140/144 and Qwen3.5 9B scored 144/144 on the frozen JSON-and-choice endpoint. The hosted Qwen3 32B returned its JSON in Markdown fences, making its strict score 0/144. An explicitly post-hoc removal of those wrappers gives 140/144. Both scores and all raw responses remain visible.

**Plain guidance and recipient-frame guidance selected the same answer in every matched pair for each model. No framing advantage was demonstrated here.** This was a short recognition task with supplied answer alternatives, not an independent held-out or free-response study. The model configurations differ in more than size. The two imperfect configurations failed different receipt-only cases; the 4B could select a hidden-true answer without the supplied summary warranting it.

Runpod reported **USD 0.54451** including its excluded transport probe. All reservations settled; **USD 9.45549** of the total USD 10 ceiling was unused. No paid pod, volume or persistent endpoint was created. The task-loaded local 4B was unloaded afterward; the previously running personal models were left in place.

## Inspection route

- `audit/REVIEW_RESPONSE.md`: disposition of the six repair groups and the late companion addendum, reviewer scopes and remaining limits.
- `studies/maintain02`: frozen paired prompts, models, scoring contract and pre-outcome hashes.
- `evidence/model/analysis.json`: complete outcome tables and cost reconciliation. The neighboring JSONL files preserve requests and responses; `scored.json` preserves strict and supplementary scores separately.
- `evidence/review`: two independently reconstructed equal-accuracy counterexamples and paired summaries of the unchanged teaching simulation.
- `inherited-v0.5`: original paper, finite method, historical studies, original and corrected toy runs, source concordance and research notes.
- `LEAN_CLAIMS.md` and `.json`: four exact source-bound targets for the later formal companion. **No Lean run is claimed.**
- `audit/DOCUMENT_VERIFICATION.json` and `audit/EVIDENCE_VERIFICATION.json`: artifact checks with their scope and limits.

The 32B formatting diagnostic was added after inspecting its responses. Its strict score was not replaced. The explanation-review queue is prepared for a later reader; it is not a completed independent rating study. Original study IDs retain their own NOT_RUN status; the new recognition study does not complete their broader designs.

## Offline replay

From an extracted package, run:

```text
python tools/verify_package.py
```

Use Python 3.11 or newer. This entry point uses the standard library, checks every manifest file and the final claim-source bindings, then replays finite record checks, corrected foundation and witness experiments, new channel examples and paired summaries. It checks the retained model records without contacting a provider. Replay files go into `tmp`; original evidence remains unchanged. It never executes `run_model_study.py`. Historical prompt generation is also replayed: each manifest must match its own files, then corresponding JSON records must agree. Received archive hashes stay exact. Only the two log-derived information columns and the two new channel-information values allow absolute error of 1e-12 bits (zero relative tolerance, nonfinite rejected); all other replay values remain exact. This policy was added after the companion addendum exposed the platform-comparison defect. `audit/ADDENDUM_REPLAY_BEFORE_LINUX.json` retains our failed run; Windows and Linux final receipts retain the repaired results. The separate reviewer patch and raw review bundle were not supplied.

Rendering the DOCX is a separate optional operation needing python-docx, a document renderer and appropriate fonts. PDF text inspection uses pypdf. The delivered rendering was visually inspected page by page; replaying file hashes does not repeat that inspection. One observed PDF extraction quirk for the printed name Daumé is documented explicitly in the document receipt.

The original model execution code is included for methodological inspection. It is **not** an invitation to spend: a new model run needs its own authority, credentials and resource ceiling. The old proposed key and its exclusions are historical; `WORK_KEY.md` records Chris's subsequent experiment authorization and total USD 10 amendment.

## Limits and next seam

The review repairs and bounded feasibility study are complete. Framing benefit, autonomous retrieval, free-form expression, independent human reception, causal model-size effects and the whole-language benefit hypothesis remain open. No training or Branchline changes were made.

The portable package excludes full private conversations, full reviewer texts, third-party PDFs, credentials, model weights and render images. It retains source identities and scope-qualified references. The next formal task can use the four stable cards; the next empirical task should use fresh independent cases and a clearer output contract.
