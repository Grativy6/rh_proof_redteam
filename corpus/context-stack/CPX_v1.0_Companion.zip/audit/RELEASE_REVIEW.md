# CPX v1.0 publication review

12 October 2026. Hearthline publication self-review under CPX-PUB-01.

The reviewed edition is a 35-page research preprint. It incorporates the completed Lean companion into the v0.6 scientific account and supplies portable evidence entry points. Chris selected CC BY 4.0 for original release material. The human author and steward and the named AI collaborator remain separately credited.

## Scientific preservation

- All 37 key-pinned source files remain unchanged. All 281 files carried from the v0.6 inspection archive remain byte-identical at their documented new paths. Historical PDF and Word editions are omitted to avoid duplicate renderings; the controlling Markdown is retained.
- All five controlling mathematical passages remain verbatim, and all nine earlier tables retain their cells. The added table records formal coverage. The paper states the rational-value and finite-sequence limits beside the corresponding formal claims.
- A fresh replay from an extracted candidate compiled the six Lean units, printed the 33 selected statements and their axiom dependencies, and passed the five module kernel checks. The final delivered proof sources, reporting sources, dependency pins and three controlling inputs are identical to those used in that replay. Cached imports remain trusted.
- A separate publication source review checks the correspondence of the new summaries with the original theorem registry and source-to-formal review. This is self-review, not independent referee validation.
- Offline finite replay passed 47 retained evidence checks and 13 portability guards. Re-scoring all 432 saved responses reproduced the original results and review order. No new model calls were made. The null matched-framing contrast, strict versus post-hoc scoring distinction, adverse results, failed attempts and historical unrun designs remain visible.

## Reading edition

All 35 candidate pages were visually inspected. Native Word equations, ten captioned tables, linked contents, reference navigation, text correspondence and publication identifiers passed their checks. Two unchanged occurrences of an accented surname use a different font so the PDF also preserves searchable text.

Only two edition-label lines changed after those checks: the opening now says research preprint and the closing carries the final date. Final rendered pages 2–34 were pixel-identical to the reviewed candidate; final pages 1 and 35 were inspected again. The final text, native equations and links were checked again after rendering. The exact Markdown, Word and PDF identities are in `DOCUMENT_VERIFICATION.json`.

## Package and limits

The current archive inventory is `MANIFEST.json`. Run `python tools/verify_package.py` from the extracted package to verify it and replay the finite computations without credentials, models or network access. The retained candidate replay records in `publication-replay/` identify the earlier candidate on which they ran; they are not represented as a receipt for the final ZIP. The final ZIP's extraction and verification receipt is supplied alongside the upload files to avoid a self-referential archive hash.

Release checks found no excluded model artifacts, caches, full private conversations, third-party reading PDFs or credential signatures in the payload. Historical records retain declared source locators and their original status. Only the matching-cache formal replay route was tested; fresh network acquisition of Lean dependencies was not tested.

No new independent human review, free-response study, autonomous retrieval trial, broad language-welfare result or full-manuscript formal proof is claimed. Publication readiness describes this edition and its inspectable evidence. It does not change those research limits.
