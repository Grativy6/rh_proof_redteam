# Claim and evidence map — CPX v0.5

Status: self-reviewed working paper. This map separates elementary implications, executed local evidence, development observations and proposed behavioral work. Artifact verification does not promote one class into another.

| Claim | Manuscript | Evidence | Status and reopening condition |
|---|---|---|---|
| A frame can change what is elicitable without establishing prior hidden recognition | §§1, 4–5 | Inherited method and neighboring probe literature | Methodological distinction; behavioral benefit NOT_RUN |
| Pinch is an event; inflection is carried change; seed is a possible further beginning | §§6–7 | C1 adopted correction and artifact use | Operational vocabulary; not a new learning law |
| Carried availability, current engagement and expression differ | §§9–10 | C2; human-memory neighbor L12 | Proposed observation discipline; not literal compartments |
| Author credit changed in two recorded places | §11 | Inherited D1 record and before/after identities | Inherited artifact result, not fresh long-term behavior evidence |
| Reconstruction can implement continuity; derivation, fidelity and later use differ | §12 | C6 review; existing carriage method | Refined functional proposal; no identity/consciousness determination |
| Same protected projection preserves queries that factor through it | §13 | Substitution; S1 | Elementary conditional implication |
| Capsule decoder exists iff no equal capsule merges differing protected answers | §13 | Finite fiber argument; S5 | Elementary criterion; no universal compression rate |
| Original synthetic checker passes 93, baseline agrees on 64 combinations | §16 | `audit/record-checks`, unchanged method | Replayed in v0.5; finite data only |
| Whole-language balance must include outsiders, horizons and alternatives | §17 | C5; R01–R05 | Definition required to test the original hypothesis; not settled |
| Information, correct decoding and listener payoff can separate | §18 | E1 1,008-row exact binary grid | Stipulated binary task, not animal/model observation |
| Listener threshold follows from expected payoff | §18 | Algebra in `research/foundation-FOUNDATIONS.md` | Conditional on known probabilities, payoff and alternative |
| Participant-compatible use can have negative total welfare | §19 | E1: 1 + 0.9 − 3 = −1.1; 288-case sweep | Whole-world countermodel to uptake inference; no persistence theorem |
| Every affected party's informed zero-baseline veto implies nonnegative sum | §19 | Addition of nonnegative returns | Conclusion encoded in premise; not discovered benevolence |
| Repair sometimes preserves more labels and sometimes fails or costs too much | §20 | E1 final run-002 and cost_effects.csv | 960 seeded chains; conditional program results |
| Bijection has full capacity despite original naming drift | §20 | Learner definition, oracle decoder | Capacity guaranteed by construction, not learned receiver skill |
| Initial bijection results leaked original assignments | §20 | run-001, old code, RUN_HISTORY.md | Retained implementation defect; run-002 used for claims |
| Identical observational distributions can yield different intervention effects | §21 | E2 causal_worlds.csv; R06 | Elementary stipulated counterexample |
| Diagnosis may change action, be too costly, miss the objective or lack an action | §21 | E2 exact grid and named cases | One-step known-model decision toy; exit and later learning omitted |
| Free optional information cannot reduce an ideal chooser's value under fixed premises | §21 | Elementary constant-action proof | Optimizer property, not measured agent reliability |
| Resolution is question-relative under compatible worlds and assumptions | §22 | Singleton answer-set definition; E2 | Proposed account, empty world set is inconsistency |
| Home does not depend on finishing an endless task | §23 | Earlier adopted design commitment | Normative/workflow commitment, not an empirical result |
| Compact answer support and a reason to reopen can separate | §§24–26 | Development records and proposed retrieval comparisons | Actual recognition/handle selection NOT_RUN |
| 12 cases × 3 carries × 4 arms yields 144 prepared prompt records | §27 | E3 fixtures, prompts and manifest | Design preparation; zero model calls |
| A/B evidence and C/D evidence match within each cell | §27 | E3 checks.json | Structured inspection, no frame-effect finding |
| Baseline supports 10 full, 6 receipt, 6/10 handle cases by arm | §27 | E3 baseline.json | Declared fact-ID coverage, not semantic understanding |
| The broad language-benefit hypothesis and CPX advantage remain open | §§17, 28 | Limits of all evidence above | Needs scoped empirical design and independent criticism |

## Study register

| Study | Executed portion | Remaining status |
|---|---|---|
| Original finite record suite | 93 checks; six separate analysis checks | Not a model study |
| Foundation run-002 | 1,008 binary cases; 288 welfare cases; 960 chains / 38,400 rows; 21 checks plus 1,554 occupancy sequences | Completed toy study, initial defective run retained |
| CPX05-WITNESS-01 | 288 exact decision rows; 16 causal distribution rows; 21 categories / 1,932 assertions | Completed toy study, cultural transmission not modeled |
| PARALLAX-EXPR-01 | No outcomes | NOT_RUN; candidate 864 calls, smaller feasibility 72; not authorized here |
| PARALLAX-RETURN-01 | No outcomes | NOT_RUN; full call graph unset |
| Carriage / correction extensions | Design only | NOT_RUN; separate from original counts |
| PARALLAX-REOPEN-01 | Sketch only | NOT_RUN; no autonomous lookup evidence |
| CPX-MAINTAIN-01 | Fixtures, 144 prompt records and 195 preparation checks | MODEL_NOT_RUN; live model/cost/scoring contract not frozen |
| Diagnostic-selection study | Proposed question only | NOT_RUN |

## Smallest live research seam

Have a second reader inspect the new argument and the twelve fictional support contracts. Then choose one bounded pilot and fix the missing run/scoring details. Do not merge all inherited proposals into a larger prerequisite. No paid execution, publication, human recruitment or model training is implied by this manuscript.

Publication judgment: ready for review; not yet ready for a claim of model effectiveness or a general welfare law. A conceptual/finite-model publication still needs an independent critical read and final author adoption. Chris remains human author and steward.
