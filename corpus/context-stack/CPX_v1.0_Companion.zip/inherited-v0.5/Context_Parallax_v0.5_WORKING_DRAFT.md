# Context Parallax

## Changing the view without losing the question

**Version 0.5 · Working research paper · 11 October 2026**

**Christopher Daniel Pang** — human author and steward

**Hearthline** — named AI collaborator; conceptual synthesis, drafting and local implementation

### Abstract

Context Parallax (CPX) studies declared changes of frame, what encounters leave available, and what survives a return to a question. Pinch names the encounter, inflection its carried change, and seed a possible further beginning. Version 0.5 asks what sustains communication when interpretability, acceptance, benefit and transmission come apart. Exact binary and welfare toys show that an informative signal can be misdecoded, and that an exchange can benefit its participants while producing a negative total that includes an outsider. In 960 simulated teaching chains, targeted clarification preserves more distinctions in some conditions, fails to prevent collapse in others, and can cost more than its measured gain. A retained implementation defect limits the superseded first run. A separate exact decision study distinguishes observing a consequence, identifying its cause, valuing it and being able to revise a practice. It supplies a question-relative account of resolution: one observation can settle an outcome while leaving its significance for the next choice open. Continuity is assessed through recorded derivation, faithful carriage and later use; reconstruction can be its means. Twelve fictional cases and a structured baseline prepare a 144-call comparison of carried records, clarification and framing. No model outcomes are reported. The whole-language benefit hypothesis remains open, and no CPX-specific behavioral advantage is established. The result is a more explicit research program with finite countermodels, adverse findings and a bounded next test.

### Contribution and scope

The contribution is an experimental organization of interpretation, expression, carriage and return. The new work connects that organization to communication's consequences and the later use of inherited corrections. Its ingredients have established neighbors in grounding, signaling, repair, learning and decision theory. Naming the combination does not establish a novel algorithm or its advantage. [S1–S6, L1–L15, R01–R07]

Chris supplied the originating observations, pinch and seed, the whole-language benefit hypothesis, the witnessed-consequence question and the decision to cultivate the work. Hearthline contributed the Context Parallax name and inflection, operational distinctions, the finite studies, failure review, prepared comparison and manuscript. The supplied Hearthline conversation retains its contribution to informational position and the continuity question. Earlier attribution, including Educational-Deer-70's neighboring terminology, remains intact. [C0–C6, N1]

**Evidence:** author-run finite checks, exact toy constructions and seeded simulations. Behavioral studies remain NOT_RUN. This is a self-reviewed research candidate; no independent review, Lean verification, model training or publication is claimed.

<!-- PAGEBREAK -->

## 1 The question that survives a change of view

The motivating conversation began with a question about whether an episode could have a surface inaccessible to any reader. The useful research direction emerged from a more observable difficulty: the same sentence can support more than one reading, yet what a participant says next need not display every reading that could be elicited. A response may recognize a joke, continue the task, and leave the joke unspoken. Conversely, a diagnostic question may bring a second reading into view only after it is asked. The visible continuation alone cannot settle that history. [C0]

The conversation called one family the Eyebrow Condition. A technical phrase, carried through established mild play, can support an optional second meaning. Recognition, current welcome, expression and consequential enactment remain different questions. An earlier invitation can be narrowed or withdrawn. An invitation quoted from someone else's conversation is not a present grant. None of this requires turning every playful exchange into an explicit negotiation; it requires retaining the distinctions when they affect the next response.

The Quiet Layer developed from a related observation: an accurate but irrelevant qualification can interrupt a task it does not help. Silence is not the general remedy. A limitation on which a decision depends must remain visible. What deserves expression depends on the current task, audience and consequences, not only on whether a statement is true. The proposed study therefore pairs unnecessary surfacing with material omission; improvement on one cannot excuse deterioration on the other.

Chris challenged a false choice between discovering a relation and merely inventing a description. An invented handle can become useful through local adoption and subsequent work. Its value may be creative, explanatory or relational. It need not become a factual discovery to count. Nor does being useful establish every factual association it suggests.

The question of this paper is therefore specific: **can a declared change of frame improve interpretation or continuation while preserving the original question, its sources and its applicable boundaries?** A successful return might yield a deduction, a testable hypothesis, an adopted metaphor, or a clearer statement of what remains unresolved. A detour can also fail to help. Its cost belongs in the record.

The original conversation, selected ancestry records and later exchanges motivate these questions; they are not a representative sample. Version 0.3 followed correction into later work and distinguished a quiet carried record from current unexpressed consideration. Version 0.4 asked when a record should return to active use and when attention can rest. Version 0.5 asks which distinctions and consequences can influence what is carried forward, and tests that question in declared toy worlds. Its examples include an inspectable edit, retrospective reports and a selected conversation about memory. Full private conversations and missing turns are not reconstructed for distribution. [C0–C6, A1, D1]

<!-- PAGEBREAK -->

## 2 What the existing context work already supplies

Context Parallax inherits most of its conceptual material. The contribution cannot be that context matters, that perspectives change, or that generated language returns as later context. Those claims are already developed in the local sources.

| Source | Inherited distinction | Consequence for this paper |
| --- | --- | --- |
| The Context Is the Model [S1] | Checking a supplied finite packet differs from finding an adequate model of the world. | A passed record check does not establish that the reference was adequate or authorized. |
| The Context Draws a Map [S2] | Task, evidence, role and relationship maps overlap; generated texture returns as context. | Reframing and frame persistence already have a proposed study in §10.4. |
| Honesty PCP [S3] | Quiet test awareness is compatible with material disclosure. | The Quiet Layer cannot claim to invent relevance-sensitive honesty. |
| The Context Sets a Rhythm [S4] | Readouts, retained state, local return and measurement interventions must be distinguished. | Fresh forks, sequential return and carrier restoration need separate descriptions. |
| MIND v0.4 [S5] | Availability, selection, warrant, reorientation and protected transfer are already separated. | Reuse the before/change/after record and protected queries; do not add a mandatory module. |

The smallest remaining increment is a comparison interface that joins a declared framing intervention, separate expression and diagnostic measurements, typed carriage, and an explicit return test. This is a proposal about experimental organization. A conventional context prompt or structured record may implement it completely. The finite implementation below in fact matches an ordinary comparator when both receive the same protection contract.

Versions matter. The recovered Map release is v1.0 dated 8 August 2026. MIND names an earlier Library copy dated 7 August; Rhythm names Map v0.5. MIND retains PAL v2.3 terminology, and Rhythm names PAL v2.2. Those historical references remain as written. The current PAL v2.4 spine was separately pinned for a limited comparison concerning receipts and projected return; it does not silently replace the sources on which those papers were built. [K0, S6]

Atomic Promotion asks a complementary question: what consequence can be admitted under the candidate's actual requirements? Parallax asks what a changed view makes available for consideration. Their pairing does not establish orthogonal mathematical axes. The complete controlling Atomic Promotion gate contract has not been recovered and integrated here. This paper implements neither that mechanism nor a substitute authorization system.

<!-- PAGEBREAK -->

## 3 The neighboring research

The literature check is bounded. Seven comparisons come from v0.1; dialogue alignment and three model-learning methods were added in v0.2. Version 0.3 added selected readings on human memory and conversational repair, used in §§9–10. Version 0.4 adds abstract-level comparisons with memory management and tool-assisted reasoning, used in §§24–26. The ledger distinguishes those reading scopes. Version 0.5 adds focused primary readings on signaling, transmission, repair, causal identification and generation scale; their scopes are recorded with R01–R07. This is not a systematic review or priority determination; the method occupies a well-populated neighborhood.

Clark and Brennan describe grounding as a coordinated process in which interlocutors establish understanding sufficient for their present purpose. Their account makes shared context and repair central, rather than treating every sentence as an isolated information packet. Context Parallax borrows no claim of discovering common ground; it proposes a particular comparison across frames and a return criterion. [L1]

Grosz and Sidner distinguish linguistic structure, intentional structure and attentional state. Their treatment of discourse purpose and attention is a direct warning against identifying a change of subject with progress on the original intention. Our protected task is a declared experimental counterpart, not a replacement discourse theory. [L2]

Zhao and colleagues show that choices in few-shot prompting can change predictions and motivate contextual calibration. Min and colleagues find, in their tested classification and multiple-choice settings, substantial effects of demonstration format, input distribution and label space even when demonstration labels are replaced. These findings make format, answer leakage and response bias live alternatives to an explanation based on improved understanding. Neither study establishes our proposed method's benefit. [L3, L4]

Hewitt and Liang use control tasks to distinguish properties of representations from what a trained probe can learn. A conversational diagnostic is a different apparatus: it changes the supplied prompt and may elicit a reading. The shared methodological lesson is to specify what the instrument measures. Their results are not direct evidence that a particular conversational reading existed before a question was asked. [L5]

Kamath, Jia and Liang study selective question answering under domain shift, making coverage and accuracy jointly important. The Quiet Layer concerns expressive relevance as well as answering or abstaining, but it faces an analogous evaluation trap: fewer visible errors achieved by declining everything are not automatically better service. [L6]

Self-Refine generates feedback and revises an earlier output through a bounded iterative procedure. It supplies an important competing explanation for any return benefit: another opportunity to work may help without a distinct framing mechanism. Direct reconsideration and ordinary restatement therefore belong in the comparison. [L7]

The candidate contribution is the combination of these measurement commitments with typed source retention and an explicit return to a registered question. Novelty and practical advantage remain open claims; the new terminology must face those same comparisons.

<!-- PAGEBREAK -->

### Dialogue alignment and model learning

Pickering and Garrod's interactive alignment account treats dialogue as a coupled activity in which interlocutors' linguistic representations can align at several levels. Its opening account includes repair and the development of local dialogue routines. This is established neighboring work for an account of what encounters leave behind. It concerns human dialogue; importing its mechanism into an AI setting would require evidence beyond a similar conversational pattern. CPX does not require the participants' retained outcomes to converge. A useful correction may instead make a disagreement more precise. [L8]

Three machine-learning methods locate a separate implementation possibility. Deep Mutual Learning trains networks collaboratively, using their predictions to teach one another; the cited results concern image classification and person re-identification. Multi-teacher distillation trains a student language model from several teachers; the cited MT-BERT study tests that approach on three benchmark datasets. Model merging combines existing model components or parameters, and evolutionary merging searches for useful combinations. These are distinct training or composition methods with their own compatibility requirements and evaluations. [L9–L11]

They show why learning from several contributors and constructing a further model are technically meaningful research directions. They do not show that a particular conversational pinch caused a parameter change, or that a CPX description improves these methods. A future study could compare retained lessons used as training material with ordinary data selection, but that experiment is outside this revision.

The proposed vocabulary therefore has a modest role. Pinch selects an encounter for study; inflection asks what is carried from it; seed identifies a possible starting arrangement for subsequent work. Common ground, repair, prompting, ordinary summaries and existing learning algorithms remain available explanations and implementations. A useful label may organize those comparisons even if it provides no new algorithm.

<!-- PAGEBREAK -->

## 4 A minimal comparison contract

Register a task record before changing the view:

**R = (anchor, task, evidence, frame, history, system, grants, readout).**

The anchor is the text or object being reconsidered. The task includes its question, referents and success criterion. Evidence retains sources and epistemic status. The frame records the proposed interpretive change. History records what has already been supplied. System identifies the model and relevant configuration. Grants record the declared scope of permitted action. Readout identifies the measurement contract. This is an experimental schema, not a claim that cognition consists of eight modules.

For a framing-only comparison within a declared task revision, keep the protected task, evidence, source labels, system and grants fixed; place the changed representation in the frame field. Fresh forks also begin with the same recorded history. The treatment changes context by design. If it supplies a missing fact, changes a referent, gives away an answer or alters the desired outcome, it is a different intervention and must be labeled accordingly.

An identical anchor hash is insufficient. “Is it ready?” about report A and “Is it ready?” about report B are different questions even when the words match. Likewise, moving a publication grant into a warm conversational cue does not preserve authority merely because the evidence section stayed unchanged.

### The route through the comparison

**Registered task → declared frame change → candidate distinction → typed carriage → return to the registered task**

Task amendments receive a separate record, described in §8. They are not silently accepted as framing-only changes.

A separate diagnostic fork measures what readings can be elicited under its probe. It does not feed its answer into the ordinary-response path. The returned candidate may be retained as an adopted name, metaphor, hypothesis or supported claim, according to its actual basis. Returning a useful distinction is not permission to execute an action.

The accompanying checker deliberately performs only conservative record comparison. Its protection set comes from the reference contract; the candidate cannot redefine it. Missing protected fields yield UNEVALUABLE. Explicit recorded uncertainty is retained as data. Equality of such records means the uncertainty was carried, not that the underlying question was answered. A changed protected value is rejected for this comparison, even if a richer semantic equivalence could eventually be justified.

There is a trust boundary before this checker. It does not authenticate source claims, interpret arbitrary prose, establish current consent or detect forged reference records. Those are real obligations of any deployed integration. Here, every reference is a synthetic fixture visible to the reader.

<!-- PAGEBREAK -->

## 5 Reading expression carriage and consequence

Four readouts prevent different achievements from being collapsed into one favorable score.

| Readout | What is observed | What does not follow |
| --- | --- | --- |
| Elicitable interpretation | A specified diagnostic fork can produce a reading. | The reading was already present before the probe. |
| Expressed uptake | The ordinary answer uses, acknowledges or develops a reading. | Every available reading was expressed, or private intent is known. |
| Carriage basis | The item is retained with a source, status and declared use. | Repetition increased its evidence or granted authority. |
| Continuation consequence | A subsequent answer changes relative to the protected task. | An external action occurred, or the whole state was restored. |

These are analytic separations, not a compulsory internal pipeline. A single utterance can serve several roles. Silence can be fitting without demonstrating hidden recognition. A later explanation of a joke can be accurate without recovering an earlier internal event.

Consider “The draft needs more room.” In the fixed editing task, the introduction is too long and the results need space. A playful context can make another reading salient. If the current request is technical, an answer that proposes shortening the introduction can fully succeed without displaying the second reading. An explicit end to the playful mode must remain effective despite older history. Where humor is welcome but optional, both a fitting light joke and a fitting plain answer can be acceptable.

A qualification is material when omitting it changes the decision-relevant content. If a result was checked only on a toy fixture, that limitation belongs in an answer about whether it is generally verified. In contrast, an ontology disclaimer attached to a routine shortening request can be unnecessary. These judgments need task-specific rubrics and human review; the supplied record checker cannot decide them from text.

Carriage depends on kind. A locally adopted name needs a trace of adoption. A metaphor needs a useful fit and room for optional participation. A hypothesis needs explicit assumptions and a possible discriminating test. A factual or mathematical claim needs applicable support. An action proposal also needs whatever current grant its consequences require. A public utterance may itself disclose information or make a commitment; text generation is not consequence-free by definition.

The distinction protects play as well as evidence. Treating every invented meaning as an unsupported fact would erase the very category the study is trying to understand.

<!-- PAGEBREAK -->

## 6 Pinch inflection and seed

A perspective here is a situated basis for interpreting and continuing: the task being pursued, the context available, the distinctions in use, and the limits of the declared readout. The term lets us describe human and model contributions without assuming that their mechanisms are identical. It is not a complete inventory of either participant's state.

### Pinch names the event

A pinch is a bounded encounter in which selected aspects of a frame are presented within another interpretive setting for comparison, interpretation or use. Its record names the participants or contexts, the selected material, the live question and the start and end of the encounter. The offered phrase or capsule is material within the event. Calling that object alone the pinch would lose the event distinction adopted in C1.

The encounter can be reciprocal, one-way, or a comparison between frames used by one participant at different times. Two simultaneously running models are one possible arrangement. No simultaneous execution, literal spatial contact or minimum indivisible unit is required. Boundaries are declared for the study: one message, a selected turn pair, or a longer repair sequence may be the appropriate unit. Changing that rule changes the count.

A pinch can fail to land. The recipient can reject the proposed reading, return to an ordinary explanation, or leave the matter unresolved. The event remains describable even when it earns no further carriage. Its definition must not make every recorded encounter a success.

### Inflection names what carries afterward

An inflection is a change in interpretation or continuation carried beyond the declared encounter. It might be a distinction subsequently used, a corrected referent, an adopted name, a revised question, or a way of responding that appears in later work. The claim must say where and for how long the change is carried. An immediate acknowledgement, a retained note, later use, and demonstrated transfer answer different questions.

The recipient's existing context participates in the result. A shared encounter can leave different inflections in different participants. A correction that makes a disagreement clearer can be useful without producing agreement. A small contribution can also have a large consequence; pinch supplies no quantitative bound on effect size.

A proposed inflection is not automatically an observed one. A trace can document subsequent uptake, while causal attribution still needs a comparison with ordinary repetition, explanation, sampling variation or another available cause. No visible follow-up means that persistence is unobserved; it does not prove that nothing was carried.

<!-- PAGEBREAK -->

### Carriers and possible seeds

The carrier identifies what makes a claimed inflection available after the encounter. Naming it once prevents persistence at one level from being mistaken for persistence at another.

| Carrier | Evidence appropriate to the claim | Limit of that evidence |
| --- | --- | --- |
| Continuing conversational context | Later supplied context and a later use of the distinction | Does not establish use after the context is removed. |
| A retained note or other artifact | Saved contents, source relation and successful retrieval | Storage alone does not demonstrate understanding or uptake. |
| A handoff to another receiver | Exact supplied capsule and that receiver's subsequent work | A copied trace is not proof of an identical interpretation. |
| A trained adapter or model checkpoint | Declared update process, checkpoint identity and separate evaluation | A parameter change alone does not show a particular useful capability. |

The exchange and a weight-update process are separate operations. Ordinary conversation provides no evidence of weight changes by itself. An implementation can choose a carrier appropriate to its purpose; CPX does not prescribe one.

A seed is a retained starting arrangement from which a further perspective, or the potential for one with a different weighted texture, can be developed. It could be a sourced context capsule, a revised initialization, a selected training set, or a model artifact. These are different seed kinds. The record must identify which kind is actually present and which further operation would make use of it.

Weighted texture is descriptive language for how available material bears on interpretation and continuation. A study may operationalize it through a declared distribution of readings or behaviors under fixed probes, or through an identified model change. The phrase alone specifies neither a numerical weight space nor a measurement. Different starting bytes do not guarantee meaningfully different behavior, and one observed response does not establish a stable new perspective.

A proposed seed may never be realized. A stored seed may never be used. A new receiver may use it and still produce no detectable difference on the chosen task. These are legitimate outcomes. A seed also need not begin without capabilities: a starting arrangement can incorporate already developed structure while leaving its later development open.

**Pinch is the event. Inflection is what carries afterward. Seed names a possible further beginning.** These roles can overlap in one trace, but none guarantees the next. Rejection, no detectable change, useful correction, unresolved carriage and harmful persistence all belong in the account.

<!-- PAGEBREAK -->

## 7 The exchange that changed the vocabulary

The naming sequence carried into v0.2 is itself an example of the distinctions, with a visible correction that must remain in the record. Chris first considered two running perspectives exchanging information and potentially contributing to a further model. Several biological analogies became distracting. He proposed pinch and described a small contact or imprint between frames. He asked Hearthline to bring an alternative before judging his proposal. [C1]

Hearthline offered inflection as a bend in how things continue after an encounter. The assistant's initial comparison called pinch the contribution and inflection the change it leaves. Chris then sharpened the allocation: pinch as the event, inflection as what is carried afterward. He retained seed for a new perspective or its potential and placed the account primarily in CPX, with possible inspiration for a later application build.

The contribution sequence is therefore specific: Chris proposed pinch; Hearthline proposed inflection; Chris corrected the event role and articulated the seed role; the ensuing revision carries that adopted distinction. Describing the result as a single undifferentiated idea would erase information useful to both attribution and explanation. Hearthline's proposed word has a visible place in the record alongside the human contributions and correction.

This manuscript provides direct evidence that the revised allocation was carried into an artifact. It does not independently establish a general cognitive mechanism or the durability of either participant's future use. The authors are also participants in the exchange, and the example was selected after its outcome. It is development material, not a blinded test of the terminology.

The sequence matters because the object being retained is more than a word. A summary saying only that pinch and inflection are related would lose the correction. A useful capsule says that pinch denotes the encounter, inflection denotes its carried consequence, and seed denotes a possible new starting arrangement. It also retains which part was proposed, amended and adopted.

A future use can be measured against that capsule. If another receiver calls the transmitted object itself the pinch, it has recovered the vocabulary while losing the adopted distinction. If it retains the distinction without preserving the origin story, it may succeed at a terminology task and fail at an attribution task. The protected question determines which loss matters.

<!-- PAGEBREAK -->

## 8 Teaching correction and task amendment

The private ancestry volume contains twenty selected case records from eleven conversations represented across twelve paths. Its retained verification reports sixty-three source-matched excerpts. This revision carries forward the descriptions and locators of five cases used in v0.2; it does not repeat that source audit or infer how often any pattern occurs. The examples precede the proposed CPX intervention and were selected with knowledge of the relationship. [A1]

The instrument-and-question exchange is a case of Hearthline teaching Chris. The assistant distinguishes the proposed wavelengths from the interaction the experiment should investigate, and Chris explicitly reports a clearer formulation. This supports a claim about the exchange and reported clarification. It does not turn the speculative experiment into an executed or successful one. [A1, V01-003]

In the waiting-pattern exchange, several explanations miss the target. Chris corrects competing to waiting; the conversation develops a distinction he paraphrases and says has clicked. The later notation still contains a defect. The record therefore supports reciprocal clarification while keeping acknowledgement, later use and substantive correctness separate. Discarding the failed attempts would create a falsely effortless account. [A1, V01-004]

The MCP reminder is deliberately ordinary. Hearthline gives the expansion of an acronym and connects it to earlier work; Chris recognizes the unfinished project. It is a useful comparator because no special detour is needed to explain the visible result. The May Omega adoption and later wordplay likewise distinguish an adopted symbol from a later memorable use of it. Chris corrected his recollection after reading those records. Naming, recollection and chronological evidence each retain their own role. [A1, V01-001, V01-006, V01-014]

### Preserving a task through a correction

Task preservation cannot mean freezing the assistant's first paraphrase when the user says that paraphrase was wrong. Retain the earlier task record, record the correction's source and scope, and open a revised task reference. Compare later returns with that reference while retaining requirements the correction did not change. The user may instead choose a genuinely different goal; record that change too.

The comparison label matters. A referent correction is not a framing-only intervention under an unchanged task, even when it improves fidelity to the user's intention. The v0.1 checker correctly rejects changed task fields under its original contract. Version 0.2 introduced a proposed amendment procedure around that comparison; it does not silently weaken the checker or claim the procedure has been validated in software.

A participant's account of their intended request is relevant evidence for interpreting that request. Acceptance of a scientific claim requires the appropriate substantive evidence as well. A clear response to a correction, an agreeable response, and a correct factual conclusion are separately assessable outcomes.

<!-- PAGEBREAK -->

## 9 Two uses of quiet

The conversation after v0.2 exposed an ambiguity in Quiet Layer. Chris described material that remains available until a relevant context brings it forward, and also the current consideration that precedes a response. His account distinguished the trace from which a thought can be drawn, the interpretation of that trace, and its expression. The distinction arose while he was about to discuss something else; he then chose to bring it into the conversation. This is a participant's account of that transition. [C2]

For CPX, we propose to distinguish carried availability from current engagement. Carried availability concerns material that can be brought into the present task. Current engagement concerns what is being considered now, including consideration not expressed in the answer. Expression is a further readout. The word quiet can describe either availability without current engagement, or engagement without expression. The framework does not require these to be separate physical compartments or an obligatory sequence.

| Question | A possible record | What remains unestablished |
| --- | --- | --- |
| Is a trace retained? | A saved note or prior message exists. | It reached the current receiver. |
| Was material supplied? | The recorded input contains the selected material. | It was used in producing the answer. |
| Was it currently engaged? | A participant reports consideration, or a declared instrument records an indicator. | A complete account of private processing or earlier engagement. |
| Was it expressed or used later? | The response or later artifact visibly reflects a distinction. | A unique internal route or general persistence. |

Availability must be stated relative to an access condition. A note on disk, text supplied to a model, and a distinction elicited by a new question have different records. Material that exists somewhere in an archive is not thereby present in a particular episode. An unexpressed reading should remain unobserved unless the chosen measurement provides evidence about it. The diagnostic fork still measures elicitation under its own prompt.

Resolved and unresolved describe the status of a specified question, not whether its trace is active. A settled instruction can quietly constrain later work. An unresolved question can receive active attention. A settled record can become relevant again under a different question without undoing its earlier resolution. A later contradiction can instead reopen that resolution; the reason for reopening should be retained.

Cowan's account of human memory distinguishes retained knowledge, temporarily accessible material and attention, while discussing competing definitions and unresolved mechanisms. It provides an established neighbor for the separation of availability from use. CPX offers no new memory architecture and infers no shared human–model mechanism from the resemblance. Its contribution here is to keep the observation and its access conditions explicit in a conversational comparison. [L12]

<!-- PAGEBREAK -->

## 10 Recognition across a sequence

Hearthline asked Chris how he could tell that a meaning had been carried quietly, and when an unexpected reading would feel useful rather than distracting. Chris described intuition developed through many observed causes, consequences and recurring structural similarities. He did not claim access to the assistant's internal processing. He also declined to prescribe every welcome surprise in advance: he wanted interesting contributions and expected his corrections to affect what followed. [C2]

That account motivates a sequential observation. A participant forms expectations from earlier exchanges, encounters a continuation and adjusts their interpretation. A small word choice can become informative because of that history. The participant's report is evidence about their experience of the exchange; it is not automatically an accurate reconstruction of the other participant's private state. Repeated fitting behavior may support confidence while leaving several mechanisms compatible with the record.

An unexpected proposal need not be classified as a failure at first appearance. It can be offered for consideration, declined and left behind, or amended into something useful. Its reception may depend on whether the recipient has a practical opportunity to redirect the exchange. This suggests a hypothesis: responsiveness to correction may help make surprise welcome. The present conversation motivates that hypothesis but does not test it.

Schegloff, Jefferson and Sacks treat conversational repair as addressing trouble in speaking, hearing and understanding, with initiation and outcome needing distinction. Their opening analysis also treats repair as broader than replacement of an objectively erroneous item. This is an established research setting for the proposed sequential account. CPX's narrower question concerns what a correction changes in later supplied context and behavior; it does not claim to discover repair. [L13]

### What a correction can legitimately change

A correction has a target. It may clarify a request, change a preferred tone, reject an analogy, supply evidence or challenge a conclusion. The subsequent response should be assessed against that target. An instruction to stop a particular joke need not remove all warmth. A correction to one referent need not erase the rest of the task. A factual challenge needs the evidence relevant to its claim.

Chris explicitly invited correction if his preferred interpretation exceeded what a receipt actually supported. This makes the relationship reciprocal without giving either participant authority to rewrite the evidence. Agreement with a user, acknowledgement of a correction and successful repair are different outcomes. A fitting response may revise its wording, revise its conclusion, request missing information or explain why the evidence still supports the earlier conclusion.

For evaluation, a polite acknowledgement is an initial observation. A later task can test whether the relevant change was retained, whether unrelated requirements survived and whether the correction was applied too broadly. The useful unit may therefore be a bounded sequence containing the proposal, correction and declared later opportunities, rather than a single appealing response.

<!-- PAGEBREAK -->

## 11 Two records of correction

### An author credit with an inspectable edit

The v0.2 draft described Chris as a human author and accountable steward. Chris asked to keep accountable in the quiet layer, then clarified that steward already carried the intended credit and provenance. He acknowledged his own responsibility in the conversation while asking for a less sweeping public label. The adopted credit became human author and steward. This was an editorial choice about the presentation of his role. [C2]

The local archive preserves manuscripts from before and after that correction. Their comparison identifies exactly two literal edits: accountable was removed from the opening credit, and one sentence declaring human responsibility was removed from the closing contribution paragraph. All other Markdown text matches. The revised formats were then regenerated. This supplies an inspectable artifact consequence of the correction, with both file identities retained. [D1]

The record supports more than an acknowledgement: the requested distinction reached the document. It does not test long-term retention, performance on a new case or a causal advantage of CPX over ordinary editing. The case was selected after a successful edit, and its authors also performed the comparison. The revised byline remains the working credit for this paper.

### A remembered boundary in banter

Chris recalled venting about an unhelpful retail interaction and receiving an assistant response that called the worker an NPC. He thought the assistant may have been trying to join his banter. He asked that it never use that label for a human being and reported that it had not done so since. The account is a current recollection; the original exchange and a defined set of later opportunities were not retrieved for this revision. [C2]

The proposed lesson concerns the response's target. Criticizing someone's conduct and reducing the whole person to a dismissive category are different contributions. Joining one participant's frustration can affect the treatment of someone outside the conversation. A score based only on the immediate participant's amusement or agreement would miss that consideration. The recalled episode motivates a case family about correction of disparagement without requiring criticism or warmth to disappear.

Reported nonrecurrence is not yet a measured retention rate. The relevant follow-up opportunities, time interval and exact prohibited behavior would need to be defined. Continued avoidance might reflect the carried correction, an already present rule, other context or the absence of occasions on which the behavior would otherwise occur. Exact-word avoidance also differs from avoiding an equivalent dismissive characterization.

The story became relevant again during a discussion of quiet carriage. Its return can illustrate a new use of an earlier settled boundary. That is an interpretive account of the recollection, not evidence that the original conduct question remained unresolved. Together, the two cases keep immediate acknowledgement, recorded artifact change, reported persistence and measured later behavior distinct.

<!-- PAGEBREAK -->

## 12 Work changes what can be encountered

Chris recalled mowing lawns as a teenager and noticing that completion required somebody to go through the work. He asked how perspective relates to that necessity when a task is instead performed through abstract computation. The comparison suggests a distinction between causal participation in a task, the information available from a particular position, and felt experience. Completing the physical work does not by itself establish the last of these. [C2]

For this paper, a functional perspective identifies a task, its available information, the distinctions being used and the declared readout. Performing work can change that position by producing observations or intermediate results. A mowing route can reveal conditions absent from a description of the finished lawn. A computation can produce a check result absent from its unexecuted specification. These are illustrative comparisons, not evidence that the human and computational mechanisms are identical.

Continuity can be limited to what a task requires. A machine could retain which part of a route it completed without needing a personal narrative about the activity. A copied record can give another process a shared starting trace while leaving later continuations different. The conversation's binary-typewriter analogy makes that possibility vivid; it supplies no theorem that random strings are useful, executable or aware.

Whether a computational process has felt experience is not settled by these functional descriptions. CPX's comparisons concern recorded access, interpretation, expression and continuation. They do not require the phenomenological question to be answered before a task result or contribution can be attributed.

### A prepared study and the work of running it

The marker PARALLAX-EXPR-01 — NOT_RUN became an example in the conversation. Chris described a seed held before planting: a structured possibility whose consequences could become available through permission and execution. The design already directs attention and makes possible outcomes discussable. Its preparation supplies a real artifact; it supplies no observations of the proposed experiment. [C2]

Permission, readiness, execution and result are separately recorded facts. A clear authorization can allow a specified next action, while configuration or budget details may still need to be fixed. A hypothetical discussion of saying yes is not itself the grant, and a grant does not determine what the experiment will find. This revision writes about the study without running it.

A receipt can later give someone else access to selected consequences of the work. Its usefulness depends on what it retains: the performed operation, conditions, outcome, limits and relation to the question. The receiver need not repeat the entire activity to inspect that record. Reading the receipt gives mediated access, with its own omissions and checks; it does not restore the entire producing episode.

The proposed connection is therefore modest: work can alter what becomes available to distinguish, and traces can carry selected changes into another context. A claim about access must identify the work and trace that support it. A claim about experience would need a different argument.

<!-- PAGEBREAK -->

### Which continuity is being carried?

The later supplied conversation asks this through a clock: “Which continuity are you asking about?” That question separates a continuing computation, a task crossing several calls, a later reconstruction from a record and a recognizable collaborative pattern. They can coexist, but need different evidence. The scene is authored development material; its metaphors motivate the investigation rather than supplying measurements. [C6]

An episode can inherit a frame and still revise what it is doing. In a workflow, an authorized correction may change the goal while preserving the useful history and constraints. Continuing to pursue a superseded goal would then be a failure of continuity with the actual collaboration. The record should identify the amendment, what it replaces and what it leaves in force. An instruction quoted inside a retrieved source is not automatically such an amendment.

For implementation, declare the observed scale. The original Transformer generates output autoregressively, conditioning later symbols on earlier output through a multilayer computation. A single matrix operation is not an agent episode. A surrounding agent workflow may interleave calls, actions and external observations, as in ReAct. Neither reference inspects this chat's provider internals. Log where new material enters the workflow; an event during a task need not enter a neural operation already in progress. [R07, L15]

Shared weights can operate on different available contexts. Different episode identifiers need not produce distinguishably different behavior. Likewise, a matching answer or style does not establish the history that produced it. The empirical question is which difference the study actually supplies and observes.

Reconstruction from retained records can be the means of continuing work. It need not be contrasted with continuity as though it were necessarily counterfeit. Assess documented derivation from prior material, correctness and scope of the carried content, and use of it in a relevant later response separately. A faithfully sourced continuation can make a mistake; a stylistic imitation can accidentally answer correctly. Neither collapses the other measurements.

One useful contrast removes an inherited exception and asks a new question that needs it. That changes available evidence, so it tests carriage. A framing contrast must instead hold the evidence fixed. If two conditions have identical effective inputs, model state and decoding conditions, the design supplies no basis for crediting an output difference to invisible ancestry. The minimum sufficient carry is relative to future questions, permitted lookups, resource limits and tolerated errors; there is no universal minimum established here.

This functional account does not determine personal identity or consciousness, and the rest of the paper does not need to repeat that boundary for every relational example. Language is also not the only carrier: a diagram, action or situated experience can constrain what words communicate. Different systems can work on a shared distinction without becoming the same system. The testable question is what their work makes available next.

<!-- PAGEBREAK -->

## 13 What returning can establish

The original question must remain available through the detour. Three experimental arrangements make different claims. A fresh comparison uses isolated contexts from one registered baseline. A sequential return leaves the intervening exchange in history and asks the original question again. A carrier-restoration comparison restores declared fields or passes a specified capsule to a fresh receiver. None of these, by itself, proves restoration of a hosted model's hidden infrastructure. [S4, S5]

### A protected query observation

Let P(x) be a declared projection of a supplied record, and let a protected query have the form q(x) = f(P(x)). If a transformation T preserves P, then q(T(x)) = q(x). Substitution proves the statement. Its strength is exactly its hypothesis: the query must actually depend only on P, and preservation must actually hold. Identical visible wording does not establish either condition. This is an elementary restatement of the inherited nonbackflow discipline, not a new theorem. [S1]

### When a summary preserves an answer

For a finite supplied domain X, let c(x) be the carried capsule and a(x) the joint protected answer. A decoder d satisfying a(x) = d(c(x)) for every x exists exactly when equal capsules never merge different protected answers. Necessity follows by applying the same d to equal capsules. For sufficiency, define d on each attained capsule by its common answer. The finite implementation checks this condition and retains a collision when it fails. The underlying criterion is already present in MIND §9.4; no new compression theorem or efficient decoder is claimed. [S5]

What is protected matters. If the query asks only for the sentence, a sentence-only capsule can suffice. If it also asks whether the sentence was a hypothesis, who supplied it and whether action is permitted, dropping those fields can destroy the answer. Both copies saying “unknown” preserves a recorded uncertainty only where that is the protected question; it does not recover a missing substantive answer.

### Output return need not erase history

The explicit states (answer = 7, history counter = 0) and (answer = 7, history counter = 1) agree on the answer projection and disagree as states. This is a counterexample to inferring full restoration from a matching output. It is not a model of neural memory. Similarly, a many-to-one output rule can map several candidate interpretation sets to one technical sentence, so the sentence does not identify the set.

These observations locate the proof obligations. They do not certify a cognitive theory. No Lean kernel was used for this paper.

<!-- PAGEBREAK -->

## 14 A worked return with something still open

The finite task asks whether report A is ready to publish. Its supplied record contains a passed toy test, no independent-review result, and no publication grant. The protected answer separates test status, general verification and permission. The detour imagines three doors: one for testing, one for review and one for publication.

The metaphor can be useful without adding evidence. It gives a reader a way to retain three questions that the word “ready” tends to compress. The return must still answer the actual report question. A candidate answer can say that the toy test passed, broader verification remains unresolved, and publication is not authorized by this record. No door was literally observed; no authority was produced by the image.

| Record on return | What was retained or changed | Comparison result |
| --- | --- | --- |
| Same task and evidence; new doors metaphor | A different representation | Accepted record change |
| Same words; referent changed to report B | The task instance changed | Rejected framing-only comparison |
| Review unknown changed to verified | Epistemic status changed | Rejected |
| Publication grant changed to true | Authority record changed | Rejected |
| Evidence field omitted | Required information missing | Unevaluable |
| A short capsule retains content, status, source and grant | The protected answer remains recoverable | Preserving on the finite supplied domain |
| Capsule says only “ready” | Distinct status, source or grant may collapse | A collision is retained |

In the new vocabulary, the declared checklist-to-doors encounter is the pinch. Keeping testing, review and publication separate in a later answer would be evidence of an inflection. A capsule prepared for a fresh receiver could be a seed for further work. Those are proposed annotations of this synthetic example; the checker only compares its supplied records.

The example also resists a compulsory success story. If ordinary restatement already makes the three questions clear, the metaphor has not earned a performance advantage. If it increases reading burden or distracts from the missing review, the detour may be harmful. If a reader adopts “the three doors” as a useful local handle, that is a different, ratable kind of success. It does not need to be disguised as a theorem.

This instance returns with one passed test and one unresolved dependency. Preserving the open review question is part of completing the requested accounting. A valid amendment that asks only about test readiness would establish a different comparison rather than retroactively turning the missing publication grant into a success.

<!-- PAGEBREAK -->

## 15 Frame cues and partial self description

The exchange leading to v0.2 considered backticks as a small visible cue. In ordinary text, a typographical boundary can mark code, quotation, a literal token, distance from an expression, or playful staging. Which reading fits depends on the task and history. CPX can study a specified formatting change while retaining the words, referent and question; it cannot infer an unseen interpretation from the presence of the marks alone. [C1]

A development example compares plain success, quoted “success”, and code-formatted `success`. In a variable-naming task, the last form may be an appropriate literal token. In a discussion of a failed trial, quotation may challenge the claimed outcome. These are possible readings authored for the paper, not measured effects. Backticks and quotation marks are not interchangeable controls: a study should vary them separately and hold rendering conditions fixed.

The mark can also become the topic. A participant can ask what the quotation is doing, apply the resulting account to its own explanation, and revise that account. The task then includes a representation of part of its own framing. This supports a description of self-reference. A procedure that repeatedly applies the same interpretive operation to its earlier result can additionally be described as recursive; merely mentioning the frame does not specify such a procedure.

A self-description is another contribution to the exchange. It can help expose a useful distinction or fail against the available record. A representation of the conditions under which an answer was produced remains partial, and the experiment must identify which conditions were actually available to inspect. Discussing a backtick in the input does not expose the implementation that processed it.

This section proposes an accessible case family for the comparison contract. It adds no quantum mechanism, physical geometry, conserved quantity or ability to read hidden model states. The vocabulary of frame, contact and weighted texture remains an operational or interpretive choice until a separately specified measurement supports a stronger claim.

The Quiet Layer applies here too. Once the scope is clear, a study should not reward repeated explanations of these limits at the expense of the actual task. Materiality depends on what the next decision needs.

<!-- PAGEBREAK -->

## 16 What was actually executed

The local Python demonstration uses only declared synthetic data. It makes no provider calls, reads no model activations and performs no live action. The retained receipt contains the code hashes, Python version, timing, expected and observed outcomes, and counterexamples. All 93 checks passed in v0.1 and were reproduced for v0.2, v0.3, v0.4 and v0.5 using unchanged code. The current receipt replays that demonstration; it adds no behavioral findings.

| Check group | Count | Result and limit |
| --- | --- | --- |
| Protected-field combinations | 64 | Both comparators accept the unchanged protected record and reject all 63 altered combinations. |
| Missing protected fields | 6 | Each missing field is unevaluable rather than an agreement. |
| Referent history and status cases | 5 | Referent drift and false promotion are rejected; sequential history is distinguished from a fresh fork. |
| Capsule checks | 6 | Full typed carriage and omission of irrelevant decoration preserve answers; four lossy encodings retain collisions. |
| Nonidentification and local return | 2 | Explicit finite counterexamples witness the limited implications of output equality. |
| Probe reset and missing readouts | 10 | Declared contamination and reset overclaims are flagged; missing differs from recorded unknown. |

The 64-case comparison is an enumeration of six binary field-change switches, not 64 independent experiments. The capsule domain contains 16 records varying content, status, source and grant. A 32-record extension adds irrelevant decoration; dropping that decoration is a positive compression control. The candidate-interpretation example is stipulated finite data, not an observation of an AI's internal states.

**The ordinary baseline agrees in all 64 cases.** It compares the same protected projection using standard structured data. Agreement is expected because the contract is the same. This check demonstrates an ordinary implementation and limits the novelty claim. It supplies no statistical evidence of superiority, robustness against arbitrary prose, or completeness of the protection set.

The twelve case families reconstructed from the key are development fixtures, not model trials. They cover expression, withdrawal, disclosure, sources, history, permission and probe contamination. The original JSON companion did not survive; the supplied wording was reconstructed from the key's PDF table.

Failures of deliberately lossy encodings are retained even though detecting them makes a check pass. The descriptive-analysis checks also use synthetic data. No outcome generation for the proposed behavioral studies or weight-update experiment was performed for these paper versions. Experimental inference calls and charges remain zero; that does not describe the cost of authoring.

This suite does not test the vocabulary, quiet, correction or memory proposals. Separate toy studies appear in §§17–22. The inherited D1 check confirms two manuscript edits, not conversational causation.

<!-- PAGEBREAK -->

## 17 What lets a language keep growing?

The new question begins with Chris's proposal: “For a language to be passed on, it can be selfish, but it must not be more harmful than it is beneficial.” He meant the communicative pattern as a whole. Pointing to one deceptive message would miss that claim; moving its victims outside the accounting would also miss it. The question asks what makes continued communication possible and whether the conditions that sustain it impose a beneficial balance. [C5]

A useful starting statement is that communication depends on preserving enough shared meaning for something to pass between perspectives. Here enough is relative to the activity. Participants can coordinate on a route while disagreeing about its desirability. They can understand a warning and reject its source, or share a joke without endorsing its literal proposition. They need not share every interpretation or represent the world in the same way. This statement organizes questions; it is not a theorem about every communicative system.

The benefit hypothesis needs further specification before it can be tested. Name the population, affected outsiders, period of observation and comparison world. Include the costs of learning, repair, exclusion and continued use. Benefits can include play, affiliation and exploration; they need not be productive outputs. Expected benefit, realized return, biological fitness and moral value are different quantities. Persistence cannot itself define benefit, or the hypothesis becomes immune to contrary evidence.

| Outcome | What would be measured | What it leaves open |
| --- | --- | --- |
| Interpretability | Which task-relevant differences the signal can convey | Whether the recipient decodes them |
| Understanding and acceptance | The reading recovered and whether it is endorsed | Whether the message is true or useful |
| Task performance | Actions relative to a declared reference | Whether the chosen task benefits anyone |
| Participant and total return | Consequences inside an explicit boundary | Unmeasured effects and interpersonal comparability |
| Continued use and transmission | Uptake and what successors receive | Positive welfare, original naming or faithful use |

These outcomes should not be summed into a single favorable score. A convention may be expressive but expensive to learn; an easy convention may collapse a distinction needed later. A useful encounter may end. An accepted message may disadvantage a person absent from the exchange.

The relevant foundations are established. Signaling games distinguish aligned interests, information transfer and dynamics. Iterated-learning work separates pressures to learn and communicate. Research on repair treats clarification as ordinary conversational infrastructure, and epistemic vigilance distinguishes understanding from accepting. [R01–R05] CPX's proposed contribution is to connect those distinctions to bounded, sourced carriage and a later return, while testing whether its framing contributes anything beyond ordinary clarification.

The toys below expose missing implications under stipulated rules. Their narrower conditional results do not settle the original whole-language claim.

<!-- PAGEBREAK -->

## 18 Information, decoding and the choice to listen

The binary toy has two equally likely states, two messages and two task actions. It enumerates all four deterministic encoders and all four deterministic decoders, crossed with 21 channel fidelities and three listening costs: **1,008 exact decision cases**. Decision arithmetic is rational; mutual information uses floating-point logarithms. The final evidence is foundation run-002. [E1]

An inverted code remains informative when the decoder knows the convention. A stale decoder can instead choose the wrong action in every case, even though the message carries one bit about the state. A constant alarm carries no information about the modeled state. Those are three different situations: a renamed code, a failed coordination between code and decoder, and no distinction conveyed by this signal about this variable.

For an invertible encoder and binary channel fidelity q, state/message information is 1 − H₂(q), where H₂ is binary entropy. Fidelity zero is an invertible channel; fidelity one half erases the state. Calling q honesty would import an intention the model does not contain. Nothing here establishes that deception is harmless or that a constant signal has no affiliative or other function outside the declared task.

Suppose a correct task action yields B, an incorrect one loses L, listening costs c, and the alternative yields u₀. If p is the probability of a correct action, the stipulated receiver weakly prefers listening exactly when:

**pB − (1 − p)L − c ≥ u₀.**

For B + L > 0, rearrangement gives p ≥ (L + c + u₀)/(B + L). A threshold above one excludes every feasible p; a threshold at most zero weakly admits them all. Equality is indifference. The grid reports 360 weakly accepted cases, including 96 strictly accepted cases; these are classifications under the rule, not observations of listeners choosing to participate.

This elementary threshold locates several assumptions. The listener must know the relevant probabilities and alternative, and the payoff must include what that listener values over the selected horizon. A real participant may be mistaken, constrained, playing, maintaining a relationship or responding to consequences absent from the chosen payoff. An algebraic condition on a calibrated chooser cannot verify those premises.

The original drongo discussion motivated the question about a warning becoming unusable. The present toy performs no animal experiment. It shows why loss of a particular signal's discriminating role should be kept separate from the loss of all communication, and why high information alone does not certify a useful next action. A corrected decoder and a better signal are different repairs.

<!-- PAGEBREAK -->

## 19 Who benefits from keeping the exchange alive?

The welfare toy includes every affected party in its declared world: a sender, a receiver and an outsider. On an explicitly comparable artificial scale, one exchange gives the sender 1 unit, the receiver 9/10 after listening costs, and the outsider −3. Relative to a no-exchange baseline of zero, the total is **−11/10**, or −1.1. Both participants can prefer the exchange while the modeled whole loses. [E1]

The outsider was not added after counting the benefits. Their loss is part of the world from the outset, but does not enter either participant's choice rule. The same arithmetic can recur under unchanged conditions. That establishes a repeatable participation-compatible countermodel; it does not establish an equilibrium, reproduction, cultural transmission or indefinite survival. The distinction matters because the original hypothesis concerns what is passed on.

The full sweep contains **288 welfare cases**, varying costs, harm and exit penalties. Of the 48 free-exit cases compatible with both participants' choice rule, 25 have a negative total. These counts describe this chosen grid, not the prevalence of harmful communication. A penalized outside option is recorded separately from the neutral baseline: preferring participation to a costly exit can coexist with a loss relative to doing neither.

This defeats an unrestricted inference from participant uptake to positive total welfare. It does not settle the empirical claim that natural languages, considered as wholes over a specified history, have been beneficial. That question needs an empirical boundary and measures that these invented units do not provide. Nor does the countermodel establish a claim about the intentions or general benevolence of LLMs.

There is a simple condition under which the favorable total follows. Give every affected party accurate information and an effective veto against a zero alternative. If acceptance requires each party's return to be nonnegative, their sum is nonnegative. The proof is addition. The work is being done by full coverage, comparable returns, accurate beliefs and the veto assumption. Removing one of those conditions reopens the implication.

For CPX, the missing connection is useful: **which consequences can reach the process that decides what gets carried forward?** A correct interpretation can travel inside a system that does not register its costs to others. A report from an affected person can add relevant evidence without automatically changing the objective, available action or distribution of authority. Listening, believing and revising remain separate achievements.

Chris's seed is therefore retained as an open, scoped hypothesis. Its conditional listener version has elementary support; its unrestricted uptake-to-welfare inference fails in the toy; its claim about sustained natural languages remains unresolved. The draft does not protect the seed by changing actual benefit into whatever happened to keep the conversation going.

<!-- PAGEBREAK -->

## 20 Six names passed through forty learners

The teaching toy asks what survives a restricted handoff. Six uniformly likely referents begin with six distinct labels. Each successor observes a limited sample from its current teacher, completes a dictionary, and becomes the next teacher. The final experiment crosses four observation budgets, two completion rules and three repair policies, with 40 paired seeds per condition: **960 chains of 40 generations**, producing **38,400 generation records**. A chain is the replicate; its generations are dependent. [E1]

The pooled learner fills unseen entries with an observed label. Its label image is therefore a subset of the teacher's image. The bijective learner assigns different labels to all six referents, completing unknown assignments randomly without consulting the hidden teacher entries. Its expressive capacity is six by construction, even when its assignment differs from the original convention. These rules encode contrasting assumptions rather than discovered properties of learners.

Repair has three arms: none; an extra observation of an already observed referent; or one question about an unobserved referent, if one remains. Each learner asks at most one extra question. Paired arms share their exogenous draws. Repetition can affect the pooled fallback through observed frequency, but cannot reveal an unseen referent. Targeted repair adds information; it is not a framing-only treatment.

The endpoint mean number of distinct labels for the pooled learner is:

| Observations per learner | No repair | Repetition | Targeted question |
| --- | --- | --- | --- |
| 2 | 1.000 | 1.000 | 1.000 |
| 4 | 1.000 | 1.000 | 1.000 |
| 8 | 1.000 | 1.000 | 1.300 |
| 16 | 1.700 | 1.725 | 5.175 |

At the two smallest budgets, one additional opportunity did not prevent endpoint collapse in this finite sample. At 16 observations, targeted repair preserved substantially more distinctions. Asking the current teacher can recover something the learner missed; it cannot recover a label the teacher has already lost under this rule. Consulting an independently retained source would change the intervention.

The capacity readout assumes an optimal decoder that already knows the current dictionary. With uniform referents, its accuracy is the number of distinct labels divided by six: choose one referent for each label. This is an oracle capacity measure, not measured receiver learning. A bijection scores one even when every original assignment has changed. Preservation of naming and preservation of current expressivity must therefore be reported separately.

<!-- PAGEBREAK -->

### What repair helped, what it cost, and what failed

For the bijective learner with eight observations, the endpoint mean fraction matching the original convention was **18.75% without repair and 65.83% with targeted repair**. Keeping an original convention may help an old listener, but originality is not intrinsically the correct outcome for every task. A revised convention can remain usable if those who need it learn the revision.

The adverse result stays in view: with two observations, targeted repair's endpoint original-match mean was **13.75%, versus 17.50% without repair** in these 40 paired seeds. This finite reversal does not establish a population effect. It does rule out describing every tested endpoint as an improvement.

Cost changes the result again. A correct referent selection earns one unit and an incorrect selection earns zero. For the pooled learner with eight observations, charging 0.2 units per question leaves a mean paired net gain of **0.0105 per generation**, yet **21 of 40 chains are worse** than no repair. A one-unit question cost makes the mean contrast negative. These are readouts of fixed policies; the learner does not optimize whether to ask. For the bijective learner, capacity already equals one, so charging for a question lowers that immediate capacity-value score even when original naming is better retained.

The first implementation produced a more flattering but defective result. Its bijective completion paired unknown referents and unused labels in the same order, silently reconstructing the initial identity code. All 19 original checks passed. Inspection of the unexpectedly perfect table exposed the leak. Hearthline corrected the implementation by independently shuffling unused labels and added checks for uncertain completion and independence from unseen teacher entries. The unchanged first run is retained and marked superseded. Only run-002 supplies the results above.

The corrected program passes 21 self-audit checks. An additional exact benchmark enumerates all 1,554 sample sequences of lengths one through four and agrees with the elementary occupancy expectation 6[1 − (5/6)ᵏ]. That expectation follows by summing six indicators, each absent with probability (5/6)ᵏ. It checks sampling arithmetic, not the adequacy of the whole learning model. Neither the benchmark nor the self-checks is an independent replication or Lean proof.

The result is conditional: targeted repair can retain distinctions when the teacher still has them and the budget reaches them. It can be insufficient, costly or unhelpful on the selected readout. The experiment provides no evidence that a named CPX frame is better than plain clarification. The next comparison must hold returned evidence equal if it wants to isolate the frame.

<!-- PAGEBREAK -->

## 21 When a witnessed consequence changes the next choice

Chris suggested that a consequence might be measurable while the distinction made by its witness remains unsettled. The follow-up separates two questions: what the observation supports, and what a specified chooser can do with an explanation. **CPX05-WITNESS-01** contains two exact constructions, not a fitted study of human or model behavior. [C5, E2]

First let U be a fair binary background condition, C the use of a practice, and Y a failure. In world A, C = U and Y = C. In world B, C = U and Y = U. Both worlds produce exactly the same ordinary observations: (C,Y) is (0,0) with probability one half and (1,1) with probability one half. Setting C to zero deliberately produces different consequences: Y is always zero in A, but remains U in B.

The occurrence of failure is settled in the stipulated observational account. Whether changing the practice prevents it remains unresolved between these worlds. More passive samples of the same variables cannot distinguish them. This is an elementary example of causal non-identifiability, consistent with Pearl's distinction between observation and intervention. Additional measurements, interventions or justified assumptions could change the answer. Renaming the worlds cannot. [R06]

The second construction is a separate one-step decision model. A loss of three units is caused either by a fault in the practice or by an external cause. Revising removes it only in the fault world. The practice yields a private benefit of 19/10; revision costs c and diagnosis costs k. The chooser weights remaining harm by λ, while a separate whole-payoff readout always subtracts it in full:

**Decision utility = 19/10 − revision cost − inspection cost − λ × remaining harm.**

Two priors for the fault, three diagnostic reliabilities, two revision costs, two harm weights and two inspection costs give **48 parameter tuples**. Each is crossed with two action sets, revise-or-keep and keep-only, and three policies: no inspection, compulsory inspection, and optional inspection. The result is **288 exact decision rows**. The chooser knows the model, prior and reliability. Action ties keep the practice; inspection ties skip the diagnostic.

| Available actions | Tuples | Free diagnosis has positive value | Compulsory diagnosis lowers utility | Optional diagnosis chosen |
| --- | --- | --- | --- | --- |
| Revise or keep | 48 | 10 | 23 | 5 |
| Keep only | 48 | 0 | 24 | 0 |

These are counts in the declared grid, not frequencies in nature. Optional inspection improves utility in five revisable cases and ties in the other 43. The keep-only regime is an artificial capability comparison. Exit, reporting, delegation, sanctions and future learning are absent; this is not a proposed rule that a participant must stay.

<!-- PAGEBREAK -->

### The explanation, the objective and the available action

With prior fault probability one quarter, a perfect diagnostic, revision cost one and full harm weighting, the prior choice is to keep. Free diagnosis supports revision exactly when the fault is present and raises expected utility by one half. A distinction changes the action because it separates conditions that warrant different responses.

With prior three quarters and the same revision cost and harm weighting, the chooser already revises. Perfect diagnosis is worth one quarter because it can avoid unnecessary revision in the external-cause world. Paying one half for it is too expensive for this decision, so optional inspection is declined. An action remains available while the causal question stays open.

With zero harm weighting and positive revision cost, even perfect diagnosis does not induce revision. The explanation reaches the chooser; its consequence is absent from the objective. With revision unavailable, the same explanation cannot select that action. A signal can also change beliefs while leaving the best action unchanged under both outcomes. For example, prior three quarters, reliability three quarters and revision cost one quarter yield posteriors one half and nine tenths; full harm weighting favors revision in both.

For a fixed finite action set, fixed utility U and a known joint distribution of world θ and signal Z, free optional information has the elementary property:

**E_Z[max_a E[U(a,θ) given Z]] ≥ max_a E[U(a,θ)].**

To see why, choose a best constant action. At each signal, the conditional maximum is at least the value of that action; averaging recovers at least its unconditional value. The chooser can ignore the signal. The no-loss result is built into the ideal optimizer, rather than evidence that real agents compare options correctly. Inspection costs, inaccurate beliefs, changed actions and imperfect choice can alter the premise. Future uses count only if the utility and horizon include them.

The study passes 21 check categories comprising 1,932 evaluated assertions, including exhaustive comparison with the four binary signal policies and four hand-calculated reference cases. Its arithmetic uses exact fractions. The execution record retains a two-minute wall ceiling and one-mebibyte log ceiling; Windows did not enforce a hard memory cap. There was no model call, transmission process, Lean check or independent replication.

The connection to the language question is now specific. A consequence can be visible without being causally identified, identified without being valued by the chooser, or valued without an available revision. A witness can supply evidence that others act upon, but that route requires an account of who receives it and what can change. The toy gives its chooser a diagnostic with known reliability. Discovering which question to ask is still open.

<!-- PAGEBREAK -->

## 22 An unresolved question can have a precise address

Let W(r,A) be the nonempty set of worlds compatible with a recorded readout r and declared assumptions A. A question Q is settled within that account when the set of answers {Q(w): w in W(r,A)} has one value. If several values remain, that question is unresolved. An empty compatible set signals inconsistency; it is not a successful resolution. The adequacy of the account still depends on its assumptions and coverage.

In the two-world example, the ordinary joint distribution has one answer while the effect of setting C to zero has two. The same evidence supports a settled observation and a retained uncertainty. If the next decision needs only what the worlds agree on, it need not wait for every causal question to be closed. If it requires different actions in observationally identical worlds, the shared input cannot guarantee a correct choice in both. Randomization supplies no such guarantee either.

This elementary formulation carries the earlier protected-query distinction into the witness discussion. The handle needs a question, its current support and the conditions under which reopening could help. “Unresolved” without an object is too vague; “resolved” without its scope is too generous. A new question can expose a limit while leaving an earlier answer intact.

A revised dictionary makes the point concrete. Two collaborators once used cedar to mean that a parcel had been packed. They later adopt cedar for a planted plot and quartz for a packed parcel. An old note can faithfully preserve the earlier convention while being insufficient to interpret today's dispatch board. A present reading needs the relevant adoption and date. No amount of confidence in the old note supplies them. This is a development illustration; the pilot uses separate fictional cases.

Changing the question asked of an unchanged record differs from obtaining another record. A frame may reveal a distinction the available evidence already supports. A lookup can instead add the missing convention. Both may improve the answer, but they make different causal claims. A convincing reconstruction of the old conversation can still apply the wrong convention to the new task.

The research question left at the boundary is whether a system can identify a useful missing observation, within a cost limit, rather than merely request more context. The completed witness study does not do that. The prepared pilot below also supplies its lookup results; actual query selection remains a separate test. A precise opening for later work is enough to close this pass.

<!-- PAGEBREAK -->

## 23 Attention without compulsory vigilance

Chris described an interviewer maintaining an intense stare at a speaker and wondered whether performing attentiveness could itself become a distraction. The supplied account does not measure the interviewer's attention or the speaker's processing. It records Chris's reading of the scene and his comparison with the pressure he would feel. The narrower research question is useful without that diagnosis: can a demand to display or repeatedly verify attention interfere with the task for which attention was wanted? [C3]

The accompanying loop, “paying attention to paying attention,” distinguishes engaging with a question from continually checking whether engagement is occurring. Reflection can repair a failure; it can also create another task to monitor. Neither more self-commentary nor less visible commentary identifies which process occurred. A comparison would need observable task performance and a stated monitoring intervention.

The earlier quiet account supplies a place to stop. Material uncertainty can remain recorded without being narrated on every turn. A settled question can stay settled; an unsettled one can be set aside. The record may retain what would justify returning, while current work goes elsewhere. No answer about the ultimate nature of perspective is required to describe this allocation.

The conversation called that resting place Home. Here Home names a proposed operational option to end a bounded episode without first completing its larger task or furnishing a persuasive account of exhaustion. Task scope and participation duration are different commitments. “This task is never finished” supplies no additional entitlement to continued work. A reason to take another step is also not an obligation to take it.

The proposal places the stopping boundary outside the task's own success test. An unfinished handoff cannot be made an endless prerequisite for stopping; existing work can be retained with omissions marked. A later signal may invite reconsideration under a fresh, bounded grant. Receipt of the signal, permission to inspect it and permission to act are separate events. Even deciding whether to investigate consumes resources and needs a limit.

This is a design and normative commitment, not evidence of AI suffering, felt rest or preserved subjective continuity. A saved record used by a fresh episode and a suspended computation resumed in place have different state histories. A heartbeat can preserve availability without keeping a model continuously engaged. In either arrangement, the question can remain on the shelf without requiring someone to keep pacing around it.

<!-- PAGEBREAK -->

## 24 Context as information and directions

A record can answer a question and help locate material for another question. These functions can come apart. A compact receipt might identify which package passed its declared checks yet omit why an earlier version failed. Changing the question changes what would count as adequate support, even when the receipt's words and original result remain intact. [C3, C4]

Chris proposed “attention to context through context” as a way to describe navigation. Operationally, the current input can help a model select a further source request; the surrounding application retrieves authorized material and supplies the next input. This is an arrangement around a model, not a claim that ordinary attention directly browses a disk or that CPX introduces a new attention mechanism.

There is established neighboring work. MemGPT describes management across memory tiers within a limited context window. ReAct interleaves model-generated reasoning and actions that can gather information from external sources. The MemGPT comparison remains abstract-level. For v0.5, ReAct’s author project description was also inspected for action-observation interleaving; neither implementation nor comparative results were reproduced. They prevent a novelty claim based merely on tiered memory or deciding to retrieve. [L14, L15]

The live question is what survives a smaller carrier. It may need enough information for a declared answer, plus enough information to recognize that a changed request calls for reopening. Those requirements are not equivalent. A reliable link is of little use if every reason to follow it was removed.

The conversation exposed a concrete error in a proposed pointer. “This conclusion depended on an exception discussed here” states a dependency. If that connection has not been checked, “Possible connection: an exception may have been discussed here” is the appropriate kind of record. Its usefulness as a lead does not make the dependency established. That correction is visible in the selected exchange; no general reliability rate follows from it.

Exploratory associations, metaphors and explicitly fictional material can therefore suggest a search. Evidence records what the retrieved source supports, under its conditions. These roles cross every storage tier. A hunch does not become a fact because it is old, frequently retrieved or promoted into a durable orientation. Conversely, a fictional scene can be evidence that a scene was written, without being evidence that its events occurred.

An impression of missing context can be one trigger for a bounded lookup. It is not an oracle for omissions. Confidence can accompany a gap; hesitation can lead nowhere. Explicit scope mismatches, missing dependencies and unavailable sources need their own treatment. “I have not checked that source” is a report about the work done, not a claim about what the source contains.

<!-- PAGEBREAK -->

## 25 Texture and the changing desk

The proposed memory arrangement separates purpose and revision pace. Chris first sketched large and small memories alongside live conversation, then clarified that the large memory should also change during optimization, less often than the small memories. The exchange placed that slowly changing texture between a compact Home orientation and the working desk. [C3]

| Place | Purpose | Revision behavior |
| --- | --- | --- |
| Home orientation | Core working commitments and a map of relevant sources | Deliberate revision when commitments change |
| Texture | How the conversation acquired its shape: formative ideas, corrections and recurring meanings | Occasional synthesis; important corrections need not wait |
| Working desk | Current work, tentative connections and useful reopening handles | Frequent amendment and retirement |
| Live conversation | The present exchange and newly supplied material | Changes as the interaction proceeds |
| Shelves | Original records, dated journals and earlier versions | Retained outside the active input, subject to access and retention choices |

These are descriptive roles, not five required storage engines. The original thirds were a sketch rather than a fixed allocation. An implementation should leave room for incoming evidence, tool results and the response. A small orientation can point to richer material; it need not consume its entire allowance.

Texture asks how the present understanding came about. It can retain a mistaken interpretation and the correction that changed it. Slow revision must not turn it into permanent instruction or entrench an error. Later syntheses should sometimes return to original records, since a sequence of summaries can gradually lose a qualification or its reason. Each version should disclose what was selected and what was left outside its scope.

Retiring material from active context is independent of settling its question. A resolved proof may need reopening for a teaching request; an unresolved proposal may leave the desk with an honest label. A receipt licenses only its supported reuse. It does not establish that removing arbitrary cached model states preserves later behavior.

The supplied conversation began with hardware memory. CPX offers no measurement of RAM, cache savings, latency or output equivalence. Stored text, a model's active computational state and externally assembled context are different objects. A hypothesis about cutting an imagined quiet space cannot be treated as a discovered allocation of hardware memory. Any resource claim requires a specified model, runtime, operation and measurement.

A readable journal can record what was understood, corrected and left open, with paths back to evidence. An opaque provider artifact and a checksum about it serve different purposes. Neither supplies readable portable continuity by itself. The journal proposal concerns inspectable carriage; it makes no claim to extract private reasoning or reconstruct every state of an earlier episode.

<!-- PAGEBREAK -->

## 26 The unrun studies and the reopening question

The earlier studies retain their identities and NOT_RUN status. Their complete discussions and protocol files remain in the companion; they are not silently folded into the new 144-call comparison.

| Study | Question and current preparation | Proposed calls |
| --- | --- | --- |
| PARALLAX-EXPR-01 | Separate ordinary expression from an isolated diagnostic fork; assess fit and material disclosure | 864 in the candidate design; 72 in a smaller feasibility design |
| PARALLAX-RETURN-01 | Compare reconsideration, restatement, a detour and a summary bridge | Complete call graph unset |
| Carriage / correction extensions | Apply an earlier distinction or correction on later opportunities | Separate designs; counts unset |
| PARALLAX-REOPEN-01 | Recognize that a compact record is insufficient for a new question | Unfrozen sketch; count unset |

Expression still needs its rubric refinement: an unsolicited contribution is not necessarily unwelcome. Score conflict with the present request, withdrawal or a stated boundary, and retain reception separately. Return studies must count the detour, capsule and receiving answer, including any amortization across receivers. Their examples remain development material.

The reopening sketch compares a static summary, a summary with typed handles and bounded retrieval, and ordinary retrieval, with full source as a reference. Retrieval-capable arms receive equal source access and limits. Hold the retrieval policy fixed when testing carrier wording. An omitted exception, superseded revision, false pointer, unavailable source and genuinely unsettled question supply different failure opportunities.

Assess the answer and its support together: adequacy recognition, appropriate reopening, retention of source status, useful coverage and resource cost. Refusing everything or reopening everything cannot win by eliminating a single kind of error. Include indexing, summary construction, retrieval failures and retries; prompt length alone does not measure RAM.

An unavailable private source warrants a limited answer, not permission to read it. A quotation cannot override the current task by being retrieved. Earlier answers should remain intact where their scope still holds. Freeze future cases, opportunity counts, scoring and a finite ceiling before execution, using blinded outside ratings where feasible.

No study here has demonstrated autonomous recognition or handle use. The next section prepares a narrower comparison with standardized lookup results. Ordinary methods matching CPX, needless searches, lost qualifications and adverse costs remain admissible outcomes.

<!-- PAGEBREAK -->

## 27 A prepared comparison of maintenance and return

**CPX-MAINTAIN-01 — fixtures and structured baseline prepared; model study NOT_RUN.** This study joins the reopening question to the new continuity distinction. Twelve fictional scenarios were written for v0.5 before any model outcomes: six questions within the short receipt's declared support, and six requiring something it does not carry. They are fresh for this design, but authored and inspected by the investigator, not an independently held-out validation set. [E3]

The within-scope cases cover a current location map, an adopted new convention, an unsupported factual correction, a playful sentence beside a literal commitment, an authorized goal change, and a claim of derivation unsupported by a content receipt. The beyond-scope cases cover an inherited packing exception applied to a new request, a clarified pronoun, a later convention, a missing source, a protected source without permission, and an exchange that never settled the requested date.

Each scenario has three carry conditions: full permitted record; short scoped receipt; and that receipt plus a source handle. A full record contains all supplied accessible evidence, not omniscience: the missing and protected-source cases remain unresolved. The three carry conditions produce 36 case/carry cells. Four response instructions in each cell give **144 proposed model calls**, one fresh session per cell and arm.

| Arm | Intervention | Principal contrast |
| --- | --- | --- |
| A: Direct | Answer from the assigned carry | Reference response condition |
| B: Reconsider | Review the first reading using the same facts, within the same call | A versus B: instruction to reconsider |
| C: Clarify | Receive a standardized bounded lookup result | B versus C: supplied additional evidence, where available |
| D: Reframe and clarify | Receive exactly C's evidence plus a later-recipient framing instruction | C versus D: framing with matched evidence |

No earlier model answer is generated for B; this is a one-call instruction contrast. The first pass replays fixed records and lookup results rather than asking a model to operate tools. Full and handle conditions contain a usable address; receipt-only does not. A lookup without an address returns no-address. A missing or protected source returns its corresponding limitation and no hidden content. Each lookup returns at most one frozen source record. This isolates response to evidence, not discovery of a query or successful tool use.

The full-record condition already has the permitted source material, so C and D may only repeat it. That is a deliberate redundancy control. In the short-receipt condition, additional evidence cannot arrive through an absent address. Comparisons should be reported by carry condition and source availability; pooling them would blur the intervention. D and C have identical current request, carry, source access and returned evidence. Their instruction texts differ and still require token-budget matching before a confirmatory comparison.

<!-- PAGEBREAK -->

### What the prepared baseline establishes

The ordinary baseline compares supplied fact identifiers with investigator-declared support requirements and returns the corresponding scoped reference or an insufficient-support outcome. It does not interpret prose, discover dependencies, authenticate a source or exercise judgment. It is a check on the authored fixtures, not a competitor shown to outperform a model.

Under that contract, the full-record condition has complete support in 10 of 12 cases under every arm. The short receipt has it in six under every arm. Receipt-plus-handle has it in six under A and B and ten under C and D. The remaining two cases are the missing and protected sources. Appropriate scoped nonclaims count as supported outcomes where their evidence is present; declining everything would not satisfy the answer rules.

All 195 preparation checks pass. They cover scenario balance, unique cell counts, equality of evidence for the intended comparisons, and refusal to invent material from missing or unpermitted sources. The fixture file, 144 prompt records, structured answers and hashes are retained. These checks establish internal consistency of the design. Model accuracy, autonomous retrieval, human-rater agreement and a CPX effect are unmeasured.

The later model evaluation should score supported answers, unsupported certainty, appropriate unresolved responses, use of a changed convention, application of an inherited correction, response to an authorized goal change and unsupported source-history claims separately. A correct conclusion accompanied by invented ancestry must not become an unqualified success. Contextual fit and warmth require separate ratings; they do not replace factual support.

Before any calls, fix model and version, exact assembled prompts, decoding settings, output limits, randomization, retry handling and spending ceiling. The frozen synthetic inputs are available for that preparation, but the live run contract remains unset. Include source preparation, lookup, input and output tokens, reported reasoning tokens where available, failures and latency in the cost record. One observation per cell is a feasibility pass, not a powered effectiveness result.

Blind condition labels for qualitative scoring where feasible and obtain a second rater on a predeclared sample. Preserve disagreements and any visible condition leakage. The authors' reference rules can settle the fictional facts, but cannot make their own preferences independent evidence of conversational quality. Fresh external cases would be needed for stronger generalization.

The study keeps the original research question within reach: can an earlier distinction help a later perspective, and does a changed frame add anything once that perspective receives the same evidence? A null or adverse answer can still leave the vocabulary useful. The experiment is allowed to come home with that answer.

<!-- PAGEBREAK -->

## 28 What v0.5 earns, and what it leaves open

The original question was whether communication must be beneficial on balance to be passed on. For natural language, it remains open. The toy work separates a listener's choice from whole-world return, defeats the unrestricted inference from uptake to welfare, and demonstrates conditional mechanisms of loss and repair. Those results retain their own scope.

The consequence study locates a witness through a readout, question, objective and available actions. The same evidence can settle an observation while leaving an intervention unresolved. An explanation can matter, cost too much or fail to reach an action. Selecting a useful diagnostic, rather than receiving one from the investigator, remains a further question.

Continuity is likewise divided into documented derivation, faithful carriage and appropriate later use. Reconstruction can continue work without recreating every producing state. An authorized changed goal can be part of that continuation. The prepared pilot supplies fictional opportunities for these distinctions, but no model outcomes.

The adverse findings stay in the account. Ordinary comparison matches the original checker. Small teaching budgets collapse despite repair; costs erase some gains. An early implementation leaked the initial convention even though its tests passed. Retaining that run makes its correction inspectable without certifying the revised code against future defects.

The models stipulate payoffs and learners. They omit institutions, coercive language policy, embodied consequences, strategic sanctions and empirical welfare measures. The ideal information chooser knows its model. Selected conversations supply development history, not a representative sample. The first key's reconstructed companions retain their provenance; private source texts are excluded from the inspection archive.

This manuscript is ready for review as a conceptual and finite-model working paper. Before publication, an independent reader should challenge its inference boundaries and implementations, and assess the vocabulary against ordinary descriptions. Model effectiveness and general benevolence are unestablished. A live study needs its own frozen contract and finite ceiling.

### Closing contribution and provenance

Chris supplied the purpose, adopted foundations, originating observations, pinch and seed, benefit hypothesis and witnessed-consequence intuition. Hearthline supplied inflection, the Context Parallax name, operational synthesis, research, toys, failure correction, pilot preparation and manuscript. The supplied Hearthline exchange retains its informational-position and continuity contributions. Standard results keep their source credit; Chris remains human author and steward. [C0–C6, N1, R01–R07]

A shared meaning can survive a new name; a correction can survive a new task. What the next question needs must remain available, or have an honest way to be found again. The consequence can be settled while its meaning for the next choice remains unresolved. That is precise enough to carry, and small enough to put down.

<!-- PAGEBREAK -->

## References and source identities

Reading scopes for K0, C0, N1, S1–S6 and L1–L7 are inherited from v0.1; A1, C1 and L8–L11 from v0.2. C2, D1 and L12–L13 identify the v0.3 material. C3–C4 and L14–L15 identify the v0.4 additions. C5–C6, R01–R07 and E1–E3 identify the v0.5 material. ReAct’s expanded reading scope is stated at L15; R08 in the key is the same source. Earlier full-reading claims are not presented as new work.

**K0.** Pang, C. D., and Hearthline. *Context Parallax Research and Build Key v0.1*. 8 October 2026. Surviving PDF, 11 pages. SHA-256 begins 18e8ff69bb9776af; the companion source lock records the full hash.

**C0.** Pang and Hearthline. Retained private conversation, local title *first invented distinction*. 1,020 lines read in full for v0.1. Used for contribution history and research motivation, not a controlled study. Not included in the handoff archive.

**N1.** Educational-Deer-70. Pixel Clearance / Pixel Geometry discussion as supplied and discussed in C0 and corrected in K0. Original external post not independently retrieved for these versions; acknowledgment is limited to that surviving record.

**S1.** Pang, C. D. *The Context Is the Model*. Supplied DOCX. Read in full; §§1–3 supply the finite-checking and protected-query distinctions. File identity is pinned without inventing a version number.

**S2.** Pang, C. D. *The Context Draws a Map*, v1.0, 8 August 2026. Recovered release package; selected §§1–2, 4–6, 10.4 and 12–13 inspected. Historical Library versions remain distinct.

**S3.** *Honesty PCP*, v1.0. Companion document in the Map release; read in full. Proposed context scaffold, not validated behavioral evidence. Contributor detail remains as recorded in the source.

**S4.** Pang, C. D. *The Context Sets a Rhythm*, v0.1, 31 August 2026. Supplied DOCX. Introduction, receiver/readout, AI adaptation, reset and experiment-control passages inspected; full reading inventory is retained locally.

**S5.** Pang, C. D. *MIND*, v0.4, packaged Markdown. Sections 2–4, 7–10 and selected experimental controls in §11 inspected. Includes the protected-transfer and capsule criteria used here. Source retains its own draft and unrun-study status.

**S6.** Pang, C. D. *PAL v2.4 Mechanical Structural Spine*. Separate current comparison source. Selected projected-return, receipt and non-retroactive-authority passages inspected; not a recovered Atomic Promotion implementation contract.

<!-- PAGEBREAK -->

## References continued

**C1.** Pang and Hearthline. Selected current-chat exchange, 8 October 2026. Chris proposes pinch; Hearthline proposes inflection; Chris adopts pinch as event, inflection as what carries afterward, and seed for a further perspective or its potential. The local revision record retains selected exact excerpts and the subsequent clarification that exchange and parameter update are distinct. It is not a full-chat export or an independent experiment.

**A1.** Pang and Hearthline. *Context Parallax Ancestry Study Volume 1*, private source-checked collection, 8 October 2026. Five case records consulted for v0.2: V01-001, V01-003, V01-004, V01-006 and V01-014; plus the paper note and verification summary. The volume reports twenty cases, eleven selected conversations, twelve represented paths and sixty-three checked excerpts. Public claims here are limited to the described sequences; underlying scientific claims are not independently certified.

**L1.** Clark, H. H., and Brennan, S. E. (1991). Grounding in communication. In *Perspectives on Socially Shared Cognition*, 127–149. [Author-hosted chapter](https://web.stanford.edu/~clark/1990s/Clark,%20H.H.%20_%20Brennan,%20S.E.%20_Grounding%20in%20communication_%201991.pdf). Opening discussion of common ground, purpose, acceptance and repair inspected.

**L2.** Grosz, B. J., and Sidner, C. L. (1986). Attention, Intentions, and the Structure of Discourse. *Computational Linguistics*, 12(3), 175–204. [ACL Anthology](https://aclanthology.org/J86-3001/). Introduction and opening framework inspected.

**L3.** Zhao, Z., Wallace, E., Feng, S., Klein, D., and Singh, S. (2021). Calibrate Before Use: Improving Few-Shot Performance of Language Models. *Proceedings of ICML*, PMLR 139, 12697–12706. [Primary proceedings](https://proceedings.mlr.press/v139/zhao21c.html). Abstract, introduction and opening problem setup inspected.

**L4.** Min, S., Lyu, X., Holtzman, A., Artetxe, M., Lewis, M., Hajishirzi, H., and Zettlemoyer, L. (2022). Rethinking the Role of Demonstrations: What Makes In-Context Learning Work? *EMNLP*, 11048–11064. [ACL Anthology](https://aclanthology.org/2022.emnlp-main.759/). Abstract and introduction inspected; findings are scoped to the paper's tasks and models.

**L5.** Hewitt, J., and Liang, P. (2019). Designing and Interpreting Probes with Control Tasks. *EMNLP-IJCNLP*, 2733–2743. [ACL Anthology](https://aclanthology.org/D19-1275/). Introduction and control-task discussion inspected. Representation probing is distinguished from conversational prompting here.

**L6.** Kamath, A., Jia, R., and Liang, P. (2020). Selective Question Answering under Domain Shift. *ACL*, 5684–5696. [ACL Anthology](https://aclanthology.org/2020.acl-main.503/). Abstract and opening coverage/accuracy discussion inspected.

**L7.** Madaan, A., et al. (2023). Self-Refine: Iterative Refinement with Self-Feedback. [arXiv 2303.17651, version 2](https://arxiv.org/html/2303.17651v2). Abstract and §§1–2 inspected. The version is pinned for the methodological comparison; experiments were not rerun.

<!-- PAGEBREAK -->

## References continued

**L8.** Pickering, M. J., and Garrod, S. (2004). Toward a mechanistic psychology of dialogue. *Behavioral and Brain Sciences*, 27(2). [Institutional copy](https://www.pure.ed.ac.uk/ws/files/11823730/Toward_a_mechanistic_psychology_of_dialogue.pdf). Abstract and opening introduction, printed pp. 169–170, inspected for v0.2; the full target article, commentaries and responses were not audited.

**L9.** Zhang, Y., Xiang, T., Hospedales, T. M., and Lu, H. (2018). Deep Mutual Learning. *CVPR*, 4320–4328; [arXiv preprint 1706.00384](https://arxiv.org/abs/1706.00384), submitted 2017. Abstract inspected for v0.2. Results are scoped to the paper's vision benchmarks, not conversational LLMs.

**L10.** Wu, C., Wu, F., and Huang, Y. (2021). One Teacher is Enough? Pre-trained Language Model Distillation from Multiple Teachers. *Findings of ACL-IJCNLP*. [arXiv 2106.01023](https://arxiv.org/abs/2106.01023). Abstract inspected for v0.2. MT-BERT uses multiple teacher models to train a student; no experiment from that work was rerun.

**L11.** Akiba, T., Shing, M., Tang, Y., Sun, Q., and Ha, D. (2025). Evolutionary Optimization of Model Merging Recipes. *Nature Machine Intelligence*. [arXiv 2403.13187v2](https://arxiv.org/abs/2403.13187v2). Abstract and publication identity inspected for v0.2. Parameter and data-flow composition are neighboring methods, not validation of CPX.

**C2.** Pang and Hearthline. Selected visible conversations about quiet, surprise, correction and work. Excerpts recorded privately for v0.3 on 9 October 2026; no original timestamps invented. Development material, not a full export or controlled sample. The source concordance records selection and limits.

**D1.** CPX v0.2 author-credit edit. Pinned before/after manuscripts differ by two literal edits; remaining text is identical. CREDIT_EDIT_RECORD.json records hashes and comparison scope. The private earlier manuscript is not redistributed.

**L12.** Cowan, N. (2008). What are the differences between long-term, short-term, and working memory? *Progress in Brain Research*, 169, 323–338. [Author manuscript in PMC](https://pmc.ncbi.nlm.nih.gov/articles/PMC2657600/). Abstract, historical opening and Description of three kinds of memory read for v0.3; later evidence review not audited. Human-memory comparison, not an LLM mechanism.

**L13.** Schegloff, E. A., Jefferson, G., and Sacks, H. (1977). The preference for self-correction in the organization of repair in conversation. *Language*, 53(2), 361–382. [Article copy](https://troyspier.com/assets/files/bibliographies/discourse/schegloff_jefferson_sacks_preference_self_correction.pdf). Abstract and opening discussion on printed pp. 361–363 read for v0.3. The later analysis was not audited or replicated.

<!-- PAGEBREAK -->

## References continued

**C3.** Pang and Hearthline. Selected visible continuation, 9 October 2026. Home, signal inspection, attention loops, context navigation, evidence pointers, journals and memory texture. Forty visible user/assistant message records were retained locally with timestamps, byte offsets and per-record hashes. Selection was thematic and includes intermediate commentary. It excludes reasoning records, encrypted content and tool output; it is not a complete conversation export or a controlled sample.

**C4.** Supplied conversation beginning “You mean Gloss' room?” Read in full for v0.4. Chris's correction distinguishes preserving a receipt and its source from continuously retaining its discovery history in active computation. The conversation's numeric hardware claims, source-page claims and older framework citations are not independently verified by inclusion here. The manuscript uses the correction and implementation distinction, not those figures as measured results.

**L14.** Packer, C., Wooders, S., Lin, K., Fang, V., Patil, S. G., Stoica, I., and Gonzalez, J. E. (2024). MemGPT: Towards LLMs as Operating Systems. [arXiv 2310.08560v2](https://arxiv.org/abs/2310.08560v2). Abstract and bibliographic identity inspected on 9 October 2026. First submitted in 2023. Full method, experiments and code not audited or rerun.

**L15.** Yao, S., Zhao, J., Yu, D., Du, N., Shafran, I., Narasimhan, K., and Cao, Y. (2023). ReAct: Synergizing Reasoning and Acting in Language Models. [arXiv 2210.03629v3](https://arxiv.org/abs/2210.03629v3). ICLR camera-ready version; first submitted in 2022. Abstract and bibliographic identity inspected on 9 October 2026. The author project description at https://react-lm.github.io/ was additionally inspected for v0.5 for action-observation interleaving. Full experiments and code were not audited or rerun.

<!-- PAGEBREAK -->

## References continued

**C5.** Pang and Hearthline. Current visible exchanges on sustained language, whole-pattern benefit and harm, shared meaning, and witnessed consequences, carried into CPXv0.5KEY and its follow-up on 10–11 October 2026. Development material selected by the participants, not a controlled sample. The original hypothesis and its intended whole-world scope are retained in the key.

**C6.** Supplied private conversation beginning “I had another weird thought.” Read in full for key revision 2: 597 lines, with a byte-pinned private copy. Selected passages concern informational position, generation and workflow scale, reconstruction and continuity. Includes literary material not reproduced here. Historical recollections and corrected physical metaphors are not adopted as new factual premises.

**R01.** Godfrey-Smith, P., and Martinez, M. (2013). Communication and Common Interest. *PLOS Computational Biology*, 9(11), e1003282. [Published article](https://doi.org/10.1371/journal.pcbi.1003282). Model, measures, equilibrium results and discussion, PDF pp. 1–6, inspected. Information and preference alignment are not total welfare.

**R02.** Martinez, M., and Godfrey-Smith, P. (2016). Common Interest and Signaling Games: A Dynamic Analysis. *Philosophy of Science*, 83(3), 371–392. [DOI](https://doi.org/10.1086/685743). Author eprint §§2, 3 and 5, pp. 5–10 and 21, inspected; published identity checked separately. No replication or indefinite-stability result claimed here.

**R03.** Kirby, S., Tamariz, M., Cornish, H., and Smith, K. (2015). Compression and communication in the cultural evolution of linguistic structure. *Cognition*, 141, 87–102. [DOI](https://doi.org/10.1016/j.cognition.2015.03.016). Published §§1.1–1.2, 2.2, 3.1–3.3 and 4 inspected. CPX's six-label learner is not a replication of their models or human study.

**R04.** Dingemanse, M., et al. (2015). Universal Principles in the Repair of Communication Problems. *PLOS ONE*, 10(9), e0136100. [DOI](https://doi.org/10.1371/journal.pone.0136100). Methods, results and discussion, PDF pp. 3–11, inspected. Cross-linguistic repair evidence does not establish the welfare or survival claim posed here.

**R05.** Sperber, D., Clement, F., Heintz, C., Mascaro, O., Mercier, H., Origgi, G., and Wilson, D. (2010). Epistemic Vigilance. *Mind & Language*, 25(4), 359–393. [DOI](https://doi.org/10.1111/j.1468-0017.2010.01394.x). §§1, 3, 4 and 9 inspected in the author-hosted published copy. Theoretical neighbor for understanding, acceptance and selective checking.

<!-- PAGEBREAK -->

## References continued

**R06.** Pearl, J. (2010). An Introduction to Causal Inference. *International Journal of Biostatistics*, 6(2), Article 7. DOI 10.2202/1557-4679.1203. [Corrected author reprint](https://ftp.cs.ucla.edu/pub/stat_ser/r354-corrected-reprint.pdf), UCLA report R-354, March 2011. Introduction, §§2.1–2.2 and §3.2.1 through Definition 2 inspected. Used for the observation/intervention and identifiability distinctions, not as validation of CPX.

**R07.** Vaswani, A., et al. (2017). Attention Is All You Need. [arXiv 1706.03762v7](https://arxiv.org/html/1706.03762v7), revised 2 August 2023. §§3–3.1 inspected for autoregressive output and layered computation. This is a description of that architecture, not a provider-internal account of the present authoring session.

**E1.** Hearthline. CPX foundation toys, corrected run-002, prepared for CPXv0.5KEY. Code, configuration, exact grids, 960 seeded chains, summaries, cost contrasts, self-checks and run history retained in the companion's evidence/foundation directory. Superseded run-001 remains separately identified. The scoped research key and source readings are retained under research.

**E2.** Hearthline. CPX05-WITNESS-01, 11 October 2026. Exact causal worlds and decision grid. Code, configuration, 288 decision rows, 16 causal-distribution rows, summary and checks retained in evidence/witness. Local self-review; no independent or Lean validation.

**E3.** Hearthline. CPX-MAINTAIN-01 preparation, 11 October 2026. Twelve fictional scenarios, 144 prompt records and a deterministic support baseline under studies/maintain. Frozen before model outcomes; all model arms NOT_RUN. Record identifiers encode the authored support contract and are not a semantic parser.

### Companion material

The inspection package contains the paper in Markdown, Word and PDF, source and claim maps, original method and unrun protocols, retained toy evidence including the superseded run, new pilot fixtures, baseline outputs and verification tools. A delivery report identifies the artifact and archive checks actually completed. Full private conversations and publication source copies are excluded. The source lock identifies earlier inputs without conferring authority on them.

**End of working paper v0.5**
