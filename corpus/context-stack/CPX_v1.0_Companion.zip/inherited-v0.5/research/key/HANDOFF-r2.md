# CPX v0.5 key revision 2

Revised 11 October 2026 for Chris's review. The current manuscript remains v0.4. The new key is `CPXv0.5KEY-r2.md`, with a reading copy at `output/pdf/CPXv0.5KEY-r2.pdf`. The original key, PDF and evidence manifest remain preserved.

This revision integrates the completed CPX05-WITNESS-01 study and the supplied chat about situated perspective, steering and continuity. It treats reconstruction from retained evidence as one possible continuity mechanism. It makes minimum carry relative to the future question, and separates source history, fidelity and later useful behavior.

The proposed CPX-MAINTAIN-01 pilot remains 12 scenarios × 3 carry conditions × 4 arms = 144 calls, NOT_RUN. New continuity cases occupy existing slots; no additional experiment is required before drafting. Authorizing a changed goal is different from treating arbitrary incoming content as authority to redirect work.

The next selected task can be the scoped v0.5 manuscript described in this key. Paid model calls still need a provider/model choice and spending ceiling. This key revision performs no live model trial, weight update, public release or application change.

Read `amendments/2026-10-11-perspective/REVIEW.md` for the full review, retained corrections and source locators. `SOURCE_LOCK.json` in that folder pins the entire supplied conversation and prior inputs; its private transcript copy includes user-supplied literary material and must stay out of the shareable paper. `revision.diff` records the exact editorial changes.

Verification and rendering status are recorded in `VERIFICATION-r2.json` and `DELIVERY_MANIFEST-r2.json`. These are author-run checks, not independent scientific review. The large questions about perspective, language welfare and choosing useful observations remain open without extending this task.
