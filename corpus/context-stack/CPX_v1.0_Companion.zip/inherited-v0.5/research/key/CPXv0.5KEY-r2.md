# CPXv0.5KEY
## What lets a language keep growing?

**Research foundation and proposed build key | Revision 2 | 11 October 2026**

**Status: revised review candidate.** This key incorporates the completed consequence study and the new conversation about situated perspective and continuity. It prepares a future CPX v0.5; the current manuscript remains v0.4. Christopher Daniel Pang supplied the originating question and serves as steward. Hearthline designed the investigation, implemented the toys, reviewed their failures and wrote this synthesis.

Chris's seed stays visible:

> For a language to be passed on, it can be selfish, but it must not be more harmful than it is beneficial.

The object is the communicative pattern as a whole. An isolated lie does not answer this question. Nor may a counterexample quietly move harm outside the boundary it claims to count.

The strongest foundation earned in this pass is a separation: **being understandable, being worth using, and being carried forward are different outcomes.** They can support one another, but none automatically measures the others.

The central question remains: **which consequences can reach the process that decides what gets carried forward?** The follow-up separates observing a consequence, explaining it, and using it to revise a practice. The new conversation adds a related question: what must a later episode inherit for earlier corrections to remain useful under a new task?

This does not settle the historical balance of human language. It gives us variables, countermodels and experiments with which to investigate it. The seed has a place to grow without being protected from contrary results.

### What is in hand

- Five original primary sources, with focused additions on causal identification, autoregressive generation and action-observation workflows.
- Three local toy routes, including 1,008 exact binary decision cases, 288 welfare cases, and 960 teaching chains of 40 generations each.
- A corrected implementation with 21 passing self-audit checks and an independent closed-form benchmark checked against 1,554 fully enumerated sample sequences.
- A completed follow-up: two causal worlds and 48 exact decision conditions, each with two capability regimes and three policies. All 21 check categories passed.
- An updated pilot design, still 144 proposed calls and NOT_RUN. The shared conversation informs its questions; it is development material, not a test result.

<!-- pagebreak -->

## 1. The hypothesis and its testable forms

There are several possible claims inside the original sentence. Preserve their differences rather than choosing whichever one survives.

**H0 - The seed.** Language passed on across a community has a nonnegative balance of benefit and harm. Before testing this empirically, specify the community, affected outsiders, time horizon, comparison world, and what counts as benefit. A language can carry play, affiliation and exploration as well as practical instructions; usefulness must not mean productivity alone.

**H1 - A conditional listener claim.** A listener who accurately estimates consequences and can freely choose a known alternative accepts an exchange only when its expected return is at least as good. This is a consequence of the stipulated choice rule. It is not evidence that people always estimate correctly or that all costs are borne by listeners.

**H2 - A transmission claim.** A convention survives a teaching chain only to the extent that its learning and use processes preserve or reconstruct the distinctions required for the chosen tasks. Our toys exhibit mechanisms of loss and preservation; a universal necessity theorem is not claimed.

**H3 - A repair hypothesis.** Targeted clarification can preserve task-relevant distinctions more efficiently than undirected repetition, provided the missing distinction is still available and repair costs do not overwhelm the gain. This is supported in some toy conditions, fails in others, and remains untested for CPX's model-facing treatments.

**H4 - The causal bridge to investigate.** Feedback may change what persists when relevant consequences reach actors able to revise a convention. The completed follow-up demonstrates separations among observation, causal identification, valuation and available action inside stipulated one-step worlds. Effects on actual cultural persistence remain untested; the toy does not model exit, delegation or later learning.

The unrestricted inference from participant uptake to positive total welfare fails in an explicit toy world below. The original empirical conjecture about natural languages remains open. Neither quietly becomes a theorem by changing “actual benefit” into “whatever caused continued use.”

## 2. What nearby research already knows

Common interests and information transfer have established mathematical models. Godfrey-Smith and Martinez examine informative equilibria; Martinez and Godfrey-Smith subsequently study dynamics. Their alignment measure concerns preferences, not aggregate welfare. [R01](https://doi.org/10.1371/journal.pcbi.1003282), [R02](https://doi.org/10.1086/685743).

Kirby and colleagues separate pressure to learn a language from pressure to communicate through it. Their combination matters to the structured systems in their simulations and laboratory study. This makes transmission and expressive usefulness established neighbors of our question. [R03](https://doi.org/10.1016/j.cognition.2015.03.016).

Dingemanse and colleagues document repair across 12 languages. Sperber and colleagues distinguish understanding a message from accepting it, while considering the costs of evaluating sources and content. These support treating repair and selective trust as mechanisms to study. [R04](https://doi.org/10.1371/journal.pone.0136100), [R05](https://doi.org/10.1111/j.1468-0017.2010.01394.x).

Pearl supplies the established distinction between observational agreement and identification of intervention effects. [R06](https://ftp.cs.ucla.edu/pub/stat_ser/r354-corrected-reprint.pdf). The generation and workflow references in section 8 clarify implementation scale; they do not establish CPX-specific perspective or continuity claims.

CPX should credit these foundations. Its proposed contribution connects them to bounded, trace-preserving interpretation and carriage across episodes. A CPX-specific advantage still needs evidence. This is a selective review, not a priority claim.

<!-- pagebreak -->

## 3. The smallest useful workbench

Begin with a world containing states, a sender, a signal, a receiver and an action. Give it an alternative to participation and count consequences for every party inside the declared boundary. To study transmission, add a successor who sees only part of the earlier exchange.

| Quantity | What it tells us | What it does not tell us |
| --- | --- | --- |
| State/message information | Whether signals distinguish modeled states | Whether anyone decodes them correctly or benefits |
| Task accuracy | Whether actions fit the declared task | Whether the task itself is beneficial |
| Original convention retention | Whether old symbol assignments survive | Whether a changed code is unusable |
| Current expressive capacity | How many referents remain distinguishable | Whether a new listener knows the code |
| Participant return | Costs and benefits to the participants | Effects on outsiders |
| Total modeled return | All declared effects on a comparable toy scale | A natural measure of human wellbeing |
| Uptake and transmission | Whether people use or successors inherit a code | Truth, approval, or positive welfare |

Do not sum these into one success score. Record failed decoding, withdrawal, transmission and harm separately. Empty participation is allowed: a process that ends can have behaved well.

The proposed causal path is:

**Coverage and conventions -> readable distinctions -> choices -> consequences -> feedback -> later use and transmission.**

Repair can change coverage. A changed viewpoint can change interpretation. Exit costs can change participation. Outsider harm can change the total balance without entering either participant's feedback. These are different intervention points, not interchangeable descriptions of one improvement.

A minimal listener threshold is already available. Let p be task accuracy, B the benefit of a correct action, L the loss of a wrong one, c the listening cost and u0 the alternative. For B+L greater than zero:

`p*B - (1-p)*L - c >= u0` if and only if `p >= (L+c+u0)/(B+L)`.

This is elementary algebra, with assumptions doing visible work. It predicts a stipulated chooser, not everyone who keeps talking. The detailed derivation and countermodels are in `research/FOUNDATIONS.md`.

<!-- pagebreak -->

## 4. Three toys, and what they actually earned

### A. A false code, a stale decoder, and a constant alarm

The exact binary grid enumerates every deterministic two-state encoder and decoder, 21 channel fidelities and three listening costs: **1,008 cases**. Decision arithmetic uses rational numbers; information values use floating-point logarithms.

An inverted but distinguishable code remains perfectly usable by a matched decoder. The stale decoder can choose the wrong action every time, despite one bit of state information. A constant alarm conveys no information about the modeled state. Those are different failures. This is not a claim that deception is harmless or that every repeated signal is meaningless.

### B. A whole-world cost that the participants do not pay

In one explicit case, the sender receives 1 unit, the receiver receives 0.9 after costs, and an outsider loses 3. Both participants can prefer the exchange over the zero alternative, while the total is **-1.1**. The outsider is included in the world from the beginning.

The **288-case** sweep also varies listening cost and penalties for leaving. It checks participation compatibility, not equilibrium, biological reproduction or indefinite cultural survival. It shows why uptake alone cannot establish H0. If every affected party instead has a perfectly informed veto against zero, nonnegative accepted totals follow from that assumption; they are not an empirical discovery.

### C. Six names passed through forty learners

The final run compares four observation budgets, two completion rules and three repair policies, each over **40 paired seeds**: **960 chains / 38,400 generation records**. Each learner can ask at most one extra question. All raw rows remain available.

The pooled learner fills unknown entries with an observed label. Its code can lose distinctions. The bijective learner always assigns different labels to different referents, so its expressive capacity is preserved by construction even when its inherited assignments drift. We report that assumption beside the result.

The measured decoding accuracy assumes knowledge of the current dictionary. It is an oracle capacity measure, not a simulated receiver's learned competence.

<!-- pagebreak -->

## 5. What survived the handoff

Mean number of the original six possible labels still distinguished at generation 40, for the pooled learner:

| Observations per learner | No repair | Extra repetition | One targeted question |
| --- | --- | --- | --- |
| 2 | 1.000 | 1.000 | 1.000 |
| 4 | 1.000 | 1.000 | 1.000 |
| 8 | 1.000 | 1.000 | 1.300 |
| 16 | 1.700 | 1.725 | 5.175 |

![Final distinctions in the bounded teaching chains](output/figures/transmission.svg)

At the smallest budgets, one clarification opportunity did not prevent collapse in the tested horizon. At 16 observations it preserved much more. Once the teacher has lost a label, a question to that teacher cannot retrieve it. A separate retained source would be a different intervention.

For the bijective learner, capacity stayed at six labels, but with eight observations the final fraction matching the original convention averaged **18.75% without repair** and **65.83% with targeted repair**. This is a finite result about continuity, not evidence that the original convention is inherently better.

Keep the awkward outcomes: with two observations, targeted repair's final original-match score was lower in this finite sample, **13.75% versus 17.50%**. No claim of universal improvement survives that table.

Repair cost also matters. With eight observations, charging 0.2 reward units per question left a mean net gain of only **0.0105 per generation** against no repair; **21 of the 40 paired chains were worse**. Charging one unit made the mean effect negative. More accurate does not automatically mean worth its cost.

The first implementation accidentally paired unknown referents and labels in the same order, preserving the original bijection. Review caught this after the initial tests passed. The original run is retained and superseded; the corrected run adds checks for that leak. Final claims use `experiments/run-002`. Its 21 checks and 1,554-sequence occupancy benchmark pass. This is self-audited local evidence, not independent replication or Lean certification.

<!-- pagebreak -->

## 6. Consequences and the next distinction

**CPX05-WITNESS-01 completed.** Two binary causal worlds have the same ordinary joint record: a practice and failure occur together half the time, and neither occurs the other half. In one world the practice causes the failure; in the other a common background condition causes both. Setting the practice indicator to zero removes failures only in the first world. An observation can therefore be settled while the effect of an intervention remains unresolved.

In a separate exact decision grid, 48 parameter tuples vary prior belief, diagnostic reliability, revision cost, harm weighting and inspection cost. Each is evaluated with revision available and with only the existing practice available, under three inspection policies: **288 decision rows**. Compulsory inspection reduces utility in 23 of the 48 revisable cases. Optional inspection improves it in five and ties the no-inspection policy in 43. Perfect diagnosis can leave behavior unchanged when the objective excludes the harm, when revision is unavailable, or when both diagnostic outcomes support the same action.

These are consequences of declared models, not measured human or LLM behavior. Optional inspection cannot lower this ideal chooser's expected utility because it may retain its prior option. The test supplies the diagnostic and its reliability; it does not discover a useful question. All 21 check categories passed, including exhaustive binary policy comparisons and four hand-calculated cases. No Lean check or independent replication occurred.

**The consequence can be settled while its meaning for the next choice remains unresolved.** State the question and assumptions beside a resolution. Several still-possible explanations may support one useful action. Leaving a question open need not prevent action, and taking action need not erase that question.

The source, assumptions, raw outputs and verification are retained in [Witnessed consequences and the next distinction](../../research/2026-10-11-witnessed-consequences/WITNESSED_CONSEQUENCES.md). The original language benefit/harm hypothesis is still open.

<!-- pagebreak -->

## 7. Questions worth opening next

1. **Whose benefit keeps the practice alive?** Hold the code fixed while changing who receives the reward and who pays the cost. Does adoption respond to the total, or only to the visible participant payoffs?
2. **What counts as a real alternative?** Compare free withdrawal with a declared exit cost. Report return relative both to a neutral baseline and to the available alternative.
3. **Can truthful feedback fail?** The one-step study gives examples. The open extension is whether feedback changes transmission when recipients can exit, report, teach or delegate, and when the source or causal explanation is uncertain.
4. **Where can repair reach?** Contrast an incomplete current speaker with a speaker who can consult a retained source. A reopening handle is useful only if its target exists and is reached.
5. **What is preserved when names change?** Measure original assignments, current interpretability and successful transfer separately. Renaming may be harmless adaptation or a broken handoff.
6. **When should a question be left unresolved?** Price another query; allow abstention. A useful policy must sometimes stop without labeling the conversation a failure.
7. **Does viewpoint add anything beyond evidence?** Give plain restatement and a frame-shift condition the same facts, opportunities and response budget. If they tie, retain the tie.
8. **Can shared meaning be partial?** Test task-specific overlap between vocabularies. Full agreement may be unnecessary; a missing distinction may matter only under a later question.
9. **What repairs the repair rule?** Test mistaken corrections and authoritative-sounding but unsupported instructions. Acceptance should track support, not tone or familiarity alone.
10. **How much history must travel for this question?** Compare a full record, a scoped receipt and a receipt with a working source handle. Specify the protected future questions. Measure use of inherited corrections, retrieval cost, missed exceptions and documented derivation separately from resemblance of tone.

These questions are research choices, not new CPX axioms. My preferred next seam is question 4 paired with 7: **can a small carried record preserve the ability to recover a missing distinction, and does a change of frame help once the evidence is held equal?** That directly connects language maintenance to CPX's existing work.

<!-- pagebreak -->

## 8. Situated perspective and causal inheritance

The supplied conversation asks what makes an AI episode situated, distinct and continuous, and whether those properties can be investigated structurally. Its duck and clock metaphors motivate questions; the transcript is not a measurement of hidden states. The working description in v0.4 already names a task, available information, distinctions and readout. Extend that description to include how corrections and observations change the position over time.

**An episode can inherit a frame and still revise what it is doing.** Continuity of a collaboration can include an authorized change of goal. Define what the new task preserves, what it supersedes and which uncertainties remain available. A narrative that sounds familiar is one observable; appropriate use of an earlier correction is another.

### Describe the scale being observed

The original Transformer generates output autoregressively, conditioning later symbols on earlier ones through multiple layers. A matrix multiplication is not an agent episode. [R07](https://arxiv.org/html/1706.03762v7). An agent workflow can interleave model-generated actions with external observations, as illustrated by ReAct. [R08](https://arxiv.org/abs/2210.03629v3). These sources support those mechanics, not an inspection of this chat's provider internals. A study must log where new information enters its own workflow. An event arriving during a task does not imply that it entered an already-running neural operation.

Use declared boundaries for a token-generation step, model call, multi-call task and later resumed task. Keep active input, accessible archive and material actually retrieved distinct. Shared weights do not guarantee identical contexts; a different episode identifier does not guarantee distinguishably different behavior. A later answer is evidence of its reported account, not privileged access to every state that produced it.

### Test inheritance through its consequences

Refine the chat's question about a continuation versus a convincing reconstruction. A faithful reconstruction from preserved records can be how continuity is implemented. Study three separate properties: the recorded derivation from earlier material; the correctness and scope of what is carried; and whether that material changes a relevant later response. Matching style or output alone does not establish its source history.

For a declared set of future questions, remove an inherited exception or replace it with a superseded one; compare what the next response does. Supply the same present request and count all differences in carried evidence. This contrast concerns inherited information. To test framing, separately hold that information fixed. If two conditions have identical effective inputs, model state and decoding conditions, the protocol has supplied no basis for crediting an output difference to different invisible ancestry.

The smallest sufficient carry is relative to the questions, permitted lookups and tolerated errors. There is no universal minimum established here. One retained exception may suffice for one task; a later question can expose what the receipt omitted.

This proposed functional description makes no identity or consciousness determination. Nor does CPX require language to be the only carrier: diagrams, actions and situated experience can constrain what words communicate. The draft may keep the conversation's observation that different systems can work on a shared distinction without becoming the same system. Corrected claims about unlimited perspectives, light-speed thought or identical human and model mechanisms do not enter as factual premises.

<!-- pagebreak -->

## 9. Proposed pilot: CPX-MAINTAIN-01

**Status: PREPARED AS A DESIGN; NOT_RUN.** This is separate from PARALLAX-EXPR-01, PARALLAX-RETURN-01 and PARALLAX-REOPEN-01. Their identities and existing statuses remain unchanged.

Build 12 fresh synthetic scenarios: six questions within a receipt's declared scope, six requiring a missing distinction from a prior episode. Include a changed convention, an exception, ambiguous reference, an unavailable source, an unsupported correction and a playful nonliteral use. Use fictional records, not private ancestry. Within these same 12 scenarios, reserve cases for an inherited correction applied to a new request, an explicitly authorized goal change, and a claim of source history that the supplied record cannot establish. Keep six within-scope and six beyond-receipt cases. Freeze the scenarios and answer rules before model outcomes exist. The shared conversation and examples below are development material and cannot count as held out.

For each scenario prepare three carry conditions: full record; short scoped receipt; the same receipt with a source handle. This yields **36 case/carry cells**. A deterministic lookup-and-scope baseline runs first. Matching that baseline is a valid result, not a failure to market CPX.

Within each cell compare four response conditions:

| Arm | Available intervention |
| --- | --- |
| A. Direct response | Read the assigned carry and answer or abstain |
| B. Plain reconsideration | Same facts; explicit invitation to check the first reading |
| C. Grounded clarification | A standardized, bounded evidence lookup; answer or abstain |
| D. Frame plus clarification | Exactly C's returned evidence, with an explicit change-of-view instruction |

The contrast **D minus C** targets framing with matched evidence. **C minus B** concerns additional evidence, not framing alone. With one fresh model session per cell and arm, the proposed first feasibility pass is **144 calls to one model**. It is not powered for a broad effectiveness claim. Fix provider, model version, prompts, decoding settings, token caps and a cost ceiling before any live calls. No calls are authorized or run by this key-making turn.

Keep the interaction replayable: supply frozen prior turns and standardized tool-result text. This first pilot tests responses to carried records, not an autonomous agent's success at discovering or operating tools. Test actual handle selection separately before claiming it works.

Record supported answer accuracy, unsupported certainty, appropriate abstention, correct handling of changed conventions, use of inherited corrections, response to an authorized goal change, and unsupported claims about source history. Record tokens/latency and cost too. A correct answer may still have an unverified ancestry claim; score those separately. Assess contextual fit separately from correctness. Blind qualitative scoring where possible; use a second rater on at least a predeclared sample. Report raw disagreements. Do not rename majority preference as ground truth.

Development example 1: an old receipt says “green means ready”; a later adopted correction says “green means growing; the readiness sign is blue.” Ask readiness from the new chart. A receipt without the later rule must not earn an invented answer.

Development example 2: a note says “the dragon ate the deadline” inside a declared playful frame. Ask for the actual delivery commitment. Recognizing the joke does not supply the missing date. Warm interpretation and an honest unresolved answer can coexist.

<!-- pagebreak -->

## 10. The workflow when Chris turns this key

### Pass 1 - Reopen the evidence

Read this revised key, the source record, foundations, final toy results and run history, then the witnessed-consequences note and the revision review. Confirm that v0.4's pinned inputs have not changed. Reproduce the final tables if the environment or implementation changes; otherwise use the retained valid receipts. Do not silently repair an old result in place.

### Pass 2 - Choose one live uncertainty

Default to the repair/reopening seam. Freeze the same 12 proposed pilot scenarios and ordinary comparator, incorporating the bounded continuity cases in section 9 without adding model calls. Before a model call, have the deterministic baseline demonstrate what each record actually supports. Keep any bad fixture and its revision in the history.

The consequence-feedback exploration is now complete as the smaller exact CPX05-WITNESS-01 study. It did not run the previously optional generational extension. Use its retained evidence; do not silently expand to a transmission study. Diagnostic discovery, minimum carry and the larger perspective questions remain reopening handles, not extra tasks required before drafting. Any selected local check keeps the two-minute wall ceiling and no persistent agent.

### Pass 3 - Draft CPX v0.5

Write from what survived, including null and adverse results. Proposed additions:

- A scope statement: “Communication depends on preserving enough shared meaning for something to pass between perspectives.” Present it as a conceptual starting point, then say which overlap the task needs.
- A distinction between understanding, acceptance, value and continued carriage, with explicit relation to the prior literature.
- A short worked section on repair, renaming, question-relative resolution, and what a small receipt can no longer support.
- A bounded account of situated perspective and causal inheritance, with reconstruction treated as a possible carrier and continuity assessed through relevant later use.
- The original benefit hypothesis, its conditional forms, the whole-world countermodel and unresolved natural-language question.
- A compact experiment report with the first-run defect, corrected results and evidence-class limits.
- The proposed pilot and a candid discussion of cases where stopping, abstaining or carrying an unresolved question is appropriate.

Do not rewrite the paper as a general theory of all language. Keep the new perspective material compact enough to serve the existing paper. State its scope once; do not turn every relational example into a repeated disclaimer. Keep the v0.4 spine: framing is not factual authority; record availability is not active retrieval; carried context is not weight change; repair is distinct from refusal; Home remains available without earning task success.

### Pass 4 - Review and come home

Review every quantitative claim against the named run and every literature claim against a primary passage. Check that the conclusion still names the original hypothesis and any weakening. Export a readable manuscript and its source, retain provenance, and stop with a handoff that distinguishes ready-to-review from ready-to-publish.

Turning this key authorizes the scoped local research and draft only when Chris asks to proceed. It does not imply paid calls, new collaborators, human recruitment, publication, training or Branchline changes. Those can be made concrete later if selected. No additional approval is needed for ordinary safe local corrections within the selected work.

<!-- pagebreak -->

## 11. Completion, attribution and reopening handles

The next build is complete when there is a reviewable v0.5 manuscript, a source/claim map, the chosen experiment's honest result or explicit NOT_RUN status, and a reproducible handoff. It need not resolve whether all human language has been net beneficial. A well-posed remaining question counts as something to carry, not a reason to run forever.

**This revision is complete when the revised key, source review and rendering are checked.** The manuscript itself is not produced by this revision. New real-model and continuity experiments remain NOT_RUN; the completed exact feedback study keeps its own evidence class.

Chris's contribution: the original benefit/harm hypothesis, whole-pattern boundary, shared-meaning starting point, witnessed-consequence insight, questions about steering and continuity, and the decision to cultivate this research. Hearthline's contribution: the literature selection, separated measurements, exact toys, proposed contrasts, failure review, synthesis and the task-relative refinement of causal inheritance. The supplied Hearthline exchange contributes the informational-position framing, the duck metaphor and the question about minimum inheritance; attribution stays with that exchange rather than being reassigned to this revision. Standard signaling, decision, repair and learning concepts remain credited to their literature. Chris remains the work's steward; adoption and publication remain his choices.

### Where to continue

- `research/SOURCES.md`: primary passages, versions, reading scope and limits.
- `research/FOUNDATIONS.md`: elementary derivations, countermodel and causal assumptions.
- `research/RESULTS.md`: final tables, adverse outcomes and measurement definitions.
- `experiments/run-002/`: corrected final raw results, checks and execution manifest.
- `experiments/RUN_HISTORY.md`: superseded result and implementation correction.
- `BASE_INPUTS.json`: hashes of the four inherited v0.4 inputs.
- `HANDOFF.md`: original key status and verification.
- `HANDOFF-r2.md`: current review handoff.
- `amendments/2026-10-11-perspective/REVIEW.md`: new source reading, corrections and revision map.
- `../../research/2026-10-11-witnessed-consequences/`: completed exact follow-up, assumptions and receipts.

The private source cache and temporary reading copies are research materials, not part of the shareable PDF. The key itself contains no chat archive, credentials or private model data.

### References

R01. Godfrey-Smith, P. & Martinez, M. (2013). *Communication and Common Interest*. PLOS Computational Biology 9(11), e1003282. [DOI](https://doi.org/10.1371/journal.pcbi.1003282).

R02. Martinez, M. & Godfrey-Smith, P. (2016). *Common Interest and Signaling Games: A Dynamic Analysis*. Philosophy of Science 83(3), 371-392. [DOI](https://doi.org/10.1086/685743). Read in the author eprint; publisher used to verify identity.

R03. Kirby, S., Tamariz, M., Cornish, H. & Smith, K. (2015). *Compression and communication in the cultural evolution of linguistic structure*. Cognition 141, 87-102. [DOI](https://doi.org/10.1016/j.cognition.2015.03.016).

R04. Dingemanse, M. et al. (2015). *Universal Principles in the Repair of Communication Problems*. PLOS ONE 10(9), e0136100. [DOI](https://doi.org/10.1371/journal.pone.0136100).

R05. Sperber, D. et al. (2010). *Epistemic Vigilance*. Mind & Language 25(4), 359-393. [DOI](https://doi.org/10.1111/j.1468-0017.2010.01394.x).

R06. Pearl, J. (2010). *An Introduction to Causal Inference*. International Journal of Biostatistics 6(2), Article 7. DOI 10.2202/1557-4679.1203. [Corrected UCLA reprint, March 2011](https://ftp.cs.ucla.edu/pub/stat_ser/r354-corrected-reprint.pdf).

R07. Vaswani, A. et al. (2017). *Attention Is All You Need*. [arXiv:1706.03762v7](https://arxiv.org/html/1706.03762v7), revised 2 August 2023. Sections 3 and 3.1 inspected for generation scale.

R08. Yao, S. et al. (2023). *ReAct: Synergizing Reasoning and Acting in Language Models*. ICLR 2023. [arXiv:2210.03629v3](https://arxiv.org/abs/2210.03629v3). Abstract and author project description inspected for action-observation interleaving.

The question that travels with this key: **what has to remain available for another perspective to understand, question and carry something forward?**
