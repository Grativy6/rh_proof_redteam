# Current CPX v0.5 key

Use [CPXv0.5KEY revision 2](CPXv0.5KEY-r2.md), revised 11 October 2026, with [its current handoff](HANDOFF-r2.md).

The original `CPXv0.5KEY.md`, PDF and manifest remain the preserved first version. Revision 2 incorporates the witnessed-consequences study and the later conversation about perspective and continuity. It is a review candidate for a future manuscript; the current manuscript remains v0.4. The 144-call pilot remains NOT_RUN.
