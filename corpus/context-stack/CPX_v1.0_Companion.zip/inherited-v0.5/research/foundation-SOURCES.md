# Primary-source reading record

Read for CPXv0.5KEY, 10 October 2026 in America/New_York; acquisition timestamps are UTC and extend into 11 October. This is a bounded, selective foundation, not a systematic review or novelty clearance. Full primary texts were consulted at the passages below. Reading a passage does not reproduce its experiments or verify all its mathematical dependencies.

## R01 - Communication and Common Interest

Peter Godfrey-Smith and Manolo Martinez (2013), PLOS Computational Biology 9(11), e1003282. [Published article](https://doi.org/10.1371/journal.pcbi.1003282).

Read: model and measures, equilibrium results and discussion, published PDF pp. 1-6. Three-state cheap-talk games; alignment compares preference rankings, while information measures state/action dependence. Informative equilibria become more prevalent with common interest in the sampled games, with some informative zero-alignment cases. Equilibrium existence is not evolutionary arrival. Neither ordinal alignment nor mutual information measures total welfare. The paper does not establish that constant-sum games sustain informative equilibria. Use as the static signaling neighbor, not a proof of the seed hypothesis.

## R02 - Common Interest and Signaling Games: A Dynamic Analysis

Manolo Martinez and Peter Godfrey-Smith (2016), Philosophy of Science 83(3), 371-392. [Published identity](https://doi.org/10.1086/685743); [author eprint](https://petergodfreysmith.com/wp-content/uploads/2013/06/Martinez-GS-Common-Interest-Dynamic-2016-eprint.pdf).

Read: sections 2, 3 and 5, eprint pp. 5-10 and 21. The retained copy is a prepublication, uncopyedited version. Two-population replicator dynamics extend the static analysis. Their 15 million simulations sampled three-state games and population starts; information was assessed at t=1000, using a 0.001-bit threshold. Greater common interest strongly predicted communication in that sample, including rare low-alignment cases. The authors did not certify stability of endpoint states. This is a dynamic precedent, not an indefinite-survival result or our experiment.

## R03 - Compression and communication in the cultural evolution of linguistic structure

Simon Kirby, Monica Tamariz, Hannah Cornish and Kenny Smith (2015), Cognition 141, 87-102. [Published identity](https://doi.org/10.1016/j.cognition.2015.03.016); [University of Stirling copy](https://dspace.stir.ac.uk/handle/1893/22564).

Read: sections 1.1-1.2, 2.2, 3.1-3.3 and 4, published pp. 88-89, 93-99. Their simulations and laboratory study distinguish learnability from expressivity: their combination supports structured systems, while either pressure alone has different outcomes. Human trials included feedback and a shared coordination score. Our six-label chain borrows the question about transmission pressure, not their Bayesian learners, compositional grammar, experimental population or claimed effects. It is not a replication. Initial Edinburgh download returned HTTP 403; the public Stirling repository supplied the retained published PDF.

## R04 - Universal Principles in the Repair of Communication Problems

Mark Dingemanse et al. (2015), PLOS ONE 10(9), e0136100. [Published article](https://doi.org/10.1371/journal.pone.0136100).

Read: methods and results, PDF pp. 3-9; discussion pp. 9-11. In 48.5 sampled conversational hours across 12 languages, the authors coded 2,053 other-initiated repairs. Repair forms differed in specificity and how work was shared. This grounds repair as ordinary conversational infrastructure, rather than an exotic CPX invention. The evidence is observational and cross-linguistic; it does not experimentally establish language survival, quantify lifetime welfare, or validate our one-question intervention.

## R05 - Epistemic Vigilance

Dan Sperber, Fabrice Clement, Christophe Heintz, Olivier Mascaro, Hugo Mercier, Gloria Origgi and Deirdre Wilson (2010), Mind & Language 25(4), 359-393. [Published identity](https://doi.org/10.1111/j.1468-0017.2010.01394.x); [author-hosted published copy](https://www.dan.sperber.fr/wp-content/uploads/Epistemic-Vigilance-published.pdf).

Read: sections 1, 3, 4 and 9, published pp. 359-361, 364-365, 369-370 and 384. The account separates understanding from accepting a message and discusses source competence, interests and the costs of evaluating trust. It presents a theoretical synthesis, including assumptions its authors call speculative. It is a close conceptual neighbor to the seed, not fresh evidence that all surviving languages are beneficial. CPX can examine selective checking without making constant vigilance compulsory.

## Provenance and search limits

`SOURCE_ACQUISITION.json` preserves initial successes and the failed R03 acquisition. `SOURCE_READING_COPIES.json` records the later successful source bytes, extraction version, page counts and text hashes. PDF and text copies are in the private `.research-cache/literature` store. None is included in the shareable key PDF. R02's DOI was verified against its publisher; R05's DOI was verified against Wiley after the initial URL-based cache record.

This pass covers signaling alignment, dynamics, iterated learning, repair and trust. It does not cover language endangerment, political economy, coercive language policy, all evolutionary signaling models, or historical aggregate welfare. Those are named extensions, not silently settled questions. No claim of priority for any general communication principle is made.
