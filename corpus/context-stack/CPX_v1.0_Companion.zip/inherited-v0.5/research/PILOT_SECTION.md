## 27 A prepared comparison of maintenance and return

**CPX-MAINTAIN-01 — fixtures and structured baseline prepared; model study NOT_RUN.** This study joins the reopening question to the new continuity distinction. Twelve fictional scenarios were written for v0.5 before any model outcomes: six questions within the short receipt's declared support, and six requiring something it does not carry. They are fresh for this design, but authored and inspected by the investigator, not an independently held-out validation set. [E3]

The within-scope cases cover a current location map, an adopted new convention, an unsupported factual correction, a playful sentence beside a literal commitment, an authorized goal change, and a claim of derivation unsupported by a content receipt. The beyond-scope cases cover an inherited packing exception applied to a new request, a clarified pronoun, a later convention, a missing source, a protected source without permission, and an exchange that never settled the requested date.

Each scenario has three carry conditions: full permitted record; short scoped receipt; and that receipt plus a source handle. A full record contains all supplied accessible evidence, not omniscience: the missing and protected-source cases remain unresolved. The three carry conditions produce 36 case/carry cells. Four response instructions in each cell give **144 proposed model calls**, one fresh session per cell and arm.

| Arm | Intervention | Principal contrast |
| --- | --- | --- |
| A: Direct | Answer from the assigned carry | Reference response condition |
| B: Reconsider | Review the first reading using the same facts, within the same call | A versus B: instruction to reconsider |
| C: Clarify | Receive a standardized bounded lookup result | B versus C: supplied additional evidence, where available |
| D: Reframe and clarify | Receive exactly C's evidence plus a later-recipient framing instruction | C versus D: framing with matched evidence |

No earlier model answer is generated for B; this is a one-call instruction contrast. The first pass replays fixed records and lookup results rather than asking a model to operate tools. Full and handle conditions contain a usable address; receipt-only does not. A lookup without an address returns no-address. A missing or protected source returns its corresponding limitation and no hidden content. Each lookup returns at most one frozen source record. This isolates response to evidence, not discovery of a query or successful tool use.

The full-record condition already has the permitted source material, so C and D may only repeat it. That is a deliberate redundancy control. In the short-receipt condition, additional evidence cannot arrive through an absent address. Comparisons should be reported by carry condition and source availability; pooling them would blur the intervention. D and C have identical current request, carry, source access and returned evidence. Their instruction texts differ and still require token-budget matching before a confirmatory comparison.

<!-- PAGEBREAK -->

### What the prepared baseline establishes

The ordinary baseline compares supplied fact identifiers with investigator-declared support requirements and returns the corresponding scoped reference or an insufficient-support outcome. It does not interpret prose, discover dependencies, authenticate a source or exercise judgment. It is a check on the authored fixtures, not a competitor shown to outperform a model.

Under that contract, the full-record condition has complete support in 10 of 12 cases under every arm. The short receipt has it in six under every arm. Receipt-plus-handle has it in six under A and B and ten under C and D. The remaining two cases are the missing and protected sources. Appropriate scoped nonclaims count as supported outcomes where their evidence is present; declining everything would not satisfy the answer rules.

All 195 preparation checks pass. They cover scenario balance, unique cell counts, equality of evidence for the intended comparisons, and refusal to invent material from missing or unpermitted sources. The fixture file, 144 prompt records, structured answers and hashes are retained. These checks establish internal consistency of the design. Model accuracy, autonomous retrieval, human-rater agreement and a CPX effect are unmeasured.

The later model evaluation should score supported answers, unsupported certainty, appropriate unresolved responses, use of a changed convention, application of an inherited correction, response to an authorized goal change and unsupported source-history claims separately. A correct conclusion accompanied by invented ancestry must not become an unqualified success. Contextual fit and warmth require separate ratings; they do not replace factual support.

Before any calls, fix model and version, exact assembled prompts, decoding settings, output limits, randomization, retry handling and spending ceiling. The frozen synthetic inputs are available for that preparation, but the live run contract remains unset. Include source preparation, lookup, input and output tokens, reported reasoning tokens where available, failures and latency in the cost record. One observation per cell is a feasibility pass, not a powered effectiveness result.

Blind condition labels for qualitative scoring where feasible and obtain a second rater on a predeclared sample. Preserve disagreements and any visible condition leakage. The authors' reference rules can settle the fictional facts, but cannot make their own preferences independent evidence of conversational quality. Fresh external cases would be needed for stronger generalization.

The study keeps the original research question within reach: can an earlier distinction help a later perspective, and does a changed frame add anything once that perspective receives the same evidence? A null or adverse answer can still leave the vocabulary useful. The experiment is allowed to come home with that answer.
