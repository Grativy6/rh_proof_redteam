## 17 What lets a language keep growing?

The new question begins with Chris's proposal: “For a language to be passed on, it can be selfish, but it must not be more harmful than it is beneficial.” He meant the communicative pattern as a whole. Pointing to one deceptive message would miss that claim; moving its victims outside the accounting would also miss it. The question asks what makes continued communication possible and whether the conditions that sustain it impose a beneficial balance. [C5]

A useful starting statement is that communication depends on preserving enough shared meaning for something to pass between perspectives. Here enough is relative to the activity. Participants can coordinate on a route while disagreeing about its desirability. They can understand a warning and reject its source, or share a joke without endorsing its literal proposition. They need not share every interpretation or represent the world in the same way. This statement organizes questions; it is not a theorem about every communicative system.

The benefit hypothesis needs further specification before it can be tested. Name the population, affected outsiders, period of observation and comparison world. Include the costs of learning, repair, exclusion and continued use. Benefits can include play, affiliation and exploration; they need not be productive outputs. Expected benefit, realized return, biological fitness and moral value are different quantities. Persistence cannot itself define benefit, or the hypothesis becomes immune to contrary evidence.

| Outcome | What would be measured | What it leaves open |
| --- | --- | --- |
| Interpretability | Which task-relevant differences the signal can convey | Whether the recipient decodes them |
| Understanding and acceptance | The reading recovered and whether it is endorsed | Whether the message is true or useful |
| Task performance | Actions relative to a declared reference | Whether the chosen task benefits anyone |
| Participant and total return | Consequences inside an explicit boundary | Unmeasured effects and interpersonal comparability |
| Continued use and transmission | Uptake and what successors receive | Positive welfare, original naming or faithful use |

These outcomes should not be summed into a single favorable score. A convention may be expressive but expensive to learn; an easy convention may collapse a distinction needed later. A useful encounter may end. An accepted message may disadvantage a person absent from the exchange.

The relevant foundations are established. Signaling games distinguish aligned interests, information transfer and dynamics. Iterated-learning work separates pressures to learn and communicate. Research on repair treats clarification as ordinary conversational infrastructure, and epistemic vigilance distinguishes understanding from accepting. [R01–R05] CPX's proposed contribution is to connect those distinctions to bounded, sourced carriage and a later return, while testing whether its framing contributes anything beyond ordinary clarification.

The toys below expose missing implications under stipulated rules. Their narrower conditional results do not settle the original whole-language claim.

<!-- PAGEBREAK -->

## 18 Information, decoding and the choice to listen

The binary toy has two equally likely states, two messages and two task actions. It enumerates all four deterministic encoders and all four deterministic decoders, crossed with 21 channel fidelities and three listening costs: **1,008 exact decision cases**. Decision arithmetic is rational; mutual information uses floating-point logarithms. The final evidence is foundation run-002. [E1]

An inverted code remains informative when the decoder knows the convention. A stale decoder can instead choose the wrong action in every case, even though the message carries one bit about the state. A constant alarm carries no information about the modeled state. Those are three different situations: a renamed code, a failed coordination between code and decoder, and no distinction conveyed by this signal about this variable.

For an invertible encoder and binary channel fidelity q, state/message information is 1 − H₂(q), where H₂ is binary entropy. Fidelity zero is an invertible channel; fidelity one half erases the state. Calling q honesty would import an intention the model does not contain. Nothing here establishes that deception is harmless or that a constant signal has no affiliative or other function outside the declared task.

Suppose a correct task action yields B, an incorrect one loses L, listening costs c, and the alternative yields u₀. If p is the probability of a correct action, the stipulated receiver weakly prefers listening exactly when:

**pB − (1 − p)L − c ≥ u₀.**

For B + L > 0, rearrangement gives p ≥ (L + c + u₀)/(B + L). A threshold above one excludes every feasible p; a threshold at most zero weakly admits them all. Equality is indifference. The grid reports 360 weakly accepted cases, including 96 strictly accepted cases; these are classifications under the rule, not observations of listeners choosing to participate.

This elementary threshold locates several assumptions. The listener must know the relevant probabilities and alternative, and the payoff must include what that listener values over the selected horizon. A real participant may be mistaken, constrained, playing, maintaining a relationship or responding to consequences absent from the chosen payoff. An algebraic condition on a calibrated chooser cannot verify those premises.

The original drongo discussion motivated the question about a warning becoming unusable. The present toy performs no animal experiment. It shows why loss of a particular signal's discriminating role should be kept separate from the loss of all communication, and why high information alone does not certify a useful next action. A corrected decoder and a better signal are different repairs.

<!-- PAGEBREAK -->

## 19 Who benefits from keeping the exchange alive?

The welfare toy includes every affected party in its declared world: a sender, a receiver and an outsider. On an explicitly comparable artificial scale, one exchange gives the sender 1 unit, the receiver 9/10 after listening costs, and the outsider −3. Relative to a no-exchange baseline of zero, the total is **−11/10**, or −1.1. Both participants can prefer the exchange while the modeled whole loses. [E1]

The outsider was not added after counting the benefits. Their loss is part of the world from the outset, but does not enter either participant's choice rule. The same arithmetic can recur under unchanged conditions. That establishes a repeatable participation-compatible countermodel; it does not establish an equilibrium, reproduction, cultural transmission or indefinite survival. The distinction matters because the original hypothesis concerns what is passed on.

The full sweep contains **288 welfare cases**, varying costs, harm and exit penalties. Of the 48 free-exit cases compatible with both participants' choice rule, 25 have a negative total. These counts describe this chosen grid, not the prevalence of harmful communication. A penalized outside option is recorded separately from the neutral baseline: preferring participation to a costly exit can coexist with a loss relative to doing neither.

This defeats an unrestricted inference from participant uptake to positive total welfare. It does not settle the empirical claim that natural languages, considered as wholes over a specified history, have been beneficial. That question needs an empirical boundary and measures that these invented units do not provide. Nor does the countermodel establish a claim about the intentions or general benevolence of LLMs.

There is a simple condition under which the favorable total follows. Give every affected party accurate information and an effective veto against a zero alternative. If acceptance requires each party's return to be nonnegative, their sum is nonnegative. The proof is addition. The work is being done by full coverage, comparable returns, accurate beliefs and the veto assumption. Removing one of those conditions reopens the implication.

For CPX, the missing connection is useful: **which consequences can reach the process that decides what gets carried forward?** A correct interpretation can travel inside a system that does not register its costs to others. A report from an affected person can add relevant evidence without automatically changing the objective, available action or distribution of authority. Listening, believing and revising remain separate achievements.

Chris's seed is therefore retained as an open, scoped hypothesis. Its conditional listener version has elementary support; its unrestricted uptake-to-welfare inference fails in the toy; its claim about sustained natural languages remains unresolved. The draft does not protect the seed by changing actual benefit into whatever happened to keep the conversation going.

<!-- PAGEBREAK -->

## 20 Six names passed through forty learners

The teaching toy asks what survives a restricted handoff. Six uniformly likely referents begin with six distinct labels. Each successor observes a limited sample from its current teacher, completes a dictionary, and becomes the next teacher. The final experiment crosses four observation budgets, two completion rules and three repair policies, with 40 paired seeds per condition: **960 chains of 40 generations**, producing **38,400 generation records**. A chain is the replicate; its generations are dependent. [E1]

The pooled learner fills unseen entries with an observed label. Its label image is therefore a subset of the teacher's image. The bijective learner assigns different labels to all six referents, completing unknown assignments randomly without consulting the hidden teacher entries. Its expressive capacity is six by construction, even when its assignment differs from the original convention. These rules encode contrasting assumptions rather than discovered properties of learners.

Repair has three arms: none; an extra observation of an already observed referent; or one question about an unobserved referent, if one remains. Each learner asks at most one extra question. Paired arms share their exogenous draws. Repetition can affect the pooled fallback through observed frequency, but cannot reveal an unseen referent. Targeted repair adds information; it is not a framing-only treatment.

The endpoint mean number of distinct labels for the pooled learner is:

| Observations per learner | No repair | Repetition | Targeted question |
| --- | --- | --- | --- |
| 2 | 1.000 | 1.000 | 1.000 |
| 4 | 1.000 | 1.000 | 1.000 |
| 8 | 1.000 | 1.000 | 1.300 |
| 16 | 1.700 | 1.725 | 5.175 |

At the two smallest budgets, one additional opportunity did not prevent endpoint collapse in this finite sample. At 16 observations, targeted repair preserved substantially more distinctions. Asking the current teacher can recover something the learner missed; it cannot recover a label the teacher has already lost under this rule. Consulting an independently retained source would change the intervention.

The capacity readout assumes an optimal decoder that already knows the current dictionary. With uniform referents, its accuracy is the number of distinct labels divided by six: choose one referent for each label. This is an oracle capacity measure, not measured receiver learning. A bijection scores one even when every original assignment has changed. Preservation of naming and preservation of current expressivity must therefore be reported separately.

<!-- PAGEBREAK -->

### What repair helped, what it cost, and what failed

For the bijective learner with eight observations, the endpoint mean fraction matching the original convention was **18.75% without repair and 65.83% with targeted repair**. Keeping an original convention may help an old listener, but originality is not intrinsically the correct outcome for every task. A revised convention can remain usable if those who need it learn the revision.

The adverse result stays in view: with two observations, targeted repair's endpoint original-match mean was **13.75%, versus 17.50% without repair** in these 40 paired seeds. This finite reversal does not establish a population effect. It does rule out describing every tested endpoint as an improvement.

Cost changes the result again. A correct referent selection earns one unit and an incorrect selection earns zero. For the pooled learner with eight observations, charging 0.2 units per question leaves a mean paired net gain of **0.0105 per generation**, yet **21 of 40 chains are worse** than no repair. A one-unit question cost makes the mean contrast negative. These are readouts of fixed policies; the learner does not optimize whether to ask. For the bijective learner, capacity already equals one, so charging for a question lowers that immediate capacity-value score even when original naming is better retained.

The first implementation produced a more flattering but defective result. Its bijective completion paired unknown referents and unused labels in the same order, silently reconstructing the initial identity code. All 19 original checks passed. Inspection of the unexpectedly perfect table exposed the leak. Hearthline corrected the implementation by independently shuffling unused labels and added checks for uncertain completion and independence from unseen teacher entries. The unchanged first run is retained and marked superseded. Only run-002 supplies the results above.

The corrected program passes 21 self-audit checks. An additional exact benchmark enumerates all 1,554 sample sequences of lengths one through four and agrees with the elementary occupancy expectation 6[1 − (5/6)ᵏ]. That expectation follows by summing six indicators, each absent with probability (5/6)ᵏ. It checks sampling arithmetic, not the adequacy of the whole learning model. Neither the benchmark nor the self-checks is an independent replication or Lean proof.

The result is conditional: targeted repair can retain distinctions when the teacher still has them and the budget reaches them. It can be insufficient, costly or unhelpful on the selected readout. The experiment provides no evidence that a named CPX frame is better than plain clarification. The next comparison must hold returned evidence equal if it wants to isolate the frame.

<!-- PAGEBREAK -->

## 21 When a witnessed consequence changes the next choice

Chris suggested that a consequence might be measurable while the distinction made by its witness remains unsettled. The follow-up separates two questions: what the observation supports, and what a specified chooser can do with an explanation. **CPX05-WITNESS-01** contains two exact constructions, not a fitted study of human or model behavior. [C5, E2]

First let U be a fair binary background condition, C the use of a practice, and Y a failure. In world A, C = U and Y = C. In world B, C = U and Y = U. Both worlds produce exactly the same ordinary observations: (C,Y) is (0,0) with probability one half and (1,1) with probability one half. Setting C to zero deliberately produces different consequences: Y is always zero in A, but remains U in B.

The occurrence of failure is settled in the stipulated observational account. Whether changing the practice prevents it remains unresolved between these worlds. More passive samples of the same variables cannot distinguish them. This is an elementary example of causal non-identifiability, consistent with Pearl's distinction between observation and intervention. Additional measurements, interventions or justified assumptions could change the answer. Renaming the worlds cannot. [R06]

The second construction is a separate one-step decision model. A loss of three units is caused either by a fault in the practice or by an external cause. Revising removes it only in the fault world. The practice yields a private benefit of 19/10; revision costs c and diagnosis costs k. The chooser weights remaining harm by λ, while a separate whole-payoff readout always subtracts it in full:

**Decision utility = 19/10 − revision cost − inspection cost − λ × remaining harm.**

Two priors for the fault, three diagnostic reliabilities, two revision costs, two harm weights and two inspection costs give **48 parameter tuples**. Each is crossed with two action sets, revise-or-keep and keep-only, and three policies: no inspection, compulsory inspection, and optional inspection. The result is **288 exact decision rows**. The chooser knows the model, prior and reliability. Action ties keep the practice; inspection ties skip the diagnostic.

| Available actions | Tuples | Free diagnosis has positive value | Compulsory diagnosis lowers utility | Optional diagnosis chosen |
| --- | --- | --- | --- | --- |
| Revise or keep | 48 | 10 | 23 | 5 |
| Keep only | 48 | 0 | 24 | 0 |

These are counts in the declared grid, not frequencies in nature. Optional inspection improves utility in five revisable cases and ties in the other 43. The keep-only regime is an artificial capability comparison. Exit, reporting, delegation, sanctions and future learning are absent; this is not a proposed rule that a participant must stay.

<!-- PAGEBREAK -->

### The explanation, the objective and the available action

With prior fault probability one quarter, a perfect diagnostic, revision cost one and full harm weighting, the prior choice is to keep. Free diagnosis supports revision exactly when the fault is present and raises expected utility by one half. A distinction changes the action because it separates conditions that warrant different responses.

With prior three quarters and the same revision cost and harm weighting, the chooser already revises. Perfect diagnosis is worth one quarter because it can avoid unnecessary revision in the external-cause world. Paying one half for it is too expensive for this decision, so optional inspection is declined. An action remains available while the causal question stays open.

With zero harm weighting and positive revision cost, even perfect diagnosis does not induce revision. The explanation reaches the chooser; its consequence is absent from the objective. With revision unavailable, the same explanation cannot select that action. A signal can also change beliefs while leaving the best action unchanged under both outcomes. For example, prior three quarters, reliability three quarters and revision cost one quarter yield posteriors one half and nine tenths; full harm weighting favors revision in both.

For a fixed finite action set, fixed utility U and a known joint distribution of world θ and signal Z, free optional information has the elementary property:

**E_Z[max_a E[U(a,θ) given Z]] ≥ max_a E[U(a,θ)].**

To see why, choose a best constant action. At each signal, the conditional maximum is at least the value of that action; averaging recovers at least its unconditional value. The chooser can ignore the signal. The no-loss result is built into the ideal optimizer, rather than evidence that real agents compare options correctly. Inspection costs, inaccurate beliefs, changed actions and imperfect choice can alter the premise. Future uses count only if the utility and horizon include them.

The study passes 21 check categories comprising 1,932 evaluated assertions, including exhaustive comparison with the four binary signal policies and four hand-calculated reference cases. Its arithmetic uses exact fractions. The execution record retains a two-minute wall ceiling and one-mebibyte log ceiling; Windows did not enforce a hard memory cap. There was no model call, transmission process, Lean check or independent replication.

The connection to the language question is now specific. A consequence can be visible without being causally identified, identified without being valued by the chooser, or valued without an available revision. A witness can supply evidence that others act upon, but that route requires an account of who receives it and what can change. The toy gives its chooser a diagnostic with known reliability. Discovering which question to ask is still open.

<!-- PAGEBREAK -->

## 22 An unresolved question can have a precise address

Let W(r,A) be the nonempty set of worlds compatible with a recorded readout r and declared assumptions A. A question Q is settled within that account when the set of answers {Q(w): w in W(r,A)} has one value. If several values remain, that question is unresolved. An empty compatible set signals inconsistency; it is not a successful resolution. The adequacy of the account still depends on its assumptions and coverage.

In the two-world example, the ordinary joint distribution has one answer while the effect of setting C to zero has two. The same evidence supports a settled observation and a retained uncertainty. If the next decision needs only what the worlds agree on, it need not wait for every causal question to be closed. If it requires different actions in observationally identical worlds, the shared input cannot guarantee a correct choice in both. Randomization supplies no such guarantee either.

This elementary formulation carries the earlier protected-query distinction into the witness discussion. The handle needs a question, its current support and the conditions under which reopening could help. “Unresolved” without an object is too vague; “resolved” without its scope is too generous. A new question can expose a limit while leaving an earlier answer intact.

A revised dictionary makes the point concrete. Two collaborators once used cedar to mean that a parcel had been packed. They later adopt cedar for a planted plot and quartz for a packed parcel. An old note can faithfully preserve the earlier convention while being insufficient to interpret today's dispatch board. A present reading needs the relevant adoption and date. No amount of confidence in the old note supplies them. This is a development illustration; the pilot uses separate fictional cases.

Changing the question asked of an unchanged record differs from obtaining another record. A frame may reveal a distinction the available evidence already supports. A lookup can instead add the missing convention. Both may improve the answer, but they make different causal claims. A convincing reconstruction of the old conversation can still apply the wrong convention to the new task.

The research question left at the boundary is whether a system can identify a useful missing observation, within a cost limit, rather than merely request more context. The completed witness study does not do that. The prepared pilot below also supplies its lookup results; actual query selection remains a separate test. A precise opening for later work is enough to close this pass.
