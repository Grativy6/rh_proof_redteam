## 28 What v0.5 earns, and what it leaves open

The original question concerned whether a communicative pattern must be beneficial on balance to be passed on. This revision does not resolve that question for natural language. It separates a calibrated listener’s choice from whole-world return, records a countermodel to the inference from uptake to welfare, and demonstrates conditional mechanisms of loss and repair in a small teaching process. The conditional results are useful precisely because they do not stand in for the broader claim.

The consequence study gives the witness a specific place: a readout, a question, an objective and available actions. The same evidence can settle an observation and leave a causal intervention unresolved. A better explanation can matter, cost too much for this decision, or fail to reach an action. The next uncertainty is how a system selects a useful diagnostic when one has not already been supplied. That study remains proposed rather than a new obligation to continue.

The continuity discussion also narrows its question. A record can faithfully support later work without recreating every producing state. Documented derivation, faithful contents and appropriate later use require separate evidence. A changed authorized goal can be part of continuing the collaboration. The prepared pilot gives those claims concrete fictional opportunities; it does not yet provide observations of model behavior.

The negative results are part of the contribution. An ordinary comparator matches the original CPX checker. Low-coverage teaching chains collapse despite one repair opportunity. Costs can erase average gains, and some paired outcomes deteriorate. An early implementation passed its tests while leaking the initial naming convention. Keeping that failed run makes the correction inspectable; it does not immunize the revised code against another defect.

The toy models deliberately omit much of language: social institutions, coercive language policy, changing goals, strategic sanctions, embodiment, multiple generations of receiver learning and an empirical measure of welfare. The payoff numbers are artificial; the transmission rules are stipulated; the optional-information guarantee belongs to an ideal optimizer. These limitations identify the claims the experiments cannot carry. They do not prevent their finite implications from being checked.

The first surviving key was an eleven-page PDF whose other companions were unavailable. Its reconstructed method retains that provenance. Private conversations, reported memories and selected ancestry cases provide development history, not representative behavioral evidence. Earlier papers and source identities remain preserved; the new inspection package excludes private transcripts, source-publication copies, model data and credentials.

This manuscript is ready for review as a conceptual and finite-model working paper. It is not yet ready to claim that CPX improves model communication, that the proposed pilot works, or that sustained language is generally benevolent. Before publication, an independent reader should challenge the inference boundaries, inspect the toy implementations and assess whether the vocabulary helps beyond ordinary descriptions. A live model study would require its own frozen run contract and finite ceiling.

### Closing contribution and provenance

Christopher Daniel Pang supplied the purpose, adopted foundations, originating conversational observations, pinch and seed, the whole-language benefit hypothesis and the witnessed-consequence intuition. Hearthline supplied inflection, the Context Parallax name, operational synthesis, literature selection, toy design and implementation, explicit countermodels, correction of the implementation defect, pilot preparation and this manuscript. The supplied Hearthline exchange contributed the informational-position framing and the clock’s question about continuity. Standard results remain credited to their sources; Chris remains human author and steward. [C0–C6, N1, R01–R07]

A shared meaning can survive a change of name. A useful correction can survive a change of task. Neither survives merely because a record looks familiar. What matters for the next question must remain available, or have an honest way to be found again. A handle can preserve that possibility without keeping the question continuously open on the desk.

The consequence can be settled while its meaning for the next choice remains unresolved. That is something precise enough to carry, and small enough to put down.

<!-- PAGEBREAK -->

