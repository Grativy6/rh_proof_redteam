# Final foundation results

Final evidence: `experiments/run-002`; implementation `experiments/toys_v2.py`. Initial run-001 is retained and superseded, as recorded in RUN_HISTORY.md. Results below are bounded toy results, not model or human data.

## Exact grids

Binary decisions: 1008 rows; 360 weakly accepted, of which 96 strictly accepted. Equality is indifference by convention, not evidence that a listener chooses to participate.

Welfare sweep: 288 rows. Among 48 free-exit participant-compatible cases, 25 have a negative total on the declared artificial welfare scale. Parameter-grid counts are not prevalence estimates for natural languages.

## Teaching conditions

Six referents; forty generations; forty seeds per row below. All arms share their exogenous draws within seed and observation budget. The two learner families encode different assumptions. A chain, not a generation, is the replicate.

| Learner | Policy | Draws | Final labels: mean [min,max] | Final original match | Mean capacity accuracy | Mean questions |
| --- | --- | --- | --- | --- | --- | --- |
| pooled | none | 2 | 1.000 [1,1] | 0.16667 | 0.17167 | 0.00000 |
| pooled | none | 4 | 1.000 [1,1] | 0.16667 | 0.18687 | 0.00000 |
| pooled | none | 8 | 1.000 [1,1] | 0.16667 | 0.23854 | 0.00000 |
| pooled | none | 16 | 1.700 [1,4] | 0.25417 | 0.50333 | 0.00000 |
| pooled | repeat | 2 | 1.000 [1,1] | 0.16667 | 0.17115 | 1.00000 |
| pooled | repeat | 4 | 1.000 [1,1] | 0.16667 | 0.18500 | 1.00000 |
| pooled | repeat | 8 | 1.000 [1,1] | 0.16667 | 0.23250 | 1.00000 |
| pooled | repeat | 16 | 1.725 [1,4] | 0.26667 | 0.50260 | 1.00000 |
| pooled | targeted | 2 | 1.000 [1,1] | 0.16667 | 0.18052 | 1.00000 |
| pooled | targeted | 4 | 1.000 [1,1] | 0.16667 | 0.21427 | 1.00000 |
| pooled | targeted | 8 | 1.300 [1,3] | 0.19583 | 0.42542 | 0.88187 |
| pooled | targeted | 16 | 5.175 [3,6] | 0.86250 | 0.93750 | 0.28750 |
| bijective | none | 2 | 6.000 [6,6] | 0.17500 | 1.00000 | 0.00000 |
| bijective | none | 4 | 6.000 [6,6] | 0.17917 | 1.00000 | 0.00000 |
| bijective | none | 8 | 6.000 [6,6] | 0.18750 | 1.00000 | 0.00000 |
| bijective | none | 16 | 6.000 [6,6] | 0.84583 | 1.00000 | 0.00000 |
| bijective | repeat | 2 | 6.000 [6,6] | 0.17500 | 1.00000 | 1.00000 |
| bijective | repeat | 4 | 6.000 [6,6] | 0.17917 | 1.00000 | 1.00000 |
| bijective | repeat | 8 | 6.000 [6,6] | 0.18750 | 1.00000 | 1.00000 |
| bijective | repeat | 16 | 6.000 [6,6] | 0.84583 | 1.00000 | 1.00000 |
| bijective | targeted | 2 | 6.000 [6,6] | 0.13750 | 1.00000 | 1.00000 |
| bijective | targeted | 4 | 6.000 [6,6] | 0.20417 | 1.00000 | 1.00000 |
| bijective | targeted | 8 | 6.000 [6,6] | 0.65833 | 1.00000 | 0.88187 |
| bijective | targeted | 16 | 6.000 [6,6] | 1.00000 | 1.00000 | 0.28750 |

Accuracy assumes an optimal decoder that knows the current code. It is not a learned receiver performance. Final original match is agreement with the initial labeling, not correctness of a natural-language meaning. Means across forty generations are not endpoint statistics.

## Cost sensitivity: targeted question minus no repair

A correct referent selection pays 1, an incorrect one 0. The common random-guess outside value is 1/6 and cancels in these contrasts. Question costs are specified in config.json before the first run. Net value is a post-hoc readout of a fixed policy; the model does not choose whether to ask based on that value.

| Learner | Draws | Cost per question | Mean paired net effect | Positive / negative / tied seeds |
| --- | --- | --- | --- | --- |
| pooled | 2 | 0 | 0.008854 | 40 / 0 / 0 |
| pooled | 2 | 0.05 | -0.041146 | 0 / 40 / 0 |
| pooled | 2 | 0.2 | -0.191146 | 0 / 40 / 0 |
| pooled | 2 | 1 | -0.991146 | 0 / 40 / 0 |
| pooled | 4 | 0 | 0.027396 | 40 / 0 / 0 |
| pooled | 4 | 0.05 | -0.022604 | 1 / 37 / 2 |
| pooled | 4 | 0.2 | -0.172604 | 0 / 40 / 0 |
| pooled | 4 | 1 | -0.972604 | 0 / 40 / 0 |
| pooled | 8 | 0 | 0.186875 | 39 / 1 / 0 |
| pooled | 8 | 0.05 | 0.142781 | 35 / 5 / 0 |
| pooled | 8 | 0.2 | 0.010500 | 19 / 21 / 0 |
| pooled | 8 | 1 | -0.695000 | 0 / 40 / 0 |
| pooled | 16 | 0 | 0.434167 | 40 / 0 / 0 |
| pooled | 16 | 0.05 | 0.419792 | 40 / 0 / 0 |
| pooled | 16 | 0.2 | 0.376667 | 40 / 0 / 0 |
| pooled | 16 | 1 | 0.146667 | 39 / 1 / 0 |
| bijective | 2 | 0 | 0.000000 | 0 / 0 / 40 |
| bijective | 2 | 0.05 | -0.050000 | 0 / 40 / 0 |
| bijective | 2 | 0.2 | -0.200000 | 0 / 40 / 0 |
| bijective | 2 | 1 | -1.000000 | 0 / 40 / 0 |
| bijective | 4 | 0 | 0.000000 | 0 / 0 / 40 |
| bijective | 4 | 0.05 | -0.050000 | 0 / 40 / 0 |
| bijective | 4 | 0.2 | -0.200000 | 0 / 40 / 0 |
| bijective | 4 | 1 | -1.000000 | 0 / 40 / 0 |
| bijective | 8 | 0 | 0.000000 | 0 / 0 / 40 |
| bijective | 8 | 0.05 | -0.044094 | 0 / 40 / 0 |
| bijective | 8 | 0.2 | -0.176375 | 0 / 40 / 0 |
| bijective | 8 | 1 | -0.881875 | 0 / 40 / 0 |
| bijective | 16 | 0 | 0.000000 | 0 / 0 / 40 |
| bijective | 16 | 0.05 | -0.014375 | 0 / 40 / 0 |
| bijective | 16 | 0.2 | -0.057500 | 0 / 40 / 0 |
| bijective | 16 | 1 | -0.287500 | 0 / 40 / 0 |

All targeted-minus-repetition contrasts and finite seed minima/maxima are in `cost_effects.csv`. These ranges are descriptive sensitivity, not confidence intervals.

## What did not work

- At two and four observations, every pooled arm ended at one label in these forty-generation runs.
- At eight observations, one targeted question still left only 1.3 distinct labels on average at the endpoint.
- At eight observations and cost 0.2, the pooled mean net effect was +0.0105 but 21 of 40 seeds were worse than no repair.
- With the bijective prior and two observations, targeted repair had lower endpoint original-match in the finite sample: 0.1375 versus 0.175. This does not establish a population reversal.
- Bijective capacity accuracy is identically one by construction. Repair cannot improve that readout; charging for it lowers net capacity value even when original naming is better retained.
- Repetition is not perfectly inert in the pooled family: its extra count may change the fallback label. It never adds a previously unseen referent.
- The first implementation leaked the initial labeling into the bijective completion rule. The unchanged first-run evidence remains available.

## Assurance

The corrected run passes 21 self-audit fixtures/invariants. An exact occupancy formula is checked against all 1554 sample sequences for k=1..4. This is not independent replication or Lean verification.

The runner recorded input/output hashes, software, elapsed time, a 120-second wall limit and a 1 MiB log limit. The program is a single process. No hard memory limit was enforced on Windows. Final numerical tables are deterministic for the recorded software, configuration and fixed seeds. Changes to sample scheduling produce different finite samples.

The original strong hypothesis is not validated by these experiments. They identify explicit separations and conditional mechanisms with which to ask a better causal question.
