# Exact foundations and scope

## F1. Receiver threshold

Let p be the probability of a correct task action after using a message; B >= 0 its reward, L >= 0 the loss for an incorrect action, c >= 0 listening cost and u0 the available alternative. If B+L>0, then:

`U_R = p*B - (1-p)*L - c >= u0` exactly when `p >= (L+c+u0)/(B+L)`.

This follows by expanding and rearranging. If the threshold exceeds one, no p is accepted; if it is at most zero, all p are weakly accepted. Equality is indifference, not an empirical prediction of use. With B=L=1, u0=0, the binary grid has threshold (1+c)/2. The formula is ordinary decision theory; no mathematical novelty is claimed.

The causal premise is not proven: a real listener might misestimate p, have an unobserved alternative, face a penalty for leaving, enjoy affiliation, or value a longer horizon. Expected, realized, biological and moral value must not be equated. Assuming rational calibrated choice and then observing compliance with this inequality is not experimental evidence for the assumption.

## F2. Information is not the chosen action's value

Two equiprobable states, two messages and two actions. Every deterministic encoder and decoder is enumerated, including constant maps. For an invertible encoder and deterministic channel, a matched decoder identifies every state. A stale decoder can make every task action wrong even when state/message mutual information is one bit. A constant alarm has zero information about the modeled state. Nothing here says constant signals have no possible social function outside this declared two-state task.

For binary channel fidelity q, the one-to-one encoder's information is `1-H2(q)`, with H2 the binary entropy; a constant encoder has zero. Thus q=0 is an invertible channel, q=1/2 erases the state, and q=1 preserves it. We label q as fidelity, not honesty. Changing labels or decoding conventions is not an agent learning to become honest. The drongo discussion motivated the distinction; no new drongo experiment was performed.

## F3. Participation does not total all consequences

In a deliberately comparable utility scale, set sender benefit to 1, receiver benefit to 9/10 after listening costs, outsider loss to 3. With a zero outside option and no exit penalty, both participants can choose the exchange; the total relative to the no-exchange baseline is -11/10. Every repetition has the same accounting under unchanged assumptions. This is a whole-world countermodel with the outsider included, not an isolated bad message hidden inside a good language.

It invalidates an unrestricted inference from participant-compatible use to nonnegative total welfare. It does not establish actual natural-language welfare, cultural reproduction or evolutionary stability. A repeatable rule is not a fitted generational process.

If all affected parties instead have a modeled veto against the zero baseline, acceptance implies every U_i >= 0, hence their sum >= 0. That conclusion is arithmetic built into the veto premise. Costs to those who cannot veto, interpersonally incomparable utility, false beliefs, exit penalties and time horizons reopen the implication. The welfare CSV separates the zero baseline from a penalized available alternative.

## F4. What copying preserves

Each of six uniformly likely referents has one label. A decoder that knows the current dictionary can do no better than `number_of_distinct_labels / 6`, and attains that value by choosing one referent per label. This is an oracle readout, not measured learning performance. A bijection therefore always scores 1 even if its assignments drift completely away from an earlier convention.

The pooled learner fills unseen referents with an already observed label. Therefore its new label image is a subset of its teacher's label image. Asking that teacher another question can recover a missed label still in the teacher's vocabulary; it cannot recreate one the teacher has lost. The monotonic bound is built into this learner and is not a discovery about every language or every learner. CPX already distinguishes unavailable source content from accessible but unconsulted context.

For k independent uniform samples of six referents, the expected number observed is `6*(1-(5/6)^k)`. Proof: sum six indicator variables; each referent is absent with probability (5/6)^k. Complete enumeration for k=1..4 provides a separate exact benchmark. Again this is elementary occupancy mathematics, not a new theorem.

## F5. What a local causal result would mean

The teaching experiment intervenes on sample coverage, completion rule and repair policy while pairing random draws between arms. These are causal manipulations inside the stipulated program. Outcomes across generations in one chain are dependent. Forty seeds provide finite sensitivity, not a claim of statistical power for human language.

Targeted repair adds a missing referent/label observation. Repetition adds an already seen one and can alter a pooled fallback's frequency. These are deliberately different evidence treatments. For CPX's framing-only claim, a later experiment must supply equal evidence to its comparator. Current results do not show that perspective changes alone preserve meaning, that an LLM benefits, or that a general benevolence law holds.

## Proposed causal map

Task distribution and shared conventions -> decipherable distinctions -> choices and consequences.

Sampling and memory -> inherited coverage; repair -> additional accessible evidence -> revised decoding.

Consequences + beliefs + alternatives + exit costs -> adoption or withdrawal -> opportunities for further transmission.

Third-party effects enter total welfare, but need not enter the participants' choice rule. This missing connection is the central next question: when, and at what cost, can consequences reach the mechanism deciding what gets carried forward? The map is a proposed model, not a discovered complete causal graph.
