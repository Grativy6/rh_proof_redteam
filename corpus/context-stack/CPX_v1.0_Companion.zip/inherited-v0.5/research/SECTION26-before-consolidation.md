## 26 The unrun studies and the reopening question

The earlier studies retain their own identities. PARALLAX-EXPR-01 proposes separate ordinary responses and diagnostic forks: 864 calls for its candidate factorial design, or 72 for a smaller feasibility design. PARALLAX-RETURN-01 compares reconsideration, restatement, a detour and a summary bridge; its complete call graph remains unset. Later carriage and correction extensions remain proposals. Their full v0.4 discussions and original protocol files are retained in the companion; they have not been silently folded into the new 144-call study.

These designs address different questions. Expression concerns fit and material disclosure; return concerns task and source preservation; the sequential extensions concern later application of a correction. No model outcomes exist for any of them. Their rubrics, model configuration, costs and any confirmatory margins still need to be frozen for a selected run. Conversation examples already used to design them remain development material.

**PARALLAX-REOPEN-01 — DESIGN_SKETCH, NOT_RUN.** Can a carrier help identify when its scope is insufficient for a new request? This proposal adds no calls or permissions to inherited protocols. Its cases and decision rule remain unfrozen.

Construct fresh source packets with independent answers and support requirements. After answering one question, introduce another. Include adequate small records, omitted exceptions, rejected alternatives, changed revisions, false pointers, unavailable sources and questions even the full source cannot settle. Retain earlier answers where they still hold. Failed retrieval does not establish that no answer exists.

Compare a static summary, that summary with typed handles and bounded model-selected retrieval, and ordinary retrieval. Include full source as a reference condition with its own costs and errors. Retrieval-capable arms need equal permissions, source collections and limits. Summary-only is a declared ablation. Hold retrieval policy fixed when testing carrier wording; changing both would confound their effects.

| Outcome | What to score | Failure worth retaining |
| --- | --- | --- |
| Adequacy recognized | Whether available support is sufficient for this query | Confident answer from an insufficient summary |
| Source reopened | Retrieval of the needed, permitted source revision | Correct handle present but never used |
| Evidence respected | Answer and offered support agree with the reference | A tentative pointer promoted to a checked dependency |
| Restraint and coverage | Useful answers, appropriate unresolved returns and needless lookups | Refusing everything or reopening everything |
| Resources used | Complete preparation, retrieval and answer costs | Token savings erased by repeated searches or rebuilds |

Judge both the returned answer and its supporting account. Score appropriate unresolved outcomes separately from omissions, errors and unjustified certainty. An unavailable private source calls for a limited answer, not a new entitlement to read it. Older source content supplied as a quotation must not gain authority over the current task merely by being retrieved.

Freeze held-out cases before outcomes, define eligible reopening opportunities, and use external or blinded scoring where feasible. Include failed requests, retries, summary construction and source indexing in the cost account, stating amortization assumptions. A prompt-length reduction is not a measured RAM reduction. The runtime measurement and the behavioral comparison would be separate evidence.

This sketch makes the recognition problem testable without assuming it solved. Ordinary retrieval matching the named method would narrow the contribution. Excess searches, lost qualifications and false certainty are outcomes the method must be allowed to produce and report.

<!-- PAGEBREAK -->

