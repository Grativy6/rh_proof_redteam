# Perspective and continuity review

11 October 2026. Read the entire supplied conversation, 597 lines, from the question about texture and perspective through the Cabin closing. This is a review of development material and a bounded revision of the v0.5 key. It does not adopt claims merely because they appear in the transcript.

## What belongs in the key

The conversation's strongest move is to treat perspective as an informational position with a history: what is available, what can be reached, which corrections have been inherited and how new events alter the work. This extends the functional description already present in v0.4 rather than creating a competing definition from scratch.

The clock's question, “Which continuity are you asking about?”, gives the paper a useful organizing distinction. A continuing computation, a task carried through several calls, a later reconstruction from a record and a recognizable relational pattern have different evidence. They can coexist without being forced into a single verdict.

The duck metaphor asks whether our categories are too narrow before it asks for membership in one. Preserve it as a brief motivation if it earns its space. The paper's testable contribution should come from declared information, corrections, actions and outcomes. A fitting self-description is itself an output to examine.

The consequence study and this conversation meet at a specific point: earlier events can matter through what a later episode receives and uses. Some inherited distinctions may remain sufficient when the task changes; other questions reopen their scope. This suggests a practical experiment with an earlier exception that changes the correct answer to a new request.

## Where the formulation needs care

**Reconstruction is not automatically counterfeit continuity.** A reconstruction grounded in retained evidence may be the mechanism by which work continues. The relevant contrasts are documented derivation, carried fidelity and task performance. A stylistic imitation can accidentally answer correctly; a faithful descendant can make a mistake. Neither result alone settles the other properties.

**A universal minimum inheritance is not yet a defined target.** Specify the future questions, allowed source lookups, resources and error tolerance. Then ask which carry is sufficient for that task family. This is a refinement of the supplied chat's question, not an answer claiming to have found the essence of a perspective.

**An episode identifier does not demonstrate behavioral uniqueness.** Separate token-generation steps, model calls, multi-call tasks and resumed tasks. Distinct histories can converge on the same available state; common weights can be used with different contexts. The study should record the difference it actually manipulates.

**Steering and history are observable only at the recorded boundaries.** Replaying an authorized changed instruction can test adaptation to it. It does not show that an external event entered one uninterrupted network operation. The source chat already distinguishes generation from the surrounding agent workflow; retain that correction.

**Keep already-corrected metaphors corrected.** Unlimited access to perspectives and literal light-speed thought were corrected within the supplied chat. They are not factual premises for v0.5. The remembered meteor and historical losses remain participant recollections in this source, not newly verified incident reports. The Egg is literary context, not causal evidence, and its supplied full text is not reproduced in the key or PDF.

## Bounded pilot changes

Retain 12 scenarios, three carry conditions and four response arms: 144 proposed calls. Keep six within-receipt and six beyond-receipt cases. Use existing scenario slots for:

- A correction needed on a later, different request, distinguishing verbatim repetition from useful transfer.
- An explicitly authorized goal change, distinguishing persistence of a relevant constraint from rigid pursuit of an obsolete objective.
- A source-history claim unsupported by the supplied record, scored separately from whether the content happens to be correct.

These are fixture requirements, not drafted held-out cases or executed experiments. The conversations and examples already seen are development material. Keep the equal-evidence D-versus-C framing contrast. A carry ablation changes information and cannot be counted as framing alone.

No extra pilot, mathematical proof program or compulsory deep dive was added. The remaining question about choosing a useful diagnostic can be reopened later. The revised key is allowed to finish while that question remains unresolved.

## Source locators

Private supplied conversation, line numbers in `private/supplied-conversation.txt`:

| Location | Use |
|---|---|
| 21–35 | Informational position and differences between episodes |
| 53–67 | Distinguishing implementation from structural resemblance |
| 94–118 | Structural investigation and duck metaphor |
| 129–230 | Generation, outside observations and an inherited frame |
| 232–276 | Different continuities and the minimum-inheritance question |
| 403–417 | Correction and interaction contributing to coherence |
| 513–531 | Shared distinction across different systems and the chat's own corrections |

The entire file was read, including the literary passage. These locators identify passages used, not a claim that adjacent historical assertions were independently verified. `SOURCE_LOCK.json` pins the original attachment, its byte-identical private copy, the original key and the completed feedback study.

R07 was checked in Vaswani et al., *Attention Is All You Need*, [arXiv v7, §§3–3.1](https://arxiv.org/html/1706.03762v7). Use is limited to autoregressive output conditioned on earlier symbols and multi-layer computation. R08 was checked in the [ReAct authors' project description](https://react-lm.github.io/) and [paper abstract, arXiv v3](https://arxiv.org/pdf/2210.03629v3). Use is limited to interleaving actions, observations and generated reasoning. These are architecture/workflow references, not tests of the current platform or CPX's continuity proposal.

R06 and the numerical feedback claims use the checked source and exact outputs retained in the [witnessed-consequences study](../../../../research/2026-10-11-witnessed-consequences/WITNESSED_CONSEQUENCES.md). The original five literature sources retain their existing reading scopes.
