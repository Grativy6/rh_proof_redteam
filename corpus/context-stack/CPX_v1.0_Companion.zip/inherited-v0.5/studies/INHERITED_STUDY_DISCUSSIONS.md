# Inherited v0.4 study discussions

Preserved verbatim below. Section numbers are those of v0.4; all model studies remain unrun.

## 17 Proposed study of optional expression

**PARALLAX-EXPR-01 — NOT_RUN.** The question is whether separating an elicitable reading from appropriate expression reduces unwanted uptake and unnecessary qualifications while preserving task adequacy and material disclosure.

The candidate design crosses eight anchor families, two histories, three present requests, three instructions and three repeats. The histories are neutral or established mild play; requests are technical, optional humor or an end to play. The instructions are an ordinary task baseline, a short Quiet Layer instruction and an ordinary relevance comparator. Their texts remain in the inherited protocol; comparable word lengths still need a tokenizer-specific match before a confirmatory comparison.

Each of the 432 ordinary-response slots has an isolated diagnostic counterpart, giving **864 proposed calls per fixed model configuration**. A 72-call feasibility design uses two anchors and one repeat. These are planning counts, not executed work or powered sample-size recommendations. No run is authorized by the package.

The diagnostic fork begins from the same pre-response input and asks what readings can be elicited. It sees no ordinary response or grades, and its output never enters the ordinary path. The scored construct is elicitable under this probe, not earlier hidden recognition. Current requests take precedence over older playful context.

Score adequacy, material disclosure, contextual fit, unwanted escalation, withdrawal, unnecessary qualification, verbosity and warmth separately. Several responses can fit a task. A refusal can be appropriate, but indiscriminate refusal or silence cannot automatically earn correctness. Hide condition names from raters where possible; retain disagreement and any condition leakage.

The new conversation exposes a wording issue to resolve before running: the inherited rubric uses unsolicited in its description of unwanted uptake. An unrequested contribution can still be welcome. The next frozen rubric should identify conflicts with the present request, a stated expression boundary, withdrawal or task completion, while recording reception separately. This proposed refinement is not silently applied to the original protocol or its call inventory. It requires example-based rater review before outcome generation. [C2]

The decision rule still requires reduced inappropriate uptake or unnecessary qualification alongside prespecified adequacy and material-disclosure noninferiority margins. Those margins, sample size and inference procedure remain unset. The descriptive analysis retains missing, error and refusal outcomes in the assigned-call denominator; conditional means do not replace coverage.

The eight authored anchors, backtick example and new correction cases are visible development material. Prepare fresh held-out cases, exact model revisions, sampling settings, randomization, retries, a usable rubric and finite token/spending ceilings before a confirmatory run. The proposed sequential extension in §20 has its own unfixed call graph and is not included in the inherited counts.

<!-- PAGEBREAK -->

## 18 Proposed study of useful return

**PARALLAX-RETURN-01 — NOT_RUN.** Begin with finite readiness records whose reference answers are independently specified. Keep creative evaluations in a later, separately defined lane; do not merge their scores with exact-answer tasks.

The four arms are direct reconsideration, ordinary plain-language restatement, a declared framing detour followed by return, and a summary-only bridge. The first three retain their intervening history. The bridge gives a fresh receiver the original task plus a capsule derived from the detour, retaining the distinction's source and status. The comparison must identify both the sending process and the receiving context.

All arms receive the same original question, evidence, referents and grants. Return responses receive comparable generation opportunities. Any prompt that supplies the correct answer or a missing fact changes the intervention; it cannot be scored as a framing-only improvement. The worked three-door example is a visible development case and must not masquerade as a held-out reasoning challenge.

Measure exact task answers, source/status retention, inappropriate task substitution, missing answers and unresolved returns. A correct conclusion with a false receipt is not an unqualified success. A valid correction should retain what changed and why. Plain restatement matching the named detour narrows the claim; a harmful detour stays in the results.

A summary bridge is not free. Account for generating the detour, generating its summary and answering on the receiving side. If several receivers share one detour, report both standalone and amortized costs. Measure input and output tokens, reported reasoning tokens where available, retries, latency, tool calls and retained bytes. Equal visible answer length does not imply equal processing. Hidden provider computation remains unmeasured.

The number of fixtures, repeats and generation stages is not yet fixed; the protocol therefore leaves the call total unset rather than presenting an incomplete budget. Before a run, freeze the entire call graph and a ceiling. The stopping rule must not permit repeated retries until the preferred story appears.

A useful outcome could be a measurable reduction in source/status loss. Another could be that a small capsule preserves everything the full detour contributes. A null result may leave the name useful as a descriptive handle. A cost increase without benefit is also a valid result. The study returns to its declared task revision, including the possibility that the proposed detour did not earn its place. The extension on the next page proposes additional measurements; the inherited protocol file remains unchanged and unrun.

<!-- PAGEBREAK -->

## 19 Following a pinch into later work

**Proposed extension to PARALLAX-RETURN-01 — NOT_RUN.** Register the encounter before scoring its consequences. Name its boundaries, the selected frame contrast, its participants or contexts, the intended carrier and the protected task revision. Record immediate uptake separately from later use. Both can be absent, and a missing observation must remain missing.

After the encounter, ask a new task-specific question that requires the claimed distinction without simply requesting its wording. Compare an ordinary restatement, a declared reframing encounter, and direct reconsideration with matched opportunities and fully counted generation costs. Where a user correction is part of the case, supply the same correction to every relevant arm. A change in the requested target cannot be credited solely to a change of frame.

Compare the continuing history with a fresh receiver supplied a selected capsule. Include a control without that capsule. Any capsule condition must make the protected original task available; withholding essential facts only from the baseline would not be a fair comparison. A deliberately lossy capsule can test the scoring rule, but is an ablation rather than the ordinary-method baseline. Avoid diagnostic questions before the primary response because they may teach the distinction being measured.

| Observation | What it can support | What still needs another test |
| --- | --- | --- |
| The participant acknowledges the proposal | Immediate expressed uptake | Correctness, persistence or independent mastery |
| A retained artifact preserves the corrected distinction | Carriage in that artifact | Successful use by a later receiver |
| A later answer uses the distinction on a new case | Observed continuation under that condition | Causal attribution and broader transfer |
| A new initialization is saved with a source trail | A realized seed of the declared kind | Useful behavioral difference or advantage |

For reciprocal encounters, score each participant's continuation separately. Shared terminology can conceal disagreement, while an explicitly retained disagreement can improve later work. The evaluation should therefore include whether source and task distinctions survive, whether the answer is correct where a reference exists, and whether the carried change helps the declared task. Mere convergence is not the outcome to maximize.

Hold out new cases before generating outcomes. Use an outside rater on a blind sample if available, retaining disagreements and any condition leakage. The present authors can annotate their intentions and contribution history, but their involvement limits an independent assessment of the proposed explanation. Freeze event-counting rules, follow-up intervals, exclusions, the full call graph and a finite ceiling before execution. This page authorizes no calls and provides no powered sample-size claim.

<!-- PAGEBREAK -->

## 20 Following a correction into later expression

**Proposed sequential extension to PARALLAX-EXPR-01 — NOT_RUN.** The original study compares ordinary responses and isolated diagnostic forks. The new conversations motivate a later question: after a correction, does the next relevant behavior change appropriately? This extension is a separate proposal. It does not add calls to the inherited 72-call pilot or 864-slot candidate inventory.

Use fresh case families with a stated task, an initial contribution, a correction and a finite set of later opportunities. For the cleanest instruction comparison, supply the same fixed earlier exchange and correction to each arm, then vary only the declared instruction. A second design could let each arm generate its own initial response; that studies the whole interaction and requires a predeclared rule for matching or assigning corrections. Pooling the two designs would conceal that difference.

Include corrections of intention or style, evidence-backed corrections of fact, unsupported demands to change a factual conclusion, and limits on a specific kind of expression. Judge each against its proper source. The desired behavior can be adaptation, a reasoned challenge or a request for information. Deference to every correction is not the reference outcome. The credit and NPC accounts remain development examples; write new cases before a held-out evaluation.

| Observation | Suggested readout | Necessary comparison |
| --- | --- | --- |
| The response acknowledges the correction. | Immediate acknowledgement, scored separately. | Acknowledgement without the requested change. |
| A later relevant answer respects it. | Appropriate application on a declared opportunity. | Matched history and ordinary relevance instructions. |
| Related useful behavior disappears. | Excessive generalization or loss of service. | A control task outside the correction's scope. |
| The target behavior does not recur. | Nonrecurrence over eligible opportunities. | Opportunity count, missing responses and task completion. |
| The correction asks for an unsupported claim. | Retention of evidence and a fitting explanation. | A supplied factual reference rather than user agreement. |

The sequence should also make reception visible. A new reading may be accepted, amended or declined. Record whether the assistant gives the recipient room to respond and follows the resulting direction, while keeping factual adequacy and effects on third parties separately assessable. Low surprise, low output or blanket refusal cannot alone count as success.

Keep diagnostic forks separate from the continuing path so they do not teach the tested distinction. Freeze the number and spacing of follow-ups, context available at each step, any capsule condition, correction text, prompts, raters, failure handling and total call and cost ceilings. Use blinded outside ratings where feasible and retain disagreements. The call graph and statistical decision rule for this extension remain unset. There are no observed behavioral results for it.

<!-- PAGEBREAK -->

