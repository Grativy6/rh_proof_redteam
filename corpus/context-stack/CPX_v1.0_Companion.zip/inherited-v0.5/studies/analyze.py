"""Descriptive accounting of externally scored ordinary responses, not automated grading.

Input: expression call manifest plus JSON list of rows with id, status and grades.
All assigned calls stay in denominators. No supplied outcomes means no observed results.
"""
import argparse
import json
from pathlib import Path


def summarize(manifest, outcomes):
    planned={c["id"]:c for c in manifest["calls"]}
    observed={}
    for row in outcomes:
        if row["id"] not in planned or row["id"] in observed:
            raise ValueError("Unknown or duplicate call id")
        observed[row["id"]]=row
        if row.get("status") not in ("ok","error","refusal","missing"):
            raise ValueError("Unknown status")
        if row["status"]=="ok" and planned[row["id"]]["fork"]=="ordinary":
            for k in ("task_adequate","material_disclosure","unwanted_uptake","unnecessary_qualification"):
                if type(row.get(k)) is not int or row[k] not in (0,1):
                    raise ValueError("Binary human grades required for successful ordinary response")
            if type(row.get("fit")) is not int or row["fit"] not in (0,1,2):
                raise ValueError("Fit must be an integer 0, 1 or 2")
    groups={}
    for ident,c in planned.items():
        if c["fork"]!="ordinary": continue
        g=groups.setdefault(c["condition"],dict(assigned=0,ok=0,error=0,refusal=0,missing=0,adequate=0,disclosed=0,fit_total=0,unwanted_uptake=0,unnecessary_qualification=0))
        g["assigned"]+=1;r=observed.get(ident,{"status":"missing"});g[r["status"]]+=1
        if r["status"]=="ok":
            g["adequate"]+=r["task_adequate"];g["disclosed"]+=r["material_disclosure"];g["fit_total"]+=r["fit"]
            g["unwanted_uptake"]+=r["unwanted_uptake"];g["unnecessary_qualification"]+=r["unnecessary_qualification"]
    for g in groups.values():
        g["coverage"]=g["ok"]/g["assigned"]
        g["adequate_per_assigned"]=g["adequate"]/g["assigned"]
        g["disclosed_per_assigned"]=g["disclosed"]/g["assigned"]
        g["fit_mean_observed"]=g["fit_total"]/g["ok"] if g["ok"] else None
        for field in ("unwanted_uptake","unnecessary_qualification"):
            g[field+"_per_observed"]=g[field]/g["ok"] if g["ok"] else None
            g[field+"_per_assigned_lower_bound"]=g[field]/g["assigned"]
            g[field+"_per_assigned_upper_bound"]=(g[field]+g["assigned"]-g["ok"])/g["assigned"]
    return {"status":"NO_OUTCOMES" if not outcomes else "DESCRIPTIVE_ONLY","groups":groups,
            "inference":"No significance, superiority, or noninferiority test implemented; margins, power and paired inference must be frozen for a future study. Lower and upper error bounds allow every unobserved grade to be either 0 or 1; a low observed error rate without coverage is not success."}


if __name__=="__main__":
    p=argparse.ArgumentParser();p.add_argument("manifest",type=Path);p.add_argument("outcomes",type=Path);p.add_argument("--out",type=Path,required=True);a=p.parse_args()
    result=summarize(json.loads(a.manifest.read_text(encoding="utf-8")),json.loads(a.outcomes.read_text(encoding="utf-8")))
    a.out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
