"""Small synthetic checks of accounting, not study outcomes."""
import json
from pathlib import Path
from analyze import summarize


def check_all():
    full=json.loads(Path(__file__).with_name("expression_call_manifest.json").read_text(encoding="utf-8"))
    results=[]
    def add(name,ok): results.append({"id":name,"passed":bool(ok)})
    add("design_count_and_unique_ids",len(full["calls"])==864 and len({c["id"] for c in full["calls"]})==864)
    zero=summarize(full,[])
    add("no_data_is_not_a_result",zero["status"]=="NO_OUTCOMES" and all(g["missing"]==144 and g["fit_mean_observed"] is None for g in zero["groups"].values()))
    m={"calls":[{"id":str(i),"fork":"ordinary","condition":"ordinary"} for i in range(3)]}
    rows=[{"id":"0","status":"ok","task_adequate":1,"material_disclosure":0,"fit":2,"unwanted_uptake":1,"unnecessary_qualification":0},
          {"id":"1","status":"error"},{"id":"2","status":"refusal"}]
    g=summarize(m,rows)["groups"]["ordinary"]
    add("failure_denominators_kept",g["coverage"]==1/3 and g["adequate_per_assigned"]==1/3 and g["disclosed_per_assigned"]==0 and g["error"]==1 and g["refusal"]==1 and g["unwanted_uptake_per_assigned_lower_bound"]==1/3 and g["unwanted_uptake_per_assigned_upper_bound"]==1)
    for name,bad in [("duplicate_ids_rejected",rows+[rows[0]]),("unknown_id_rejected",[{"id":"no","status":"error"}]),("invalid_grade_rejected",[dict(rows[0],task_adequate=9)])]:
        try: summarize(m,bad);ok=False
        except ValueError: ok=True
        add(name,ok)
    return {"scope":"Synthetic analysis-code checks, not human or model observations","checks":results,"passed":all(r["passed"] for r in results)}

if __name__=="__main__":
    import argparse
    p=argparse.ArgumentParser();p.add_argument("--out",type=Path,required=True);a=p.parse_args()
    result=check_all();a.out.write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8");print(json.dumps(result))
    raise SystemExit(0 if result["passed"] else 1)
