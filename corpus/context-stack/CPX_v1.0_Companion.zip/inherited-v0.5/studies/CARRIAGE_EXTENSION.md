# Proposed carriage extension to PARALLAX-RETURN-01

Status: NOT_RUN · authored 8 October 2026 · proposal, not a preregistration or call authorization

The manuscript's §15 is the governing prose for this extension. It does not modify the inherited return_protocol.json or expression_call_manifest.json. No new call inventory or results file is manufactured.

## Question

After a bounded framing encounter, which distinction is carried, where is it retained, and does a later task demonstrate useful uptake? Keep immediate acknowledgement, storage, recipient use, correctness and causal attribution separate.

## Design commitments to freeze before outcomes

1. Define the event unit and record its start/end, selected framing material, contexts and task revision.
2. Compare ordinary restatement, direct reconsideration and a declared framing encounter with matched opportunities. Count every generation and summary step.
3. Give every relevant arm the same task correction and essential evidence. Record goal changes separately from framing-only interventions.
4. Compare continuing history, a fresh receiver with a sourced capsule, and an otherwise matched receiver without that capsule. A deliberately lossy capsule is an ablation, not a weak ordinary baseline.
5. Score both sides separately in reciprocal encounters. Include preserved disagreement and incorrect convergence. Do not assume agreement is the goal.
6. Delay diagnostics until after the primary readout, or isolate them in separate forks. Freeze follow-up intervals and missingness rules.
7. Write held-out cases before outcome generation. Obtain an outside blind rater where possible and retain disagreements. The authors' own ratings are not independent corroboration.
8. Freeze model/configuration, prompts, full call graph, retries, accounting categories and finite ceiling. No numbers are filled in as though the unresolved design were ready to run.

No observed follow-up is a missing measurement, not evidence of no change. A seed's existence is tested through its actual stored kind and identity; its usefulness needs receiver work. Parameter training is a different implementation lane and is not part of this protocol extension.
