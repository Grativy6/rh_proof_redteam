# PARALLAX-REOPEN-01

Status: DESIGN_SKETCH_NOT_RUN. This file adds no calls or permissions to the inherited protocols.

Question: can a compact carrier support recognizing when a later query needs its source reopened, while avoiding unnecessary retrieval and unsupported certainty?

The canonical design discussion is paper §24. Its contrasts separate carrier content, source access and retrieval policy. Required cases include adequate small records, omitted exceptions, changed versions, false pointers, unavailable sources and unanswerable questions. Evaluation must include the answer and the offered support, opportunity counts, failure outcomes and all preparation/retrieval/answer costs.

Before any run: author fresh held-out cases; freeze exact references, prompts, models, source permissions, retrieval operations, randomization, eligible opportunities, scoring, raters, call graph, finite limits and failure handling. Match retrieval-capable baselines fairly. A summary-only arm is a declared ablation; full context is a reference condition with its own cost and errors.

No dataset, sample-size claim, model experiment, resource benchmark or result is supplied by this revision.
