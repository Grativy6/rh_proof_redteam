# CPX-MAINTAIN-01 — prepared inputs, no model outcomes

Twelve fictional investigator-authored scenarios, six inside and six beyond the short receipt's support. Three carry conditions and four arms yield 144 records. These are fresh to this pilot, not independently held-out cases. The investigator has seen all cases and reference answers.

`fixtures.json` contains the support/reference contract. `prompts/` contains model-facing records without reference answers. `prompt_manifest.json` hashes every prompt. `baseline.json` and `checks.json` record the ordinary fact-ID comparison. `summary.json` reports preparation, not model performance.

A and B use the same evidence. C and D use identical standardized lookup results; only their instruction changes. B is a reconsideration instruction within one call, not a second generated response. The full record contains all supplied permitted content. No-address, unavailable and not-permitted results supply no additional source facts. A handle grants neither permission nor a correct interpretation.

The baseline's required-support lists are authored. It can test coverage and replay controls, but cannot read prose, learn dependencies, authenticate facts or measure contextual fit. A scoped nonclaim can be supported; a blanket abstention cannot satisfy cases with available answers.

Live execution remains NOT_RUN. Before it: choose provider/model revision; freeze actual prompt serialization, decoding and token limits; specify randomized ordering, retry/invalid-response accounting, finite cost ceiling, response schema and grading rubric; arrange blinded second-rater scoring for a predeclared sample. Any later fixture changes get a new revision and preserve this one. No run is authorized by this README.

Reproduce preparation in a copied package with `python ../prepare_maintain.py` from this directory (or use the absolute script path). The script refuses to replace differing existing frozen fixtures. The top-level verifier checks prompt hashes and evidence equivalence without generating outcomes.
