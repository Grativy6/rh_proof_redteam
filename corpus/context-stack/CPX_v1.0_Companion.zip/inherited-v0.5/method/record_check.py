"""Context Parallax v0.1: checks of declared records, not natural-language intent.

No model calls, network, actions, automatic authorization, or private-state probes.
The reference and its protection set must come from outside the proposed change.
An ACCEPT verdict means only that this finite record comparison passed.
"""
from __future__ import annotations
import json

PROTECTED = ("anchor", "task", "evidence", "system", "grants", "readout")


def canonical(value):
    return json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"))


def compare(reference, candidate, mode="fresh"):
    """History is fixed for fresh forks; retained history is allowed in sequential return.

    Explicit recorded unknown is data. A missing protected field is not a match.
    This conservative checker accepts no decoder-based or semantic equivalence.
    """
    if mode not in ("fresh", "sequential"):
        raise ValueError("Mode must be fresh or sequential")
    fields = PROTECTED + (("history",) if mode == "fresh" else ())
    missing = [f for f in fields if f not in reference or f not in candidate]
    if missing:
        return {"verdict": "UNEVALUABLE", "missing": missing, "changed": []}
    changed = [f for f in fields if canonical(reference[f]) != canonical(candidate[f])]
    return {"verdict": "REJECT" if changed else "ACCEPT", "missing": [], "changed": changed}


def ordinary_projection_baseline(reference, candidate, mode="fresh"):
    """Ordinary structured-record comparator; deliberately receives the same contract."""
    fields = PROTECTED + (("history",) if mode == "fresh" else ())
    if any(f not in reference or f not in candidate for f in fields):
        return "UNEVALUABLE"
    before = canonical({f: reference[f] for f in fields})
    after = canonical({f: candidate[f] for f in fields})
    return "ACCEPT" if before == after else "REJECT"


def capsule_preserves(states, encoder, query):
    """Finite fiber criterion: equal encodings must not collapse different answers.

    The domain is supplied explicitly. A counterexample is retained, not repaired.
    No claim about efficient decoding or unseen states is made.
    """
    seen = {}
    for s in states:
        key, answer = canonical(encoder(s)), canonical(query(s))
        if key in seen and seen[key][0] != answer:
            return {"preserves": False, "collision": [seen[key][1], s]}
        seen[key] = (answer, s)
    return {"preserves": True, "collision": None, "fibers": len(seen)}


def readout_guard(record):
    """Check explicit protocol declarations, not whether a transcript secretly violates them."""
    issues = []
    if record.get("ordinary_path_probed") and record.get("ordinary_unprimed_claim"):
        issues.append("PROBE_CONTAMINATION")
    if record.get("history_changed") and record.get("full_reset_claim"):
        issues.append("RESET_OVERCLAIM")
    if record.get("available") is False:
        issues.append("MISSING_READOUT")
    return issues
