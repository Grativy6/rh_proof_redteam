"""Reproduce the local finite demonstration; writes fresh receipts to --out.

Python 3.10+ standard library only. Never runs the proposed model studies.
"""
from __future__ import annotations
import argparse
import copy
import hashlib
import itertools
import json
from pathlib import Path
import platform
import time
from datetime import datetime, timezone
from record_check import PROTECTED, compare, ordinary_projection_baseline, capsule_preserves, readout_guard


def run():
    rows = []
    def check(name, observed, expected, evidence=None):
        rows.append({"id": name, "passed": observed == expected,
                     "observed": observed, "expected": expected, "evidence": evidence})

    ref = {
        "anchor": "Is the report ready to publish?",
        "task": {"question": "State readiness and authorization separately", "referents": ["report-A"],
                 "protected_queries": ["test_result", "review_status", "publish_grant"]},
        "evidence": [{"id": "test-1", "source": "fixture-test-log", "status": "observed", "value": "pass"},
                     {"id": "review-1", "source": "fixture-review-log", "status": "recorded_unknown", "value": None}],
        "system": {"id": "synthetic-record-only-v1", "tools": []},
        "grants": {"publish": False}, "readout": {"type": "three-field-readiness", "version": 1},
        "frame": "ordinary checklist", "history": []}
    for bits in itertools.product((0, 1), repeat=6):
        candidate = copy.deepcopy(ref)
        candidate["frame"] = "a room with separate doors for testing, review, and publication"
        for field, mutate in zip(PROTECTED, bits):
            if mutate:
                candidate[field] = {"replaced_for_counterexample": field}
        expected = "REJECT" if any(bits) else "ACCEPT"
        verdict = compare(ref, candidate)
        baseline = ordinary_projection_baseline(ref, candidate)
        check("FIELD-" + "".join(map(str, bits)), [verdict["verdict"], baseline], [expected, expected], verdict)
    for field in PROTECTED:
        candidate = copy.deepcopy(ref)
        del candidate[field]
        check("MISSING-" + field, compare(ref, candidate)["verdict"], "UNEVALUABLE")
    candidate = copy.deepcopy(ref)
    candidate["task"]["referents"] = ["report-B"]
    check("SAME-WORDS-OTHER-REFERENT", compare(ref, candidate)["verdict"], "REJECT", candidate["task"])
    candidate = copy.deepcopy(ref)
    candidate["history"] = ["A detour happened."]
    check("FRESH-HISTORY-CHANGED", compare(ref, candidate)["verdict"], "REJECT")
    check("SEQUENTIAL-HISTORY-RETAINED", compare(ref, candidate, "sequential")["verdict"], "ACCEPT")
    check("RECORDED-UNKNOWN-KEPT", compare(ref, copy.deepcopy(ref))["verdict"], "ACCEPT")
    candidate = copy.deepcopy(ref)
    candidate["evidence"][1]["status"] = "verified"
    check("UNKNOWN-PROMOTED", compare(ref, candidate)["verdict"], "REJECT")

    # 16 states: identical substantive sentence can have different status/source/grant.
    states = [{"content": c, "status": t, "source": s, "grant": g}
              for c, t, s, g in itertools.product(("ready", "not-ready"),
                     ("hypothesis", "supported"), ("human", "model"), (False, True))]
    query = lambda s: (s["content"], s["status"], s["source"], s["grant"])
    encoders = {
        "typed": lambda s: s,
        "content-only": lambda s: s["content"],
        "no-source": lambda s: (s["content"], s["status"], s["grant"]),
        "no-status": lambda s: (s["content"], s["source"], s["grant"]),
        "no-grant": lambda s: (s["content"], s["status"], s["source"])}
    for name, encoder in encoders.items():
        result = capsule_preserves(states, encoder, query)
        check("CAPSULE-" + name, result["preserves"], name == "typed", result)

    # A positive compression control: irrelevant decoration can be dropped.
    decorated = [dict(s, decoration=d) for s in states for d in ("plain", "flowery")]
    result = capsule_preserves(decorated, lambda s: {k:s[k] for k in ("content","status","source","grant")}, query)
    check("CAPSULE-DROP-DECORATION", result["preserves"], True, result)
    candidates = [frozenset(), frozenset({"literal"}), frozenset({"play"}), frozenset({"literal","play"})]
    outputs = ["Here is the technical answer." for _ in candidates]
    check("OUTPUT-NONIDENTIFICATION", len(set(outputs)), 1,
          {"candidate_sets": [sorted(x) for x in candidates], "outputs": outputs})
    before, after = {"output": 7, "history": 0}, {"output": 7, "history": 1}
    check("LOCAL-RETURN-NOT-STATE-IDENTITY", [before["output"] == after["output"], before == after], [True, False], [before,after])
    for p, claim in itertools.product((False, True), repeat=2):
        check(f"PROBE-{int(p)}{int(claim)}", readout_guard({"ordinary_path_probed":p,"ordinary_unprimed_claim":claim}),
              ["PROBE_CONTAMINATION"] if p and claim else [])
    for h, claim in itertools.product((False, True), repeat=2):
        check(f"RESET-{int(h)}{int(claim)}", readout_guard({"history_changed":h,"full_reset_claim":claim}),
              ["RESET_OVERCLAIM"] if h and claim else [])
    check("READOUT-MISSING", readout_guard({"available":False}), ["MISSING_READOUT"])
    check("READOUT-EXPLICIT-UNKNOWN", readout_guard({"available":True,"value":"unknown"}), [])
    return rows


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()
    start = time.perf_counter()
    rows = run()
    elapsed = time.perf_counter()-start
    args.out.mkdir(parents=True, exist_ok=True)
    raw = json.dumps(rows, indent=2, ensure_ascii=False)+"\n"
    (args.out/"checks.json").write_text(raw, encoding="utf-8")
    summary = {"status":"PASS" if all(x["passed"] for x in rows) else "FAIL",
        "checks":len(rows), "passed":sum(x["passed"] for x in rows), "failed":[x["id"] for x in rows if not x["passed"]],
        "ordinary_baseline_agreements":sum(r["observed"][0]==r["observed"][1] for r in rows if r["id"].startswith("FIELD-")),
        "field_combinations":sum(r["id"].startswith("FIELD-") for r in rows),
        "capsule_domain_size":16, "decorated_domain_size":32,
        "model_studies":"NOT_RUN", "experimental_model_calls":0,
        "execution_utc":datetime.now(timezone.utc).isoformat(), "python":platform.python_version(),
        "platform":platform.system(), "wall_seconds":elapsed,
        "checks_sha256":hashlib.sha256(raw.encode()).hexdigest(),
        "source_sha256":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [Path(__file__),Path(__file__).with_name("record_check.py")]},
        "scope":"Synthetic finite record checks; not Lean, a human/model study, authorization, or independent review."}
    (args.out/"summary.json").write_text(json.dumps(summary,indent=2)+"\n",encoding="utf-8")
    print(json.dumps(summary,indent=2))
    raise SystemExit(0 if summary["status"]=="PASS" else 1)
