# Source concordance for CPX v0.5

All paths below are relative to this revision unless stated otherwise. The full identity list is `audit/REVISION_SOURCE_LOCK.json`. Copies of inherited records retain their original contents and historical paths; this index is the portable route to the selected material.

| Paper identifier | Current location | Use and limit |
|---|---|---|
| K0, C0–C4, A1, D1, N1, S1–S6, L1–L15 | `audit/inherited-v0.4-SOURCE_CONCORDANCE.md` and its preserved claim/document records | Earlier CPX source identities and reading scopes; not a newly repeated corpus audit |
| C5 | `research/key/CPXv0.5KEY-r2.md`; `evidence/witness/WITNESSED_CONSEQUENCES.md` | Originating benefit hypothesis, whole-world boundary and consequence discussion; development evidence selected from visible exchanges |
| C6 | `research/PERSPECTIVE_REVIEW.md`; private original is identified by hash in the lock | Entire supplied 597-line conversation read for revision 2; source remains private and is not bundled |
| R01–R05 | `research/foundation-SOURCES.md` | Primary passages and reading scopes for signaling, dynamics, iterated learning, repair and vigilance |
| R06 | `evidence/witness/SOURCES.md` | Pearl's corrected author reprint, observational/interventional distinction and identifiability; no general audit of the paper |
| R07 | `research/PERSPECTIVE_REVIEW.md` | Vaswani et al. v7 §§3–3.1, generation scale only |
| R08 in key = L15 in paper | `research/PERSPECTIVE_REVIEW.md` | Same ReAct reference, with the author project method description also inspected; not two independent sources |
| E1 | `evidence/foundation/run-002`; `research/foundation-RESULTS.md` | Final toy results, including adverse outcomes; run-001 retained and superseded |
| E2 | `evidence/witness/run-001` | Exact decision and causal constructions, 21 check categories / 1,932 assertions |
| E3 | `studies/maintain` | Fictional pre-model fixture set, frozen inputs and ordinary structured baseline; 144 model calls NOT_RUN |

The v0.4 Markdown, Word, PDF and four key-pinned inputs were verified unchanged at preparation. The source lock also pins the r2 key and supplied private conversation. The new Markdown is a declared revision, not a reconstructed copy of missing bytes. `audit/MANUSCRIPT.diff` makes the edits inspectable.

Original code and protocols from v0.4 are byte-identical copies. Full former §§17–20 are preserved in `studies/INHERITED_STUDY_DISCUSSIONS.md`; their section numbers refer to v0.4. Main-paper §§23–26 retain the earlier attention/context/texture/reopening account, with updated numbering and one expanded ReAct reading scope.

Private transcript content, the full supplied literary story, primary-publication PDFs, credentials and model weights are excluded from the review archive. Sources in the bibliography are cited for their stated passages, not implicitly certified in full. The review is selective and makes no priority claim.
