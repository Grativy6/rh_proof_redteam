# Source and scope record

Access date: 11 October 2026. This is a focused follow-up, not a systematic literature review.

## Verified primary source

Judea Pearl. **An Introduction to Causal Inference.** The International Journal of Biostatistics 6(2), Article 7 (2010). DOI: [10.2202/1557-4679.1203](https://doi.org/10.2202/1557-4679.1203).

Read from the [author's UCLA corrected reprint](https://ftp.cs.ucla.edu/pub/stat_ser/r354-corrected-reprint.pdf). The cover labels the technical report R-354, March 2011; retain that distinction from the 2010 journal publication. The linked PDF has 61 pages. Reading focused on the introduction, §2.1, §2.2, and §3.2.1 through Definition 2. This is not a claim to have audited the full paper.

Use: supports distinguishing observed associations from intervention effects and stating identification relative to assumptions. Our binary worlds are illustrative constructions written for this note, not an example attributed to Pearl. No broad theorem from the rest of the paper is needed here. The source was read through the web tool; no local copy of its bytes is included in this delivery.

The PMC route displayed an access challenge; the public author-hosted copy supplied the reading. The challenge was not bypassed.

## Related lead not used as theorem evidence

David Blackwell, **Comparison of Experiments**, Proceedings of the Second Berkeley Symposium on Mathematical Statistics and Probability, pp. 93–102 (1951). [Berkeley library record](https://digicoll.lib.berkeley.edu/record/112749).

Search metadata was found, but full-text access returned an error. We did not rely on its theorem wording or claim to have verified the paper. The simple value-of-information inequality in this note is proved directly under its stated assumptions. A broader comparison of experiments can remain a later literature lead.

## Local continuity

- [CPXv0.5KEY](../../revisions/v0.5-key/CPXv0.5KEY.md): the adopted research starting point and bounded optional feedback lane.
- [Exact foundations](../../revisions/v0.5-key/research/FOUNDATIONS.md), especially F3 and the proposed causal map: whose consequences enter the selection rule.
- [Prior handoff](../../revisions/v0.5-key/HANDOFF.md): manuscript status, verified results, retained implementation correction, and live-model limits.

This follow-up does not rerun the key's transmission experiments or silently reclassify their evidence. It introduces a separate local experiment identifier and preserves its exact assumptions and scope.
