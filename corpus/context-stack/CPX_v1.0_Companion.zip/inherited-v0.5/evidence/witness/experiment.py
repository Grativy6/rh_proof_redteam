"""CPX05-WITNESS-01: small exact countermodels, not agent behavior data."""
from __future__ import annotations

import argparse
import csv
import json
from collections import defaultdict
from fractions import Fraction as F
from itertools import product
from pathlib import Path


CHECKS = defaultdict(lambda: {"evaluations": 0, "failures": []})


def check(name, condition, case=""):
    CHECKS[name]["evaluations"] += 1
    if not condition:
        CHECKS[name]["failures"].append(str(case))


def dump_json(path, obj):
    path.write_text(json.dumps(obj, indent=2, default=str) + "\n", encoding="utf-8")


def dump_csv(path, rows):
    with path.open("w", encoding="utf-8", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def causal_worlds():
    # In both models C := U observationally; U is a fair binary variable.
    # Intervention replaces only the C assignment, preserving the Y mechanism.
    distributions = {}
    rows = []
    for model, intervention in product(("practice_cause", "common_cause"), (False, True)):
        dist = {pair: F(0) for pair in product((0, 1), repeat=2)}
        for u in (0, 1):
            c = 0 if intervention else u
            y = c if model == "practice_cause" else u
            dist[c, y] += F(1, 2)
        distributions[model, intervention] = dist
        check("causal_distributions_normalize", sum(dist.values()) == 1)
        rows.extend({"model":model, "setting":"do_C_0" if intervention else "observational",
                     "C":c, "Y":y, "probability":pr} for (c, y), pr in dist.items())
    a, b = distributions["practice_cause", False], distributions["common_cause", False]
    check("observational_distributions_identical", a == b)
    check("observational_distribution_known", a == {(0, 0):F(1,2),(0,1):F(0),(1,0):F(0),(1,1):F(1,2)})
    intervention_failure = {
        model: sum(pr for (c, y), pr in distributions[model, True].items() if y == 1)
        for model in ("practice_cause", "common_cause")
    }
    check("interventions_differ", intervention_failure == {"practice_cause":F(0),"common_cause":F(1,2)})
    return rows, {"same_observational_distribution":a == b,
                  "failure_after_do_C_0":intervention_failure}


def evaluate(mapping, inspect, p, q, c, weight, k, benefit, harm):
    """Direct enumeration of all four world/signal events."""
    totals = {key:F(0) for key in ("probability", "revision_probability", "prevented_harm",
                                   "remaining_harm", "private_payoff", "decision_utility", "whole_payoff")}
    for world, signal in product((0, 1), repeat=2):
        prob = (p if world else 1-p) * (q if signal == world else 1-q)
        action = mapping[signal]
        remaining_harm = harm * (1 - world * action)
        private = benefit - c*action - (k if inspect else 0)
        totals["probability"] += prob
        totals["revision_probability"] += prob*action
        totals["prevented_harm"] += prob*(harm - remaining_harm)
        totals["remaining_harm"] += prob*remaining_harm
        totals["private_payoff"] += prob*private
        totals["decision_utility"] += prob*(private - weight*remaining_harm)
        totals["whole_payoff"] += prob*(private - remaining_harm)
    return totals


def run(config):
    axes = [config[key] for key in ("prior_fault", "diagnostic_reliability", "revision_cost", "harm_weight", "inspection_cost")]
    benefit, harm = F(config["private_benefit"]), F(config["harm"])
    rows, cases = [], []
    counts = {regime:defaultdict(int) for regime in config["capability_regimes"]}
    for index, values in enumerate(product(*axes), start=1):
        p, q, c, weight, k = map(F, values)
        case_id = f"W{index:02d}"
        signal_probability = ((1-p)*q + p*(1-q), p*q + (1-p)*(1-q))
        posterior = (p*(1-q)/signal_probability[0], p*q/signal_probability[1])
        check("signal_probability_normalized", sum(signal_probability) == 1, case_id)
        check("posterior_recovers_prior", sum(a*b for a,b in zip(signal_probability, posterior)) == p, case_id)
        for regime in config["capability_regimes"]:
            can_revise = regime == "revision_available"
            tag = case_id + "/" + regime
            prior_action = int(can_revise and weight*p*harm > c)
            prior_map = (prior_action, prior_action)
            diagnosed_map = tuple(int(can_revise and weight*post*harm > c) for post in posterior)
            prior = evaluate(prior_map, False, p, q, c, weight, k, benefit, harm)
            diagnosed = evaluate(diagnosed_map, True, p, q, c, weight, k, benefit, harm)
            gross_voi = diagnosed["decision_utility"] + k - prior["decision_utility"]
            inspect = gross_voi > k
            optional = evaluate(diagnosed_map if inspect else prior_map, inspect, p, q, c, weight, k, benefit, harm)

            # Check against exhaustive feasible policies, independently of the posterior threshold.
            feasible = list(product((0,1), repeat=2)) if can_revise else [(0,0)]
            best_inspected = max(evaluate(m, True, p, q, c, weight, k, benefit, harm)["decision_utility"] for m in feasible)
            best_constant = max(evaluate((a,a), False, p, q, c, weight, k, benefit, harm)["decision_utility"] for a in ((0,1) if can_revise else (0,)))
            # A second formula factors state expectation by signal instead of enumerating realized payoffs.
            base = benefit - weight*harm
            formula_prior = base + (max(F(0), weight*p*harm-c) if can_revise else F(0))
            formula_diagnosed = base-k + (sum(mass*max(F(0),weight*post*harm-c) for mass, post in zip(signal_probability,posterior)) if can_revise else F(0))
            check("posterior_rule_matches_exhaustive_policy_search", diagnosed["decision_utility"] == best_inspected, tag)
            check("prior_rule_matches_exhaustive_action_search", prior["decision_utility"] == best_constant, tag)
            check("closed_formula_matches_direct_enumeration", formula_prior == prior["decision_utility"] and formula_diagnosed == diagnosed["decision_utility"], tag)
            check("free_information_nonnegative_value", gross_voi >= 0, tag)
            check("optional_information_matches_best_available_option", optional["decision_utility"] == max(best_constant, best_inspected), tag)
            check("optional_information_no_worse_than_no_inspection", optional["decision_utility"] >= prior["decision_utility"], tag)
            check("perfect_diagnostic_posteriors", q != 1 or posterior == (F(0),F(1)), tag)
            check("uninformative_diagnostic_has_zero_value", q != F(1,2) or (posterior == (p,p) and gross_voi == 0), tag)
            check("excluded_harm_does_not_motivate_costly_revision", weight != 0 or (diagnosed_map == (0,0) and gross_voi == 0), tag)
            check("unavailable_revision_has_zero_action_value", can_revise or (gross_voi == 0 and not inspect), tag)
            for policy, result, mapping, inspecting in (
                ("no_inspection",prior,prior_map,False),
                ("compulsory_inspection",diagnosed,diagnosed_map,True),
                ("optional_inspection",optional,diagnosed_map if inspect else prior_map,inspect)):
                check("event_probabilities_normalize", result["probability"] == 1, tag + "/" + policy)
                check("harm_bookkeeping", result["prevented_harm"] + result["remaining_harm"] == harm, tag + "/" + policy)
                check("whole_payoff_counts_full_harm", result["whole_payoff"] == result["private_payoff"] - result["remaining_harm"], tag + "/" + policy)
                rows.append({"case":case_id,"regime":regime,"policy":policy,"prior_fault":p,"reliability":q,
                             "revision_cost":c,"harm_weight":weight,"inspection_cost":k,
                             "inspects":int(inspecting),"action_signal_0":mapping[0],"action_signal_1":mapping[1],
                             "posterior_fault_signal_0":posterior[0],"posterior_fault_signal_1":posterior[1],
                             "gross_information_value":gross_voi,
                             "change_from_no_inspection":result["decision_utility"]-prior["decision_utility"],**result})
            counts[regime]["cases"] += 1
            counts[regime]["positive_gross_information_value"] += gross_voi > 0
            counts[regime]["compulsory_inspection_strictly_worse"] += diagnosed["decision_utility"] < prior["decision_utility"]
            counts[regime]["optional_inspection_taken"] += inspect
            counts[regime]["optional_inspection_strictly_better"] += optional["decision_utility"] > prior["decision_utility"]
            counts[regime]["optional_inspection_equal"] += optional["decision_utility"] == prior["decision_utility"]
            cases.append({"case":case_id,"regime":regime,"p":p,"q":q,"c":c,"weight":weight,"k":k,
                          "prior_action":prior_action,"diagnosed_actions":diagnosed_map,"gross_value":gross_voi,
                          "inspection_chosen":inspect,"net_optional_gain":optional["decision_utility"]-prior["decision_utility"]})

    check("grid_bounds", len(rows) == 288 and len(cases) == 96)
    named = {}
    for name, desired, expected_value, expected_inspection in (
        ("useful_free_discrimination", (F(1,4),F(1),F(1),F(1),F(0)), F(1,2), True),
        ("useful_but_tied_with_cost", (F(1,4),F(1),F(1),F(1),F(1,2)), F(1,2), False),
        ("useful_but_too_expensive", (F(3,4),F(1),F(1),F(1),F(1,2)), F(1,4), False),
        ("clear_cause_excluded_harm", (F(1,4),F(1),F(1),F(0),F(0)), F(0), False)):
        result = next(item for item in cases if item["regime"] == "revision_available" and tuple(item[x] for x in ("p","q","c","weight","k")) == desired)
        check("hand_calculated_reference_cases", result["gross_value"] == expected_value and result["inspection_chosen"] == expected_inspection, name)
        named[name] = result
    return rows, dict(counts), named


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    root = Path(__file__).resolve().parent
    output = args.output.resolve()
    if not output.is_relative_to(root):
        raise ValueError("Output must be inside this experiment folder")
    output.mkdir(parents=True, exist_ok=True)
    config = json.loads((root / "config.json").read_text(encoding="utf-8"))
    causal_rows, causal_summary = causal_worlds()
    decision_rows, counts, named = run(config)
    failed = {key:value for key,value in CHECKS.items() if value["failures"]}
    summary = {"experiment_id":config["experiment_id"],"status":"PASS" if not failed else "FAIL",
               "arithmetic":"exact rational", "parameter_tuples":48,"capability_regimes":2,
               "decision_rows":len(decision_rows),"causal_rows":len(causal_rows),
               "causal_worlds":causal_summary,"counts":counts,"named_cases":named,
               "check_categories":len(CHECKS),"check_evaluations":sum(item["evaluations"] for item in CHECKS.values()),
               "failed_categories":list(failed),
               "interpretation_limit":"These are exact consequences of stipulated toy worlds; counts describe this grid only."}
    dump_csv(output/"causal_worlds.csv", causal_rows)
    dump_csv(output/"decision_cases.csv", decision_rows)
    dump_json(output/"checks.json", dict(CHECKS))
    dump_json(output/"summary.json", summary)
    print(json.dumps(summary, default=str))
    if failed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
