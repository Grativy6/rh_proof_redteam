# Witnessed consequences and the next distinction

CPX research follow-up · 11 October 2026 · CPX05-WITNESS-01

**Status: bounded exploration completed.** Two exact toy constructions, a checked primary-source connection, and an open question for the next CPX draft. This note supplements [CPXv0.5KEY](../../revisions/v0.5-key/CPXv0.5KEY.md); it does not replace the key or amend the current manuscript.

Chris supplied the starting question and correction: consequences can be measurable while something remains unresolved, and the perspective witnessing them matters to the distinction subsequently made. Hearthline developed the formulations, source connection, and toy experiments below. Chris is the work's steward. These formulations remain proposals for discussion.

## What the exploration found

**A consequence can be settled as an observation while remaining unresolved as an explanation, a judgment, or a reason to change what gets carried forward.**

An unresolved label needs a question attached to it. “The warning was followed by a loss” and “revising the warning would prevent the loss” ask different things. Evidence sufficient for the first can leave the second open. The second question can also be settled without the witness having the ability to change the warning.

That gives Chris's witness a precise place in the account: the witness has a particular readout, asks a particular question, and can respond through particular available actions. Affected people who are absent from that readout can still bear real consequences. Visibility, attribution, valuation, and ability are separate conditions along the route from consequence to revision. They need not occur in one person or in a fixed chronological order.

## 1. An exact pair of worlds

Let U be a fair binary background condition. Let C indicate use of a particular practice and Y indicate a failure. Consider two stipulated worlds:

| World | Ordinary operation | After deliberately setting C to 0 |
|---|---|---|
| Practice causes the failure | C = U; Y = C | Y = 0 |
| A common condition causes both | C = U; Y = U | Y = U |

In ordinary operation, both worlds give precisely the same record distribution: (C,Y) = (0,0) half the time and (1,1) half the time. No amount of passive sampling of those two variables separates these worlds. Both agree that failures occur and coincide with use of the practice.

Under the intervention C := 0, however, the first world's failure probability is 0 and the second's is 1/2. In this example, changing the practice is useful in one world and ineffective in the other. The measurements are compatible with both causal stories.

This is an elementary illustration of causal non-identifiability, not a new causal theorem. Pearl distinguishes observed associations from intervention effects and defines identifiability through agreement across models compatible with the evidence and assumptions. The distinction directly fits the present question. [Pearl, 2010, §§2.1 and 3.2.1](https://ftp.cs.ucla.edu/pub/stat_ser/r354-corrected-reprint.pdf)

There is also a useful stopping boundary. Re-reading an unchanged record cannot by itself resolve a difference that the record does not express. A different measurement, an intervention, or an additional defensible assumption can change the account. Merely renaming one of the possibilities does not change the toy's predictions.

## 2. Resolution belongs to a question under an account

Here is a compact proposed CPX formulation. Let W(r,A) be the nonempty set of worlds still compatible with readout r and declared assumptions A. A question Q is settled **within this account** when:

`{ Q(w) : w in W(r,A) }` has exactly one value.

It remains unresolved when that set contains several values. An empty W signals inconsistent evidence or assumptions; it is not a successful resolution. Correctness outside the account still depends on its assumptions and coverage.

In the two-world example, the question about the ordinary joint record has one answer. The question about failures after C := 0 has two. The same evidence therefore supports an earned distinction and a retained uncertainty at once.

This is ordinary elementary modeling, continuous with CPX's existing emphasis on scoped claims. No novelty or Lean certification is claimed. If a decision uses only one shared readout, it must give the same deterministic response to worlds producing that readout. When the required responses differ, that input cannot support a guaranteed correct choice in both. Randomizing does not create a guarantee either.

But uncertainty need not prevent every useful action. Several surviving explanations can support the same next step. Asking whether another distinction is needed for this choice differs from asking whether every causal question has been settled.

## 3. A second toy: what makes the explanation change the choice?

This is a separate decision model, not an inference fitted to the first world's observations. Its numbers are chosen examples, not estimates from language users.

There are two possible causes of a current loss of 3 units: a fault in the practice, or an external cause. Revising the practice removes the loss only in the fault world. Keeping it yields a private benefit of 19/10. Revision costs c; an optional diagnostic costs k. A chooser counts remaining harm with weight λ:

`decision utility = private benefit - revision cost - inspection cost - λ * remaining harm`.

λ = 0 excludes the harm from the chooser's objective; λ = 1 counts it fully. The separate whole-payoff column always subtracts the full harm. These are explicitly comparable artificial units, not a scale for judging people.

The sweep uses two prior fault probabilities (1/4, 3/4), three diagnostic reliabilities (1/2, 3/4, 1), two revision costs (1/4, 1), two harm weights (0, 1), and two inspection costs (0, 1/2): **48 parameter tuples**. Each is evaluated with revision available and with only the existing practice available. Three policies give **288 exact decision rows**: no inspection, compulsory inspection, and inspection chosen only when its expected benefit exceeds its cost. Action ties keep the practice; inspection ties skip the diagnostic.

Every probability and payoff is computed as an exact rational. The chooser knows the model, prior, and diagnostic reliability. It does not estimate them, invent experiments, or learn a language.

The action set is deliberately narrow. Exit, delegation, reporting, sanctions, and later learning are not modeled; allowing them can change the results. In particular, keep-only is an artificial capability comparison, not a proposed participation rule for Branchline or a claim that a real witness has no other response.

| Capability | Parameter tuples | Positive value of free diagnosis | Compulsory diagnosis made utility worse | Optional diagnosis chosen |
|---|---:|---:|---:|---:|
| Can revise | 48 | 10 | 23 | 5 |
| Can only keep the practice | 48 | 0 | 24 | 0 |

These are counts in this deliberately constructed grid, not frequencies in nature. Optional inspection improved utility in five revisable cases and tied the no-inspection policy in the other 43. That no-loss property follows from letting a perfectly informed optimizer retain its previous option; it is not evidence that actual agents reliably make that comparison.

Three examples show the causal separations:

- **A clearer cause can justify a different response.** With prior fault probability 1/4, a perfect diagnostic, revision cost 1, and full harm weighting, the prior choice keeps the practice. Free diagnosis instead supports revision exactly when the fault is present. Expected utility improves by 1/2.
- **A real distinction can be too expensive for the present decision.** With prior 3/4 and the same perfect diagnostic, cost, and harm weighting, the prior choice already revises. Diagnosis could avoid unnecessary revision in the external-cause world, worth 1/4 on average. Paying 1/2 for it lowers expected utility, so optional inspection is declined. The causal question stays open while an action remains available.
- **A clear explanation need not become a reason to revise.** With λ = 0 and a positive revision cost, even compulsory perfect diagnosis produces no revision. The explanation is available; the objective excludes the harm it explains. In the separate keep-only regime, revision cannot occur even when harm is counted and its cause is perfectly diagnosed.

Information can also distinguish worlds while leaving the best action unchanged in both. For example, prior 3/4, diagnostic reliability 3/4, revision cost 1/4, and full harm weighting yield posteriors 1/2 and 9/10. Both warrant revision in this toy. The signal distinguishes likelihoods but has zero value for that immediate action.

## 4. The small theorem behind the information result

For a fixed utility U, a fixed available action set, and a known joint distribution of world θ and signal Z:

`E_Z[max_a E[U(a,θ) | Z]] >= max_a E[U(a,θ)]`.

Proof: choose a best constant action a*. At every signal, the conditional maximum is at least the conditional value of a*. Averaging gives at least its unconditional value. A finite action set suffices here. Free information can be ignored.

Inspection costs, compulsory work, an altered action set, incorrect beliefs, or an imperfect chooser change the premise. The inequality also says nothing about future uses of a record beyond the utility and horizon being modeled. “No value for this action” does not mean “no meaning” or “never worth preserving.”

## 5. What this adds to the language question

For harmful consequences to change a communicative practice, it is insufficient simply that a consequence exists or is visible somewhere. The system carrying the practice forward needs a route by which relevant observations can influence revision. A witness may supply that route by noticing, investigating, teaching, objecting, or changing participation. Other participants may then act on the report. None of those responses was simulated here.

This narrows the proposed research question:

**When can a consequence become an available, credible, relevant reason for someone able to change what gets carried forward?**

Chris's whole-language benefit/harm hypothesis remains open. The constructions show why persistence alone cannot establish a corrective feedback path. They do not measure cultural persistence, prove language benevolent, or show that every harmful practice persists. Costs, delayed evidence, competing interests, coercion, coordination, memory, and future uses remain outside these one-step worlds.

For CPX, there is a particularly useful separation. Changing the question asked of the same record can reveal which distinction is already supported. Obtaining an additional diagnostic changes the evidence. A future framing-only comparison must keep those interventions separate. No actual CPX framing treatment or model behavior was tested here.

## Next live question, and a place to stop

Can a system identify **which missing observation would separate the remaining explanations relevant to its next choice**, instead of simply requesting more context?

The next bounded study could supply several compatible causal stories, a menu of diagnostic queries with stated costs, and an option to preserve the unresolved question. Compare targeted selection against asking everything, asking nothing, and a deterministic reference. Separate discovering a useful query from merely executing a query supplied by the experimenter. Keep future-value claims out unless future tasks are explicitly modeled.

That study is **PROPOSED, NOT_RUN**. The current experiment gives the chooser its query and likelihoods; the difficult recognition problem is still open. We can put that question down with an accurate handle. There is no need to keep rereading the same record until it pretends to answer more than it does.

## Receipts and reproduction

The [exact run summary](run-001/summary.json), [decision rows](run-001/decision_cases.csv), [two-world distributions](run-001/causal_worlds.csv), and [checks](run-001/checks.json) are retained beside the [experiment](experiment.py), [configuration](config.json), and [contract](contract.json).

All 21 check categories passed, totaling 1,932 evaluated assertions, including an exhaustive search over the four binary signal policies and four hand-calculated reference cases. These are author-run implementation checks, not independent peer review or a proof-assistant check. The evidence manifest validated. The bounded job had a 120-second wall limit, 1 MiB log limit, and one requested numerical-library thread; Windows did not impose a hard memory cap.

For reproduction, use Python 3.12.14 and the standard library. From this folder run `experiment.py --output replay-NEW` with Python, selecting a fresh output directory. The execution arguments and input hashes are recorded in [run-001/manifest.json](run-001/manifest.json). Preserve the original run. The completed key and v0.4 manuscript remain unchanged.

**Home note:** the strongest new sentence is still small enough to carry: *the consequence can be settled while its meaning for the next choice remains unresolved.*
