# Foundation run history

## run-001: completed, design defect found, superseded for interpretation

The provenance runner completed and the original 19 checks passed. Inspection of the condition table showed perfect retention in every bijective learner condition. This was caused by using the same ordering for unobserved referents and unused labels. With the initial identity code, it silently supplied the original assignments rather than allowing uncertain completion.

This is a defect in Hearthline's experimental implementation, not a discovery about language. The run, script, contract, logs and hashes remain intact. The original checks did not catch it. Do not use its bijective results as evidence for memory retention. The pooled results also use a different random stream from the corrected run and are not the final quoted results.

## run-002: corrected implementation

`toys_v2.py` independently shuffles the unused labels. It adds a fixture requiring uncertain completion to depart from the original identity code, and another requiring indistinguishable observed data to produce the same completion regardless of unseen teacher entries. Configuration and ceilings remain unchanged. Subsequent results must cite run-002 explicitly. Repair may still help, fail, or cost too much; its desired sign is not a pass criterion.
