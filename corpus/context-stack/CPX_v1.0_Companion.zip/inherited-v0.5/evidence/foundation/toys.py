"""Small stipulated worlds, not natural-language or real-model experiments."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
from collections import Counter, defaultdict
import argparse, csv, json, math, random, statistics

ROOT = Path(__file__).resolve().parents[1]
CONFIG = json.loads((ROOT/'experiments/config.json').read_text())

def write_csv(path, rows):
    rows = list(rows)
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)

def information(joint):
    x, y = defaultdict(F), defaultdict(F)
    for (a,b), value in joint.items():
        x[a] += value
        y[b] += value
    return sum(float(v)*math.log2(float(v/(x[a]*y[b])))
               for (a,b),v in joint.items() if v)

def binary(out):
    strategies = list(product(range(2), repeat=2))
    rows = []
    for sender,receiver,n,cost in product(strategies,strategies,range(CONFIG['binary_quality_denominator']+1),CONFIG['binary_costs']):
        q, c = F(n,CONFIG['binary_quality_denominator']), F(cost)
        sm, sa, accuracy = defaultdict(F), defaultdict(F), F(0)
        for state in range(2):
            for flip,prob in [(0,q),(1,1-q)]:
                signal = sender[state]^flip
                action = receiver[signal]
                mass = prob/2
                sm[state,signal] += mass
                sa[state,action] += mass
                accuracy += mass*(state == action)
        utility = 2*accuracy-1-c
        rows.append(dict(sender=''.join(map(str,sender)),receiver=''.join(map(str,receiver)),
                         quality=str(q),cost=str(c),accuracy=str(accuracy),utility=str(utility),
                         weak_participation=int(utility>=0),strict_participation=int(utility>0),
                         threshold=str((1+c)/2),state_signal_bits=information(sm),state_action_bits=information(sa)))
    write_csv(out/'binary.csv',rows)
    return dict(rows=len(rows),weakly_accepted=sum(r['weak_participation'] for r in rows),
                strictly_accepted=sum(r['strict_participation'] for r in rows),
                definition='Choice is stipulated: exact expected receiver utility >= 0. Ties are not observed preferences.')

def welfare(out):
    rows=[]
    for b,c,h,p,e in product(*(map(F,CONFIG[key]) for key in ['sender_benefits','receiver_costs','outsider_harms','accuracies','exit_penalties'])):
        ur, uo = 2*p-1-c, -h
        rows.append(dict(sender=str(b),receiver=str(ur),outsider=str(uo),accuracy=str(p),
                         receiver_cost=str(c),exit_penalty=str(e),total=str(b+ur+uo),
                         participant_compatible=int(b>=0 and ur>=-e),
                         all_affected_zero_baseline_veto=int(b>=0 and ur>=0 and uo>=0)))
    write_csv(out/'welfare.csv',rows)
    free=[r for r in rows if F(r['exit_penalty'])==0 and r['participant_compatible']]
    return dict(rows=len(rows),free_exit_compatible=len(free),
                free_exit_compatible_negative_total=sum(F(r['total'])<0 for r in free),
                counterexample=dict(sender='1',receiver='9/10',outsider='-3',total='-11/10',exit_penalty='0'),
                definition='One-step participation compatibility in comparable artificial utility units; not a Nash or evolutionary stability test.')

def learn(teacher, samples, order, family, arm):
    n=len(teacher)
    examples=[(referent,teacher[referent]) for referent in samples]
    seen=set(samples)
    unseen=[i for i in order if i not in seen]
    queries=0
    if arm == 'targeted' and unseen:
        i=unseen[0]
        examples.append((i,teacher[i]))
        queries=1
    elif arm == 'repeat':
        i=samples[0]
        examples.append((i,teacher[i]))
        queries=1
    known=dict(examples)
    if family == 'pooled':
        counts=Counter(label for _,label in examples)
        fallback=min(counts,key=lambda label:(-counts[label],label))
        child=tuple(known.get(i,fallback) for i in range(n))
    elif family == 'bijective':
        assert len(set(teacher))==n
        unused=[label for label in order if label not in known.values()]
        child=[None]*n
        for i,label in known.items(): child[i]=label
        for i,label in zip((i for i in order if i not in known),unused): child[i]=label
        child=tuple(child)
    else:
        raise ValueError(family)
    return child, queries

def chains(out):
    cfg=CONFIG
    n, generations=cfg['referents'],cfg['generations']
    rows, trajectories=[], []
    for k,seed in product(cfg['training_draws'],range(cfg['seeds'])):
        rng=random.Random(seed*1000+k)
        # All arms and learners receive identical exogenous draws and permutations.
        schedule=[]
        for _ in range(generations):
            samples=[rng.randrange(n) for _ in range(k)]
            order=list(range(n)); rng.shuffle(order)
            schedule.append((samples,order))
        for family,arm in product(cfg['learners'],cfg['arms']):
            teacher=tuple(range(n))
            trial=[]
            for gen,(samples,order) in enumerate(schedule,1):
                child,queries=learn(teacher,samples,order,family,arm)
                r=dict(learner=family,arm=arm,draws=k,seed=seed,generation=gen,
                       distinctions=len(set(child)),optimal_accuracy=len(set(child))/n,
                       original_match=sum(child[i]==i for i in range(n))/n,
                       parent_match=sum(child[i]==teacher[i] for i in range(n))/n,
                       queries=queries,code=''.join(map(str,child)))
                rows.append(r); trial.append(r)
                teacher=child
            trajectories.append(dict(learner=family,arm=arm,draws=k,seed=seed,
                         final_distinctions=trial[-1]['distinctions'],
                         final_original_match=trial[-1]['original_match'],
                         mean_accuracy=statistics.mean(r['optimal_accuracy'] for r in trial),
                         mean_queries=statistics.mean(r['queries'] for r in trial)))
    write_csv(out/'chains.csv',rows)
    write_csv(out/'trajectories.csv',trajectories)
    conditions=[]
    for family,arm,k in product(cfg['learners'],cfg['arms'],cfg['training_draws']):
        group=[r for r in trajectories if (r['learner'],r['arm'],r['draws'])==(family,arm,k)]
        conditions.append(dict(learner=family,arm=arm,draws=k,chains=len(group),
             final_distinctions_mean=statistics.mean(r['final_distinctions'] for r in group),
             final_distinctions_min=min(r['final_distinctions'] for r in group),
             final_distinctions_max=max(r['final_distinctions'] for r in group),
             final_original_match_mean=statistics.mean(r['final_original_match'] for r in group),
             mean_accuracy=statistics.mean(r['mean_accuracy'] for r in group),
             mean_queries=statistics.mean(r['mean_queries'] for r in group)))
    write_csv(out/'conditions.csv',conditions)
    lookup={(r['learner'],r['arm'],r['draws'],r['seed']):r for r in trajectories}
    effects=[]
    for family,k,control,cost in product(cfg['learners'],cfg['training_draws'],['none','repeat'],cfg['repair_costs']):
        differences=[]
        for seed in range(cfg['seeds']):
            a=lookup[family,'targeted',k,seed]; b=lookup[family,control,k,seed]
            # Correct referent gives 1, wrong gives 0; outside random guess gives 1/n.
            # The common 1/n outside payoff cancels in paired differences.
            differences.append((a['mean_accuracy']-cost*a['mean_queries'])-(b['mean_accuracy']-cost*b['mean_queries']))
        effects.append(dict(learner=family,draws=k,comparator=control,query_cost=cost,
             mean_paired_net_effect=statistics.mean(differences),
             seed_min=min(differences),seed_max=max(differences),
             positive_seeds=sum(x>1e-12 for x in differences),
             negative_seeds=sum(x < -1e-12 for x in differences),
             zero_seeds=sum(abs(x)<=1e-12 for x in differences)))
    write_csv(out/'cost_effects.csv',effects)
    return dict(chains=len(trajectories),generation_rows=len(rows),conditions=conditions,
                unit='A chain is one replicate; generations within it are dependent.',
                accuracy='Optimal decoding given the current code, NOT a learned receiver performance.',
                effects='Paired fixed-seed sensitivity within the stipulated model; not population confidence intervals.')

def audits(out):
    # Independent closed-form expectation versus complete tiny sample spaces.
    occupancy=[]
    n=CONFIG['referents']
    for k in CONFIG['occupancy_enumeration_draws']:
        counts=[len(set(sample)) for sample in product(range(n),repeat=k)]
        empirical=F(sum(counts),len(counts))
        expected=n*(1-F(n-1,n)**k)
        assert empirical==expected
        occupancy.append(dict(draws=k,samples=len(counts),mean_distinct=str(empirical),formula=str(expected)))
    tests=[]
    def check(name,condition):
        assert condition, name
        tests.append(dict(name=name,status='PASS'))
    binary_rows=list(csv.DictReader((out/'binary.csv').open(encoding='utf-8')))
    check('binary_count',len(binary_rows)==1008)
    check('threshold_on_all_exact_rows',all(bool(int(r['weak_participation']))==(F(r['accuracy'])>=F(r['threshold'])) for r in binary_rows))
    check('information_range',all(-1e-12<=float(r['state_signal_bits'])<=1+1e-12 for r in binary_rows))
    def row(sender,receiver,q):
        return next(r for r in binary_rows if r['sender']==sender and r['receiver']==receiver and F(r['quality'])==q and r['cost']=='0')
    check('identity_code_perfect',F(row('01','01',1)['accuracy'])==1)
    check('inverted_code_stale_decoder_fails',F(row('01','01',0)['accuracy'])==0)
    check('inverted_code_matched_decoder_perfect',F(row('01','10',0)['accuracy'])==1)
    check('constant_signal_no_state_information',all(abs(float(r['state_signal_bits']))<1e-12 for r in binary_rows if r['sender'] in ['00','11']))
    check('fully_random_channel_no_state_information',all(abs(float(r['state_signal_bits']))<1e-12 for r in binary_rows if F(r['quality'])==F(1,2)))
    w=list(csv.DictReader((out/'welfare.csv').open(encoding='utf-8')))
    check('welfare_count',len(w)==288)
    check('all_veto_accepted_have_nonnegative_total',all(F(r['total'])>=0 for r in w if int(r['all_affected_zero_baseline_veto'])))
    check('free_exit_externality_counterexample_exists',any(F(r['sender'])==1 and F(r['receiver'])==F(9,10) and F(r['outsider'])==-3 and F(r['exit_penalty'])==0 and int(r['participant_compatible']) and F(r['total'])==F(-11,10) for r in w))
    ident=tuple(range(n)); order=list(range(n))
    check('full_coverage_exact_transmission',all(learn(ident,list(range(n)),order,f,a)[0]==ident for f,a in product(CONFIG['learners'],CONFIG['arms'])))
    check('single_label_teacher_cannot_be_repaired_to_six',learn((0,)*n,[0],order,'pooled','targeted')[0]==(0,)*n)
    check('targeted_question_adds_missing_example',len(set(learn(ident,[0],order,'pooled','targeted')[0]))==2)
    check('repetition_does_not_add_missing_referent',len(set(learn(ident,[0],order,'pooled','repeat')[0]))==1)
    chain_rows=list(csv.DictReader((out/'chains.csv').open(encoding='utf-8')))
    check('chain_row_count',len(chain_rows)==38400)
    check('bijection_prior_preserves_six_by_construction',all(int(r['distinctions'])==n for r in chain_rows if r['learner']=='bijective'))
    check('one_query_ceiling',all(int(r['queries'])<=1 for r in chain_rows))
    check('pooled_distinctions_never_increase',all(int(b['distinctions'])<=int(a['distinctions']) for a,b in zip(chain_rows,chain_rows[1:]) if a['learner']=='pooled' and (a['learner'],a['arm'],a['draws'],a['seed'])==(b['learner'],b['arm'],b['draws'],b['seed'])))
    result=dict(status='PASS',checks=tests,occupancy_oracle=occupancy,
                review='Self-audit: exact benchmark, boundary fixtures and invariants; not an independent reviewer or Lean kernel.')
    (out/'audit.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    return dict(checks=len(tests),occupancy_sequences=sum(r['samples'] for r in occupancy),status='PASS')

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--output',required=True)
    out=ROOT/parser.parse_args().output
    out.mkdir(parents=True,exist_ok=True)
    result=dict(binary=binary(out),welfare=welfare(out),chains=chains(out))
    result['audit']=audits(out)
    (out/'summary.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(dict(binary_rows=result['binary']['rows'],welfare_rows=result['welfare']['rows'],
                          chains=result['chains']['chains'],generation_rows=result['chains']['generation_rows'],audit=result['audit'])))

if __name__=='__main__':main()
