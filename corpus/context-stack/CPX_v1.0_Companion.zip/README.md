# Context Parallax v1.0 companion

**Context Parallax: Changing the view without losing the question**  
Christopher Daniel Pang, human author and steward  
Hearthline, named AI collaborator  
12 October 2026 | DOI reserved: **10.5281/zenodo.23306102**

This companion supplies the evidence and editable sources for the v1.0 research preprint. The article is a separate PDF in the same deposit. Original release material is licensed under **CC BY 4.0**; see [LICENSE.txt](LICENSE.txt) and [RIGHTS.md](RIGHTS.md).

## Read the result

The matched recognition pilot contains **432 calls**. Plain and recipient-frame guidance selected the same answer in every matched pair. Local 4B scored 140/144 and local 9B 144/144 under the frozen answer-and-format endpoint. Hosted 32B scored 0/144 under the strict parser, and 140/144 under the separately labeled post-hoc outer-fence removal diagnostic. No framing advantage or causal model-size effect is established.

The formal companion checks **33 selected declarations in four claim families**. Its five modules passed replay by Lean's own kernel. Cached imports are trusted. The source-to-formal review is a self-review, and the full manuscript and empirical claims are outside that formal coverage.

## Find the evidence

| Question | Start here |
| --- | --- |
| What was sent to the models? | [Frozen study](studies/maintain02/FREEZE.json) and [prompts](studies/maintain02/prompts.jsonl) |
| What did they return and how were they scored? | [Analysis](evidence/model/analysis.json), [scores](evidence/model/scored.json), and the three raw JSONL files in that directory |
| What did review change? | [Review response](history/v0.6/audit/REVIEW_RESPONSE.md) and [v1.0 changes](CHANGES.md) |
| Which mathematics was checked? | [Formal result](formal/RESULTS.md), [theorem registry](formal/THEOREMS.json), and [source review](formal/history/FINAL_SOURCE_REVIEW.md) |
| How do those old proof receipts apply to this edition? | [Claim crosswalk](audit/CLAIM_CROSSWALK.json); all five controlling passages are unchanged |
| Where are the finite toys and their failures? | `inherited-v0.5/evidence/` and `evidence/review/`; the superseded foundation run remains labeled |
| Where are the editable article files? | [Markdown](manuscript/Context_Parallax_v1.0.md) and [Word](manuscript/Context_Parallax_v1.0.docx) |
| What was checked for this release? | [Publication review](audit/RELEASE_REVIEW.md), [document verification](audit/DOCUMENT_VERIFICATION.json), and [preservation checks](audit/RELEASE_INPUT_CHECKS.json) |

## Verify without a model or private files

Extract the complete ZIP into a writable directory. With Python 3.11 or later, run from that directory:

```text
python tools/verify_package.py
```

This uses Python's standard library. It checks every payload hash, the manuscript crosswalk and original proof-source identities, replays the finite constructions and re-scores the **saved** responses. It makes no model or network call and creates only a `tmp/` verification directory. There is no need for credentials, local models, Chris's H: drive, or the original private chatlogs. Add `--integrity-only` to check just the retained files and bindings.

Archive hashes are exact. Replay comparisons preserve the inherited policy: parsed JSON and each prompt manifest's own bytes; exact discrete and rational values; absolute tolerance at most 1e-12 bits only in the explicitly named logarithmic information fields. The mutation guards test those boundaries. Sampling seeds, failed runs and the strict/supplementary scoring distinction remain intact.

## Replay the formal companion separately

Follow [formal/README.md](formal/README.md). This requires the pinned Lean 4.32.1 toolchain and a matching Mathlib dependency cache, supplied separately to keep this package small. Obtaining public dependencies can require internet access. The replay writes to a fresh output directory and leaves the proof sources and old receipts unchanged. It never initiates a model call.

## Read historical records as historical records

`history/v0.6/` contains selected original documents and audits, including the controlling manuscript and claim cards. `inherited-v0.5/` carries the older finite studies and development sources. Preparation labels and local paths in those records describe their original time and location. They are not present-day status or runtime dependencies. The old v0.6 manifest describes that original archive, including its former PDF and Word files; those two formats are omitted here to avoid duplicating historical editions. The original Markdown and its hash are retained.

`formal/history/` preserves the original source lock, failed attempts and successful report completion. `formal/PORTABLE_SOURCE_LOCK.json` changes only the paths used to resolve the same three input hashes inside this archive. `MANIFEST.json` is the current package inventory.

Full private conversations, raw reviewer conversations, third-party reading PDFs, model weights, dependency caches and temporary render images are excluded. The selected source descriptions and attributed review findings are part of the paper; excluded sources do not become independently inspectable merely because their hashes are recorded.

The package is an inspectable research record. It does not demonstrate general framing benefit, whole-language welfare, a new cognitive mechanism, or independent human peer review.
