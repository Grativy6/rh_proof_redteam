# Rights and attribution

Christopher Daniel Pang has selected **Creative Commons Attribution 4.0 International (CC BY 4.0)** for the original CPX v1.0 manuscript, original companion code, fixtures, documentation and other original release material, to the extent he holds the relevant rights. The complete license is in `LICENSE.txt` and its official text is at https://creativecommons.org/licenses/by/4.0/legalcode .

Credit the paper as **Christopher Daniel Pang, with Hearthline as named AI collaborator**. The manuscript describes the separate human and AI contributions and preserves the adopted credit **human author and steward**.

The original Lean companion comes from Grativy6/hearthline, whose retained repository license is the same CC BY 4.0 license copied here. Its proof and report source bytes retain their original identities. Dependencies such as Lean, Mathlib, Python, Word fonts and LibreOffice are not bundled or relicensed by this package. Consult each dependency's own license when obtaining it.

Third-party references, attributed quotations and trademarks retain their existing rights; inclusion or citation does not extend this license over them. Raw retained model responses identify their originating services and are research records, not a claim to ownership of third-party model weights or provider technology. No third-party reading PDFs or full private chatlogs are distributed.

For reuse, preserve the relevant origin and indicate your changes. Neither attribution nor an evidence receipt implies endorsement of a later interpretation or claim.
