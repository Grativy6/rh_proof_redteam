# Context Parallax formal companion

The original result checks **33 selected declarations in four claim families**. All five modules passed replay by Lean's own kernel under Lean 4.32.1. This publication package preserves the checked proof and reporting sources byte-for-byte, along with the original result, failed attempts and source-to-formal self-review.

Start with [RESULTS.md](RESULTS.md), [THEOREMS.json](THEOREMS.json), [audit/RESULT.json](audit/RESULT.json) and [history/FINAL_SOURCE_REVIEW.md](history/FINAL_SOURCE_REVIEW.md). The original public README is retained at [history/PUBLIC_README.md](history/PUBLIC_README.md).

## Replay using a matching dependency cache

Use Python 3.11 or later and the Lean 4.32.1 toolchain. Supply an existing Lean project whose `lean-toolchain` and all package revisions in `lake-manifest.json` match those here. The runner checks those pins and the direct import caches before starting. It reads that project's dependency files without changing them.

From this `formal` directory, run the following command after replacing the two angle-bracket placeholders with directories on your machine. The output directory must be new.

```text
python run_checks.py --dependency-project "<matching-project>" --toolchain-dir "<Lean-4.32.1-toolchain>" --source-lock PORTABLE_SOURCE_LOCK.json --output ../tmp/formal-replay-001 --run
```

For example, the toolchain directory contains `bin/lean` and `bin/leanchecker` (with `.exe` on Windows). A dependency project contains its own `.lake/packages/` cache. No particular user name, drive letter or private source is needed. Omitting `--run` performs static preparation checks only.

If you do not have a matching cache, use a separate writable dependency directory containing copies of this folder's `lakefile.toml`, `lake-manifest.json` and `lean-toolchain`. Install the pinned Lean release with Elan, then use Lake's ordinary dependency/cache setup for that manifest (commonly `lake exe cache get` from the dependency directory). This setup may download public dependencies and is separate from the offline Python package check. Preserve the pinned manifest: do not substitute an unpinned latest Mathlib revision. Cache availability depends on the upstream project and network.

The exact setup route used for this release reused an already installed matching cache; a fresh network installation was not tested. The replay runner rejects mismatched revisions or missing direct import caches before execution.

## What the replay establishes

The runner compiles the six source units (five modules and the root import), prints all 33 statements and axiom dependencies, and replays the five modules through Lean's kernel checker. It retains commands, return codes, output hashes and before/after source identities. It permits only the recorded standard axiom names. It does not alter a failed attempt's status.

`PORTABLE_SOURCE_LOCK.json` locates three unchanged historical sources inside this package: the v0.6 manuscript, its claim cards and the exact diagnostic fixture. Only paths differ from [history/SOURCE_LOCK.json](history/SOURCE_LOCK.json). The [v1.0 crosswalk](../audit/CLAIM_CROSSWALK.json) identifies the five unchanged passages in the new edition. Its new manuscript hash is not a new theorem receipt.

The runner's successful status still says that source review is required. The original comparison is the explicitly labeled self-review in `history/FINAL_SOURCE_REVIEW.md`; the v1.0 publication review checks its unchanged textual correspondence. Neither is an independent referee review.

The information target has finite nonempty domains, rational joint masses and rational utilities. The sequence claim concerns every finite list of passive inputs. Real-valued generalizations, conditional-posterior equality, logarithmic calculations, infinite stochastic processes, modeling adequacy, model behavior and the broader language-benefit hypothesis remain outside this proof. Cached Lean and Mathlib imports are trusted; this is not an independent kernel implementation or a complete library audit.
