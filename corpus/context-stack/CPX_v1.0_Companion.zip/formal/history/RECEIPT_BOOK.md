# CPX v0.6 — Lean receipt book

**All 33 selected declarations compiled; all five modules passed kernel replay.** The four scoped claim cards passed the separate source-to-formal self-review. Completed 11 October 2026, America/New_York.

The proof run is complete. Christopher Daniel Pang is the human author and steward; Hearthline is the named AI collaborator. The v0.6 manuscript and its inspection package were preserved. Nothing was pushed to GitHub or published to Zenodo.

## What the check earned

| Family | Declarations | Result |
| --- | ---: | --- |
| Capsule decoding | 4 | Recoverability exactly matches constancy on attained capsule fibers, including empty and collision cases. |
| Protected return | 4 | A preserved projection preserves an answer derived from it. Equal answers can still have different histories. |
| Optional information and diagnostics | 15 | Free optional information cannot reduce optimal finite rational value under fixed premises. Both example channels have accuracy 3/4, but gross values 3/16 and zero. |
| Question-relative resolution | 10 | One query can be settled while another stays open. The same observed joint table supports intervention probabilities 0 and 1/2 in the supplied causal worlds. |

These results check the key's mathematical statements. They do not certify the whole paper, the model pilot, an empirical framing benefit, or completeness of a real-world account. The rational information result and finite-sequence causal result keep the narrower scopes declared in the key.

## Follow the evidence

- [Final source-to-formal review](FINAL_SOURCE_REVIEW.md): source locators, dependency graph, obligation matrix, definitions, repairs and exact remaining limits. This was a self-review, not an independent referee review.
- [Final compilation receipt](evidence/attempt-003/receipt.json): six successful compilation commands, followed by the original failed report command.
- [Successful reporting and kernel receipt](evidence/attempt-003-report-completion/receipt.json): all statements, exact axiom lists, unchanged compiled-object hashes and five successful named kernel replays.
- [Elaborated statements and axiom output](evidence/attempt-003-report-completion/statements-and-axioms.stdout.txt).
- [Source lock](SOURCE_LOCK.json) and [dependency checkout check](evidence/dependency-checkouts.json).
- [Third-round record](evidence/round-003.json): one diagnostic pass, repair, full compilation and report completion under the original ceiling.
- [Prepared work key](output/pdf/CPXv0.6-LEAN-KEY.pdf). Its preparation label is historical; this receipt records execution.

Lean 4.32.1 and the pinned Mathlib revision 520045ab14e26149ee970e2e617ca04b09bde5d6 were used. The three controlling input hashes matched before and after the run. All nine dependency checkout revisions matched their manifest and had no tracked changes when checked.

Kernel replay used Lean's own checker with trusted cached imports. It was not an independent proof system or a full fresh verification of Mathlib. Seven declarations use no axioms; the others use subsets of propext, Classical.choice and Quot.sound. Raw universe-decorated names are retained, not discarded.

## Failure history remains part of the receipt

1. [Initial attempt](evidence/attempt-001/receipt.json): the empty-domain control needed a library instance import.
2. [First repair round](evidence/attempt-002/receipt.json): a tuple type annotation was syntactically invalid.
3. The final round's [diagnostic pass](evidence/round-003-diagnostics/preparation.json) found policy-enumeration instance mismatches and numeric simplification that altered the comparison expression. Repairs preserved the intended statements. The subsequent full compilation accepted every module.
4. The final runner stopped at an unsupported report-formatting option, pp.width. That failed receipt was preserved. The reporting step was corrected to format.width, and axiom-name comparison was adjusted for printed universe suffixes. Reporting and the first kernel replays then finished against the same proof objects. No fourth proof-repair round or additional proof compilation was used.

The final round, including its diagnostics and reporting repair, took 443.2 seconds, below its 1,800-second ceiling. The three full executions and all diagnostic/report commands are retained. Exact historical source bytes recovered from retained files or the preparation commit are indexed in [historical-source-recovery.json](evidence/historical-source-recovery.json); a byte set was saved only if it matched the original hash.

## Declaration inventory

Every row below has successful compilation, recorded statement and axiom output, and successful replay of its containing module. The inventory has 33 rows, not 33 independent research discoveries.

| Declaration | Claim | Role | Axioms | Result |
| --- | --- | --- | --- | --- |
| `CPX.Capsule.decoder_iff` | CPX06-C1 | source-facing target | Classical.choice | Passed |
| `CPX.Capsule.collision_blocks_decoder` | CPX06-C1 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Capsule.empty_attained_decoder_exists` | CPX06-C1 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Capsule.no_total_empty_answer_decoder` | CPX06-C1 | boundary or exact fixture | none | Passed |
| `CPX.ProtectedReturn.protected_return` | CPX06-C2 | source-facing target | none | Passed |
| `CPX.ProtectedReturn.same_answer_different_history` | CPX06-C2 | boundary or exact fixture | none | Passed |
| `CPX.ProtectedReturn.factorization_is_needed` | CPX06-C2 | boundary or exact fixture | none | Passed |
| `CPX.ProtectedReturn.projection_preservation_is_needed` | CPX06-C2 | boundary or exact fixture | none | Passed |
| `CPX.Information.le_maximum` | CPX06-C3 | helper | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Information.maximum_le` | CPX06-C3 | helper | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Information.constant_policy_inclusion` | CPX06-C3 | helper | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Information.free_optional_information` | CPX06-C3 | source-facing target | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Information.zero_mass_signal_contributes_zero` | CPX06-C3 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Information.single_action_no_gross_gain` | CPX06-C3 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Information.compulsory_cost_can_hurt` | CPX06-C3 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Diagnostics.distributions_valid` | CPX06-C3 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Diagnostics.equal_accuracy` | CPX06-C3 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Diagnostics.symmetric_upper_bound` | CPX06-C3 | helper | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Diagnostics.constant_upper_bound` | CPX06-C3 | helper | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Diagnostics.symmetric_best_value` | CPX06-C3 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Diagnostics.constant_best_value` | CPX06-C3 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Diagnostics.blind_values` | CPX06-C3 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Diagnostics.unequal_gross_values` | CPX06-C3 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Resolution.empty_not_settled` | CPX06-C4 | boundary or exact fixture | Quot.sound, propext | Passed |
| `CPX.Resolution.empty_agreement_is_vacuous` | CPX06-C4 | boundary or exact fixture | Quot.sound, propext | Passed |
| `CPX.Resolution.one_query_settled_another_open` | CPX06-C4 | source-facing target | none | Passed |
| `CPX.Resolution.same_observation` | CPX06-C4 | helper | none | Passed |
| `CPX.Resolution.observational_tables_agree` | CPX06-C4 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Resolution.fair_observation_table` | CPX06-C4 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Resolution.passive_sequences_agree` | CPX06-C4 | boundary or exact fixture | Quot.sound | Passed |
| `CPX.Resolution.different_interventions` | CPX06-C4 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Resolution.observation_query_settled` | CPX06-C4 | boundary or exact fixture | Classical.choice, Quot.sound, propext | Passed |
| `CPX.Resolution.intervention_query_not_settled` | CPX06-C4 | source-facing target | Classical.choice, Quot.sound, propext | Passed |

## Saved package

Local commit `b68d3cd82d9087c080aa3a9e0f0f4101db411544` contains the completed formal companion and shareable formal outputs. The checkout is clean. All 12 checked candidate files match both their recorded execution hashes and the committed Git object bytes. [POSTFLIGHT.json](POSTFLIGHT.json) records that check. The initial Git-byte mismatch and its correction are retained in [git-byte-preservation.json](evidence/git-byte-preservation.json). Nothing was pushed.
