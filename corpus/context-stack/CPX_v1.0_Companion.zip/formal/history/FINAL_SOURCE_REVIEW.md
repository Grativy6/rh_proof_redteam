# CPX v0.6 — source-to-formal review

**Primary verdict: proved as written, for the 33 declarations and the four scoped claim cards in this key.** This verdict covers the finite rational information target, not an unqualified real-valued generalization or the entire CPX manuscript.

**Review role:** Hearthline self-review, 11 October 2026 (America/New_York). The same collaborator prepared and repaired the formalization. This is not an independent referee report. Lean compilation and kernel replay are separate machine evidence.

## Sources and evidence

The controlling manuscript is `../v0.6/output/Context_Parallax_v0.6_WORKING_DRAFT.md`, SHA-256 `ecc4d45107d20e7d148efeee26491f8310c897785575511fc32bd290ca8ce5dc`. Its actual paragraphs were read alongside the claim cards, candidate definitions and proof bodies, and the elaborated statement output. The cards alone were not treated as the source.

`SOURCE_LOCK.json` also binds `../v0.6/LEAN_CLAIMS.json` and the exact diagnostic fixture in `../v0.6/evidence/review/channel-counterexamples.json`. All three hashes were checked before execution and again after report completion.

The final proof compilations are in `evidence/attempt-003/receipt.json`. That wrapper honestly retains a failed status because its statement-report command rejected `pp.width`. The successful statement/axiom extraction and all five first kernel replays are in `evidence/attempt-003-report-completion/receipt.json`. Those replays used the same compiled proof objects; none was repaired or recompiled after attempt 003. The report-completion record checks their hashes, the unchanged proof sources, and the two reporting-file changes.

## Dependency graph

- C1: attained-value subtype and its lift → fiber-constant answer plus chosen representative → decoder; decoder plus equal capsules → equal answers. The finite-domain hypothesis is retained in the target, although this proof does not use finiteness. Classical choice is an explicit dependency.
- C2: supplied factorization and projection-preserving endomap → substitution → protected answer unchanged. The Boolean-history and omitted-premise examples are separate internal counterexamples.
- C3: finite nonempty maximum and its upper/lower bounds → every constant action gives an available contingent policy → best contingent value is at least the blind value. The source-facing theorem adds normalized nonnegative joint masses. The two diagnostic matrices and utility definition feed exact bounds over all four Boolean policies and explicit attaining policies.
- C4: nonempty supplied world set plus a constant query → settlement. Two structural equations and the same exogenous input give equal observations; replacing only the C equation gives unequal intervention probabilities. The different probabilities witness a query that is not settled.

All target proof leaves are internal Lean proofs or imported library declarations. The interpretation of the supplied types, world set, utility, and channel parameters is a modeling convention checked against the manuscript. Completeness of a real-world account is not an inferred premise. Mathlib and Lean's imported dependencies remain trusted. The dependency graph is acyclic: Diagnostics imports Information; the other four modules do not import one another; the root imports the five modules.

## Obligation matrix

| Obligation | Result | Evidence and limit |
| --- | --- | --- |
| C1 objects and quantifiers | Passed | Manuscript section 3, line 69; `decoder_iff` quantifies arbitrary types with finite X, and its decoder is defined on `Attained c`. A has no default or nonempty requirement. |
| C1 empty and collision cases | Passed | A constant capsule cannot decode both Boolean answers. With X and A empty and C inhabited, an attained-domain decoder exists while a total ambient decoder does not. |
| C2 exact implication | Passed | Section 3, line 65; T is an endomap. Both factorization and preservation are hypotheses. The output is equality of q, not equality of full states. |
| C2 limits | Passed | Two states with answer 7 and different Boolean histories differ. The omitted-premise controls show that dropping either premise permits a counterexample; they do not claim that each premise is logically necessary in every special instance. |
| C3 feasible policies and maxima | Passed | Section 9, lines 211–213; W, S and A are finite nonempty types, values are rational, and all policies S → A are available, including constants. Both sides use the same masses, action set and utility. |
| C3 stronger helper | Passed, labeled | `constant_policy_inclusion` does not need mass positivity or normalization. Those assumptions remain explicit in `free_optional_information`; no revised probabilistic claim is being smuggled into the helper. |
| C3 zero mass and cost | Passed | Zero-mass branches contribute zero without posterior division. A singleton action type has no gross gain, so subtracting a positive compulsory cost strictly lowers net value. |
| C3 numerical fixture and exhaustive range | Passed | Section 9, lines 199 and 205–207; joint masses are 9/16, 3/16, 1/16, 3/16 versus 3/4, 0, 1/4, 0. Case splits cover both outputs of every Boolean policy, hence all four policies. These are exact rational proofs, not floating-point agreement. |
| C3 broader formulations | Out of scope | Arbitrary real utilities and the separate conditional-posterior equality are not formalized. The information-theoretic logarithm calculations are also outside the key. |
| C4 nonemptiness and question dependence | Passed | Section 3, line 73; `Settled` explicitly requires a nonempty account. Empty universal agreement is vacuous and does not satisfy settlement. |
| C4 causal equations | Passed | Section 9, line 197; both worlds set C = U. One retains Y = C and the other Y = U. Intervention replaces only C, leaving U and the respective Y equation fixed. |
| C4 probability and sequence claims | Passed within stated scope | The observational joint table has mass 1/2 on each diagonal pair. After do(C=0), P(Y=1) is 0 versus 1/2. Observations agree for every finite list of shared U inputs; no infinite stochastic-process theorem is claimed. |
| All formal statements and axiom inventory | Passed | All 33 elaborated statements were inspected. Axiom sets contain only the declared Lean standard axioms, or are empty; exact lists are retained. |
| Source adequacy, empirical benefit, intent or experience | Out of scope | Kernel checking does not certify the selection of real-world alternatives, the pilot, broader language hypotheses, or any psychological interpretation. |
| Literature priority and complete library correctness | Not addressed by this run | Existing manuscript attribution is retained, rather than re-audited or promoted by the Lean result. Cached dependencies were not rebuilt or independently reverified. |

## Decisive calculations and repairs

Both diagnostic channels have accuracy 3/4. Their blind values are -11/10. The symmetric channel attains -73/80 and the constant channel -11/10; gross values are therefore 3/16 and zero. This verifies the particular counterexample to using one accuracy number as a decision-value summary.

The compiler repairs added the library instance for an empty finite domain, corrected tuple type-annotation parentheses, supplied classical policy enumeration, aligned the Boolean function enumeration used by the concrete maxima, and kept arithmetic simplification on the numerical witness side of the proof. The intended theorem statements, model constants, and source claims stayed fixed. The earlier tuple text was syntactically invalid, so the relevant claim is preservation of its intended statement, not equivalence between two previously elaborated statements.

The reporting repair replaced unsupported `pp.width` with `format.width` and taught axiom extraction to preserve universe-decorated raw names while comparing their underlying declaration names. It did not add an allowed axiom, change a proof, or turn a failed process into a success. The original failed output remains intact.

## Remaining gap and strongest safe statement

There is no remaining proof obligation for the 33 selected declarations. They compiled and their five containing modules were replayed by Lean's own kernel, with the printed standard axiom dependencies and trusted imports. The comparison to the four declared claim cards found no mismatch after the implementation repairs.

The full manuscript is not thereby formally verified. The real-valued/conditional information formulations, infinite-process formulations, modeling adequacy, empirical results, and an independent source-to-formal audit remain outside this run. The cheapest useful next independent check would give a fresh reviewer the manuscript paragraphs and these definitions before showing this verdict. No additional execution or publication is initiated by this review.
