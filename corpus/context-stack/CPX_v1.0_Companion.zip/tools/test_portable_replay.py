"""Guard the narrowly relaxed replay policy with deliberately damaged fixtures."""
from pathlib import Path
import hashlib, json, tempfile, unittest
from portable_replay import compare_csv, compare_json, compare_prompt_tree, prompt_manifest_valid

class ReplayGuards(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
    def csv_pair(self, first, second):
        a,b=self.root/'a.csv',self.root/'b.csv'
        a.write_text('id,exact,state_signal_bits\n'+first+'\n',encoding='utf-8',newline='\r\n')
        b.write_text('id,exact,state_signal_bits\n'+second+'\n',encoding='utf-8',newline='\n')
        return compare_csv(a,b,{'state_signal_bits'})['passed']
    def test_newlines_and_tiny_log_drift(self):
        self.assertTrue(self.csv_pair('A,1/2,0.06593194462450905','A,1/2,0.06593194462450899'))
    def test_changed_decision(self):
        self.assertFalse(self.csv_pair('A,1/2,0.1','A,2/3,0.1'))
    def test_changed_identifier(self):
        self.assertFalse(self.csv_pair('A,1/2,0.1','B,1/2,0.1'))
    def test_changed_information(self):
        self.assertFalse(self.csv_pair('A,1/2,0.1','A,1/2,0.100001'))
    def test_nonfinite_information(self):
        for n in ['nan','inf','-inf']:
            self.assertFalse(self.csv_pair('A,1/2,'+n,'A,1/2,'+n))
    def test_other_float_has_no_tolerance(self):
        self.assertFalse(self.csv_pair('A,0.1,0.1','A,0.10000000000001,0.1'))
    def test_json_tolerance_exact_paths_only(self):
        a={'i':.1,'count':2}; b={'i':.10000000000001,'count':2}
        self.assertTrue(compare_json(a,b,{('i',)}))
        self.assertFalse(compare_json(a,b))
        self.assertFalse(compare_json(a,{'i':.1,'count':2.00000000001},{('i',)}))
    def test_json_nonfinite_and_type_changes(self):
        self.assertFalse(compare_json({'i':float('nan')},{'i':float('nan')},{('i',)}))
        self.assertFalse(compare_json({'n':True},{'n':1}))
    def tree(self, name, newline, value='same'):
        root=self.root/name;(root/'prompts').mkdir(parents=True)
        p=root/'prompts/x.json';p.write_text(json.dumps({'text':value},indent=2)+'\n',encoding='utf-8',newline=newline)
        (root/'prompt_manifest.json').write_text(json.dumps([{'file':'prompts/x.json','sha256':hashlib.sha256(p.read_bytes()).hexdigest()}]),encoding='utf-8')
        return root
    def test_each_manifest_checks_own_bytes(self):
        a=self.tree('a','\r\n');b=self.tree('b','\n')
        self.assertNotEqual((a/'prompts/x.json').read_bytes(),(b/'prompts/x.json').read_bytes())
        self.assertTrue(compare_prompt_tree(a,b))
    def test_changed_prompt_with_valid_new_hash_rejected(self):
        self.assertFalse(compare_prompt_tree(self.tree('a','\r\n'),self.tree('b','\n','changed')))
    def test_bad_hash(self):
        a=self.tree('a','\n');(a/'prompts/x.json').write_text('{}',encoding='utf-8')
        self.assertFalse(prompt_manifest_valid(a))
    def test_unlisted_prompt(self):
        a=self.tree('a','\n');(a/'prompts/extra.json').write_text('{}',encoding='utf-8')
        self.assertFalse(prompt_manifest_valid(a))
    def test_duplicate_manifest_entry(self):
        a=self.tree('a','\n');p=a/'prompt_manifest.json';m=json.loads(p.read_text());p.write_text(json.dumps(m+m))
        self.assertFalse(prompt_manifest_valid(a))

if __name__=='__main__':
    unittest.main(verbosity=2)
