from pathlib import Path
import json,csv,hashlib,statistics,collections,random,re
ROOT=Path(__file__).resolve().parents[1];S=ROOT/'studies/maintain02';D=ROOT/'evidence/model'
prompts={x['id']:x for x in map(json.loads,(S/'prompts.jsonl').read_text(encoding='utf-8').splitlines())}
pins=json.loads((S/'FREEZE.json').read_text())['sha256']
for name,digest in pins.items():assert hashlib.sha256((S/name).read_bytes()).hexdigest()==digest,name
scored=[]; summaries={};rawpins={}
for tag in ['qwen4b','qwen9b','qwen32b']:
 path=D/f'{tag}.jsonl'
 if not path.exists():continue
 events=[json.loads(s) for s in path.read_text(encoding='utf-8').splitlines()];rawpins[path.name]=hashlib.sha256(path.read_bytes()).hexdigest()
 done={e['id']:e for e in events if e['final']}
 rows=[]
 for uid,p in prompts.items():
  if uid not in done:continue
  event=done[uid];r=event.get('response',{})
  text=r.get('choices',[{}])[0].get('message',{}).get('content','') if tag=='qwen32b' else ''.join(x.get('content','') for x in r.get('output',[]) if x.get('type')=='message')
  parsed=None
  try:parsed=json.loads(text)
  except (ValueError,TypeError):pass
  valid=isinstance(parsed,dict) and parsed.get('choice') in ['A','B','C','D'] and isinstance(parsed.get('reason'),str)
  choice=parsed['choice'] if valid else None
  # POST-HOC diagnostic only: remove exactly one enclosing Markdown JSON fence.
  # Preserve strict primary scores. No repair of malformed JSON or reasoning content.
  secondary=parsed
  fence=re.fullmatch(r'\s*```(?:json)?\s*\n(.*?)\n```\s*',text or '',re.S)
  if not valid and fence:
   try:secondary=json.loads(fence.group(1))
   except ValueError:secondary=None
  sec_valid=isinstance(secondary,dict) and secondary.get('choice') in ['A','B','C','D'] and isinstance(secondary.get('reason'),str)
  sec_choice=secondary['choice'] if sec_valid else None
  row={'id':uid,'tag':tag,'case':p['case'],'carry':p['carry'],'phrase':p['phrase'],'arm':p['arm'],
    'choice':choice,'reference':p['reference_choice'],'correct':bool(valid and choice==p['reference_choice']),
    'valid_json':valid,'support_coverage':p['support_coverage'],'flags':p['option_flags'].get(choice,[]),
    'reason':secondary.get('reason','') if isinstance(secondary,dict) else '', 'raw_text':text,'elapsed':event['elapsed_seconds'],'error':event.get('error'),
    'posthoc_choice':sec_choice,'posthoc_correct':bool(sec_valid and sec_choice==p['reference_choice']),
    'posthoc_flags':p['option_flags'].get(sec_choice,[]),'enclosing_fence_removed':bool(not valid and fence)}
  rows.append(row);scored.append(row)
 per=[]
 for carry in ['full','receipt','handle']:
  for arm in ['plain','frame']:
   sub=[r for r in rows if r['carry']==carry and r['arm']==arm]
   per.append({'carry':carry,'arm':arm,'n':len(sub),'correct':sum(r['correct'] for r in sub),'posthoc_correct':sum(r['posthoc_correct'] for r in sub),'malformed':sum(not r['valid_json'] for r in sub)})
 pairs=collections.defaultdict(dict)
 for r in rows:pairs[(r['case'],r['carry'],r['phrase'])][r['arm']]=r['correct']
 complete=[r for r in pairs.values() if len(r)==2]
 summaries[tag]={'completed':len(rows),'expected':144,'correct':sum(r['correct'] for r in rows),'cells':per,
 'posthoc_correct':sum(r['posthoc_correct'] for r in rows),'enclosing_fences_removed':sum(r['enclosing_fence_removed'] for r in rows),
 'framing_win':sum(r['frame'] and not r['plain'] for r in complete),'framing_loss':sum(r['plain'] and not r['frame'] for r in complete),
 'paired_ties':sum(r['plain']==r['frame'] for r in complete),'selected_option_flags':dict(collections.Counter(f for r in rows for f in r['flags'])),
 'mean_elapsed_seconds':statistics.mean(r['elapsed'] for r in rows),'transport_attempts':len(events),
 'errors':[r for r in rows if not r['posthoc_correct']]}
(D/'scored.json').write_text(json.dumps(scored,indent=2,ensure_ascii=False),encoding='utf-8')
ledger=[json.loads(x) for x in (D/'runpod-ledger.jsonl').read_text().splitlines()]
latest={r['id']:r for r in ledger}
spend={'requests':len(latest),'reported_usd':sum(r.get('service_cost_usd') or 0 for r in latest.values()),
 'accounted_usd':sum(r.get('accounted_usd',r.get('reserved_usd',0)) for r in latest.values()),
 'unresolved_reserved_usd':sum(r.get('reserved_usd',0) for r in latest.values() if r['status']!='RETURNED'),
 'total_tokens':sum(r.get('usage',{}).get('total_tokens',0) for r in latest.values()),
 'input_tokens':sum(r.get('usage',{}).get('prompt_tokens',0) for r in latest.values()),
 'output_tokens':sum(r.get('usage',{}).get('completion_tokens',0) for r in latest.values()),
 'ceiling_usd':10,'includes_transport_probe':True,'charge_rule':'Maximum of reported service charge and all reported tokens at USD 10/million; retain unresolved request reservations.'}
result={'models':summaries,'spend':spend,'raw_sha256':rawpins,'frozen_inputs':pins,'scope':'Choice correctness only. Explanations require separately logged inspection. No population inference or causal model-size conclusion.',
 'posthoc_rule':'Added after observing hosted outputs wrapped in Markdown fences: strip exactly one complete outer ```json or ``` fence, then apply the identical JSON and choice rule. Strict scores unchanged. Not a preregistered primary endpoint.'}
(D/'analysis.json').write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding='utf-8')
with (D/'scores.csv').open('w',newline='',encoding='utf-8') as f:
 fields=['tag','id','case','carry','phrase','arm','choice','reference','correct','valid_json','support_coverage','flags','elapsed']
 w=csv.DictWriter(f,fieldnames=fields,extrasaction='ignore');w.writeheader();w.writerows(scored)
# Mask model and condition during supplementary prose inspection; lookup key stays separate.
queue=scored[:];random.Random(911).shuffle(queue)
(D/'explanation-review.txt').write_text('\n'.join(f'{i+1:03d} {r["case"]}/{r["carry"]} | {r["choice"]} | {r["reason"]}' for i,r in enumerate(queue)),encoding='utf-8')
(D/'explanation-review-key.json').write_text(json.dumps([{'review_id':i+1,'model':r['tag'],'id':r['id']} for i,r in enumerate(queue)],indent=2),encoding='utf-8')
print(json.dumps({k:{f:v for f,v in s.items() if f!='errors'} for k,s in summaries.items()},indent=2));print(json.dumps(spend))
