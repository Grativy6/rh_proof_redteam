"""Typeset the canonical CPX publication text as an editable Word document.

Native OMML is used for structured mathematical notation. No model calls.
"""
from pathlib import Path
import hashlib, json, re
from copy import deepcopy
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK, WD_TAB_ALIGNMENT
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT
from docx.enum.style import WD_STYLE_TYPE
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
PACKAGE=ROOT/'companion' if (ROOT/'companion').is_dir() else ROOT
SOURCE=PACKAGE/'manuscript/Context_Parallax_v1.0.md'
ASSETS=PACKAGE/'manuscript/assets';ASSETS.mkdir(exist_ok=True)
INK='252A3B';PURPLE='61517C';MUTED='626573';PALE='F3F1F7'
WIDTH=6.6
doc=Document();sec=doc.sections[0]
sec.page_width=Inches(8.5);sec.page_height=Inches(11)
sec.top_margin=Inches(.82);sec.bottom_margin=Inches(.74)
sec.left_margin=Inches(.95);sec.right_margin=Inches(.95)
sec.header_distance=Inches(.33);sec.footer_distance=Inches(.32)
sec.different_first_page_header_footer=True

def font_style(name,font,size,color=INK,bold=False):
    style=doc.styles[name] if name in doc.styles else doc.styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
    style.font.name=font;style.font.size=Pt(size);style.font.color.rgb=RGBColor.from_string(color);style.font.bold=bold
    prop=style.element.get_or_add_rPr();rf=prop.find(qn('w:rFonts'))
    if rf is None:rf=OxmlElement('w:rFonts');prop.append(rf)
    for a in list(rf.attrib):
        if a.endswith('Theme'):del rf.attrib[a]
    for a in ['ascii','hAnsi','eastAsia','cs']:rf.set(qn('w:'+a),font)
    pf=style.paragraph_format;pf.widow_control=True
    return style

normal=font_style('Normal','Cambria',11.2)
normal.paragraph_format.line_spacing=1.12;normal.paragraph_format.space_after=Pt(6.5)
title=font_style('Title','Georgia',38,'000000');title.paragraph_format.space_after=Pt(10)
subtitle=font_style('Subtitle','Cambria',20,'000000');subtitle.paragraph_format.space_after=Pt(16)
for name,size,font,color in [('Heading 1',17,'Georgia',INK),('Heading 2',12,'Segoe UI',PURPLE),('Heading 3',11,'Segoe UI',INK)]:
    st=font_style(name,font,size,color, name!='Heading 1');st.paragraph_format.keep_with_next=True
    st.paragraph_format.space_before=Pt(14 if name=='Heading 1' else 11);st.paragraph_format.space_after=Pt(7)
for name,size in [('Caption',9.6),('Reference',10.3),('FrontMeta',9.5),('ContentsLink',10.4),('BodySmall',10.8)]:
    st=font_style(name,'Segoe UI' if name in ['FrontMeta','ContentsLink','Caption'] else 'Cambria',size,MUTED if name=='Caption' else INK)
    st.paragraph_format.space_after=Pt(6);st.paragraph_format.line_spacing=1.08
doc.styles['Caption'].paragraph_format.keep_with_next=True
doc.styles['ContentsLink'].paragraph_format.space_after=Pt(5)
doc.styles['ContentsLink'].paragraph_format.line_spacing=1.05
doc.styles['FrontMeta'].paragraph_format.space_after=Pt(6)
for el in list(doc.styles.element.iter(qn('w:pBdr'))):el.getparent().remove(el)
for name in ['Header','Footer']:
    doc.styles[name].paragraph_format.tab_stops.clear_all()

# A narrow spectrum in the running furniture echoes the accepted key. Its
# colors carry no result, condition or semantic distinction in the article.
im=Image.new('RGB',(1800,12),'white');draw=ImageDraw.Draw(im)
for n,c in enumerate(['#927BC0','#628CB4','#70A392','#C3AA69','#C78391']):draw.rectangle((n*360,0,(n+1)*360,11),fill=c)
bar=ASSETS/'spectrum.png';im.save(bar)
for first in [False,True]:
    header=sec.first_page_header if first else sec.header
    hp=header.paragraphs[0];hp.paragraph_format.space_after=Pt(3)
    if not first:
        hp.paragraph_format.tab_stops.clear_all()
        hp.paragraph_format.tab_stops.add_tab_stop(Inches(WIDTH),WD_TAB_ALIGNMENT.RIGHT)
        r=hp.add_run('CONTEXT PARALLAX\tPANG AND HEARTHLINE');r.font.name='Segoe UI';r.font.size=Pt(8);r.font.color.rgb=RGBColor.from_string(MUTED)
        hp=header.add_paragraph();hp.paragraph_format.space_after=Pt(0)
    pic=hp.add_run().add_picture(str(bar),width=Inches(WIDTH),height=Inches(.035))
    pic._inline.docPr.set('descr','Decorative spectrum line')
    footer=sec.first_page_footer if first else sec.footer
    fp=footer.paragraphs[0];fp.paragraph_format.tab_stops.clear_all()
    fp.paragraph_format.tab_stops.add_tab_stop(Inches(WIDTH),WD_TAB_ALIGNMENT.RIGHT)
    r=fp.add_run('CPX  /  VERSION 1.0\t');r.font.name='Segoe UI';r.font.size=Pt(8);r.font.color.rgb=RGBColor.from_string(MUTED)
    field=OxmlElement('w:fldSimple');field.set(qn('w:instr'),'PAGE');fp._p.append(field)

bookmark_id=0
def bookmark(p,name):
    global bookmark_id
    bookmark_id+=1
    a=OxmlElement('w:bookmarkStart');a.set(qn('w:id'),str(bookmark_id));a.set(qn('w:name'),name)
    b=OxmlElement('w:bookmarkEnd');b.set(qn('w:id'),str(bookmark_id))
    p._p.insert(0,a);p._p.append(b)

def link(p,label,url=None,anchor=None,size=None):
    h=OxmlElement('w:hyperlink')
    if url:h.set(qn('r:id'),p.part.relate_to(url,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',is_external=True))
    else:h.set(qn('w:anchor'),anchor)
    r=OxmlElement('w:r');props=OxmlElement('w:rPr');color=OxmlElement('w:color');color.set(qn('w:val'),PURPLE);props.append(color)
    if url:
        u=OxmlElement('w:u');u.set(qn('w:val'),'single');props.append(u)
    if size:
        sz=OxmlElement('w:sz');sz.set(qn('w:val'),str(int(size*2)));props.append(sz)
    r.append(props);t=OxmlElement('w:t');t.text=label;t.set(qn('xml:space'),'preserve');r.append(t);h.append(r);p._p.append(h)

# Explicit elementary OMML constructors. Fractions and subscripts remain
# native and editable, rather than slash/text approximations in the DOCX.
def mr(text,plain=False):
    r=OxmlElement('m:r')
    if plain:
        pr=OxmlElement('m:rPr');nor=OxmlElement('m:nor');pr.append(nor);r.append(pr)
    rp=OxmlElement('w:rPr');rf=OxmlElement('w:rFonts');rf.set(qn('w:ascii'),'Cambria Math');rf.set(qn('w:hAnsi'),'Cambria Math');rp.append(rf);r.append(rp)
    t=OxmlElement('m:t');t.text=text;t.set(qn('xml:space'),'preserve');r.append(t);return r
def expr(text):
    pieces=[]
    for part in re.split(r'(H₂|u₀)',text):
        if part in ('H₂','u₀'):
            x=OxmlElement('m:sSub');e=OxmlElement('m:e');e.append(mr(part[0]));sub=OxmlElement('m:sub');sub.append(mr('2' if part[0]=='H' else '0'));x.append(e);x.append(sub);pieces.append(x)
        elif part:pieces.append(mr(part))
    return pieces
def fraction(num,den):
    f=OxmlElement('m:f');a=OxmlElement('m:num');b=OxmlElement('m:den')
    for e in expr(num):a.append(e)
    for e in expr(den):b.append(e)
    f.append(a);f.append(b);return f
def simple(text):return expr(text)

MATH={
    'q(x) = f(P(x))':lambda:simple('q(x) = f(P(x))'),
    'q(T(x)) = q(x)':lambda:simple('q(T(x)) = q(x)'),
    'a(x) = d(c(x))':lambda:simple('a(x) = d(c(x))'),
    'c(x) = c(y)':lambda:simple('c(x) = c(y)'),
    'a(x) = a(y)':lambda:simple('a(x) = a(y)'),
    '12 × 3 × 2 × 2 = 144':lambda:simple('12 × 3 × 2 × 2 = 144'),
    'q = k/20':lambda:expr('q = ')+[fraction('k','20')],
    '1 − H₂(q)':lambda:expr('1 − H₂(q)'),
    'pB − (1 − p)L − c ≥ u₀':lambda:expr('pB − (1 − p)L − c ≥ u₀'),
    'p ≥ (L + c + u₀)/(B + L)':lambda:expr('p ≥ ')+[fraction('L + c + u₀','B + L')],
    'B + L > 0':lambda:expr('B + L > 0'),
    'C = U':lambda:expr('C = U'), 'Y = C':lambda:expr('Y = C'),
    'Y = U':lambda:expr('Y = U'), 'Y = 0':lambda:expr('Y = 0'),
    'c = 1':lambda:expr('c = 1'), 'λ = 1':lambda:expr('λ = 1'),
}
math_hits=[]
math_pattern=re.compile('('+'|'.join(re.escape(s) for s in sorted(MATH,key=len,reverse=True))+')')
def text_with_math(p,text,bold=False,italic=False):
    for token in math_pattern.split(text):
        if not token:continue
        if token in MATH:
            m=OxmlElement('m:oMath')
            for el in MATH[token]():m.append(el)
            p._p.append(m);math_hits.append(token)
        else:
            # This Windows Cambria export maps the acute accent in this name
            # incorrectly in PDF ToUnicode. Georgia keeps both its appearance
            # and searchable text correct; the canonical name is unchanged.
            for fragment in re.split(r'(Daumé)',token):
                if not fragment:continue
                r=p.add_run(fragment);r.bold=bold;r.italic=italic
                if fragment=='Daumé':r.font.name='Georgia'

token_re=re.compile(r'(\*\*.*?\*\*|`[^`]+`|\[[^\]]+\]\(https?://[^)]+\)|\*[^*]+\*|\[(?:[A-Z]+\d*|[A-Z]+\d*[–-][A-Z]+\d*)(?:,\s*[A-Z]+\d*)*\])')
def inline(p,text):
    for token in token_re.split(text):
        if not token:continue
        if token.startswith('**'):text_with_math(p,token[2:-2],bold=True)
        elif token.startswith('`') and token.endswith('`'):
            r=p.add_run(token[1:-1]);r.font.name='Consolas';r.font.size=Pt(9)
        elif token.startswith('*') and token.endswith('*'):text_with_math(p,token[1:-1],italic=True)
        elif re.match(r'\[[^\]]+\]\(',token):
            label,url=re.match(r'\[([^\]]+)\]\((.+)\)',token).groups();link(p,label,url=url)
        elif token.startswith('['):
            ref=re.match(r'\[([A-Z]+\d*)',token).group(1);link(p,token,anchor='ref_'+ref)
        else:text_with_math(p,token)

text=SOURCE.read_text(encoding='utf-8')
headings=re.findall(r'^## (.+)$',text,re.M)[1:]
anchors={h:'section_'+str(i+1) for i,h in enumerate(headings)}
lines=text.splitlines();i=0;first_sub=True;pending=False;in_refs=False;in_appendix=False
paragraph_inventory=[]
while i<len(lines):
    line=lines[i].strip()
    if not line:i+=1;continue
    if line=='<!-- CONTENTS -->':
        p=doc.add_paragraph('Contents','Heading 2')
        for h in headings:
            p=doc.add_paragraph(style='ContentsLink');link(p,h,anchor=anchors[h],size=10.4)
        i+=1;continue
    if line=='<!-- PAGEBREAK -->':pending=True;i+=1;continue
    if line.startswith('# '):
        p=doc.add_paragraph(line[2:],'Title');i+=1;continue
    if line.startswith('## '):
        h=line[3:]
        if first_sub:
            p=doc.add_paragraph(h,'Subtitle');first_sub=False
        else:
            in_refs=h=='References and source identities';in_appendix=h.startswith('Appendix') or in_appendix
            p=doc.add_paragraph(h,'Heading 1');bookmark(p,anchors[h])
            p.paragraph_format.page_break_before=pending or h.startswith(('Appendix B','Appendix C','Appendix D')) or in_refs
        pending=False;i+=1;continue
    if line.startswith(('### ','#### ')):
        level=2 if line.startswith('### ') else 3;h=line[level+2:]
        p=doc.add_paragraph(h,'Heading '+str(level))
        if h in ['About this edition','Formal coverage and its limits']:p.paragraph_format.page_break_before=True
        i+=1;continue
    if line.startswith('|'):
        rows=[]
        while i<len(lines) and lines[i].strip().startswith('|'):
            cells=[s.strip() for s in lines[i].strip().strip('|').split('|')]
            if not all(re.fullmatch(r':?-+:?',s.replace(' ','')) for s in cells):rows.append(cells)
            i+=1
        cols=len(rows[0]);table=doc.add_table(rows=0,cols=cols);table.autofit=False
        widths=[2.2]*3 if cols==3 else [2.1,1.5,1.5,1.5]
        if rows[0][0]=='Claim family':widths=[1.66,.88,4.06]
        elif rows[0][0]=='Candidate return':widths=[2.60,1.70,2.30]
        elif rows[0][0]=='Case':widths=[1.35,2.05,3.20]
        elif rows[0][0]=='Intended message':widths=[2.40,2.10,2.10]
        elif rows[0][0]=='Observations':widths=[1.05,2.40,1.35,1.80]
        elif rows[0][0]=='Carrier':widths=[1.65,2.5,2.45]
        elif rows[0][0]=='Place':widths=[1.35,2.65,2.6]
        for col,w in zip(table.columns,widths):col.width=Inches(w)
        for ri,row in enumerate(rows):
            cells=table.add_row().cells
            for ci,(c,w,content) in enumerate(zip(cells,widths,row)):
                c.width=Inches(w);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
                p=c.paragraphs[0];inline(p,content);p.paragraph_format.space_before=Pt(2);p.paragraph_format.space_after=Pt(2)
                p.paragraph_format.line_spacing=1.04
                p.paragraph_format.keep_with_next=ri<len(rows)-1
                if (rows[0][0]=='Claim family' and ci==1) or (rows[0][0] in ['Observations','Intended message']):p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                for r in p.runs:
                    r.font.name='Segoe UI';r.font.size=Pt(9.3);r.bold=ri==0
                    if ri==0:r.font.color.rgb=RGBColor(255,255,255)
                # Ensure all runs, including hyperlink runs, inherit header contrast.
                if ri==0:
                    for r in p._p.iter(qn('w:r')):
                        rp=r.find(qn('w:rPr'))
                        if rp is None:rp=OxmlElement('w:rPr');r.insert(0,rp)
                        color=rp.find(qn('w:color'))
                        if color is None:color=OxmlElement('w:color');rp.append(color)
                        color.set(qn('w:val'),'FFFFFF')
                pr=c._tc.get_or_add_tcPr();mar=OxmlElement('w:tcMar')
                for edge in ['top','left','bottom','right']:
                    el=OxmlElement('w:'+edge);el.set(qn('w:w'),'100');el.set(qn('w:type'),'dxa');mar.append(el)
                pr.append(mar);shade=OxmlElement('w:shd');shade.set(qn('w:fill'),INK if ri==0 else (PALE if ri%2 else 'FFFFFF'));pr.append(shade)
            trpr=table.rows[-1]._tr.get_or_add_trPr();trpr.append(OxmlElement('w:cantSplit'))
            if ri==0:trpr.append(OxmlElement('w:tblHeader'))
        borders=OxmlElement('w:tblBorders')
        for edge in ['top','left','bottom','right','insideH','insideV']:
            e=OxmlElement('w:'+edge);e.set(qn('w:val'),'single');e.set(qn('w:sz'),'4');e.set(qn('w:color'),'D9D9D9');borders.append(e)
        table._tbl.tblPr.append(borders)
        p=doc.add_paragraph();p.paragraph_format.space_after=Pt(2);p.paragraph_format.space_before=Pt(0);p.paragraph_format.line_spacing=Pt(2)
        continue
    pieces=[line];i+=1
    while i<len(lines) and lines[i].strip() and not lines[i].startswith(('#','|','<!--')):
        pieces.append(lines[i].strip());i+=1
    joined=' '.join(pieces)
    style='Caption' if joined.startswith('*Table ') else ('Reference' if in_refs else 'Normal')
    if joined.startswith(('**Version','**DOI reserved','**CC BY','**Christopher','**Hearthline')):style='FrontMeta'
    p=doc.add_paragraph(style=style);inline(p,joined)
    if joined.startswith('Adapted from v0.5'):
        p.paragraph_format.keep_with_next=True
    if in_refs:
        m=re.match(r'\*\*([A-Z]+\d*)\.\*\*',joined)
        if m:bookmark(p,'ref_'+m.group(1))
    paragraph_inventory.append({'text':joined,'style':style})

doc.core_properties.title='Context Parallax: Changing the view without losing the question'
doc.core_properties.subject='Comparison contract, recognition pilot and scoped formal companion'
doc.core_properties.author='Christopher Daniel Pang; Hearthline (named AI collaborator)'
doc.core_properties.keywords='Context Parallax, CPX, framing, interpretation, provenance, Lean, continuity'
doc.core_properties.comments='Version 1.0. Original release material CC BY 4.0. DOI reserved: 10.5281/zenodo.23306102.'
doc.settings.element.append(OxmlElement('w:updateFields'))
doc.settings.element[-1].set(qn('w:val'),'true')
target=SOURCE.with_suffix('.docx');doc.save(target)
report={'source_sha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'docx_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),
        'native_math_occurrences':len(math_hits),'native_math_source_fragments':math_hits,'contents_links':len(headings),
        'math_linearizations':{source:''.join(t.text or '' for node in make() for t in node.iter(qn('m:t'))) for source,make in MATH.items()},
        'table_count':len(doc.tables),'styles':'Cambria body, Georgia title, Segoe UI navigation; color is decorative only'}
(ROOT/'audit/TYPESETTING.json').write_text(json.dumps(report,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in report.items() if k not in ['native_math_source_fragments','math_linearizations']}))
