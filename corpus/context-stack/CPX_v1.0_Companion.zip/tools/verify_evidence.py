"""Offline evidence replay. No model calls, network or paid resources."""
from pathlib import Path
from datetime import datetime, timezone
import argparse, collections, csv, hashlib, json, shutil, subprocess, sys, platform
from portable_replay import compare_csv, compare_json, compare_prompt_tree, INFORMATION_COLUMNS

ROOT = Path(__file__).resolve().parents[1]
def load(p): return json.loads(p.read_text(encoding='utf-8-sig'))
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def records(p): return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines()]

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--check-originals',action='store_true');parser.add_argument('--report',type=Path,default=ROOT/'audit/EVIDENCE_VERIFICATION.json')
    args=parser.parse_args();checks=[]
    def ck(name, passed, detail=None):
        checks.append(dict(check=name,passed=bool(passed),detail=detail))
    work=ROOT/'tmp'/('offline-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f'))
    work.mkdir(parents=True,exist_ok=False)
    for source,dest in [('inherited-v0.5/evidence/foundation/toys_v2.py','foundation/scripts/toys_v2.py'),
        ('inherited-v0.5/evidence/foundation/config.json','foundation/experiments/config.json'),
        ('inherited-v0.5/evidence/witness/experiment.py','witness/experiment.py'),
        ('inherited-v0.5/evidence/witness/config.json','witness/config.json')]:
        target=work/dest;target.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(ROOT/source,target)
    jobs=[('foundation',[sys.executable,str(work/'foundation/scripts/toys_v2.py'),'--output','result']),
          ('witness',[sys.executable,str(work/'witness/experiment.py'),'--output',str(work/'witness/result')]),
          ('records',[sys.executable,str(ROOT/'inherited-v0.5/method/run_checks.py'),'--out',str(work/'records')])]
    for name,cmd in jobs:
        run=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=120)
        (work/(name+'-stdout.txt')).write_text(run.stdout,encoding='utf-8')
        (work/(name+'-stderr.txt')).write_text(run.stderr,encoding='utf-8')
        ck(name+' replay exit',run.returncode==0,run.returncode)
    for name,old in [('foundation','inherited-v0.5/evidence/foundation/run-002'),('witness','inherited-v0.5/evidence/witness/run-001')]:
        for p in (work/name/'result').iterdir():
            original=ROOT/old/p.name
            if p.suffix == '.csv':
                detail=compare_csv(original,p,INFORMATION_COLUMNS if name=='foundation' and p.name=='binary.csv' else ())
                ck(name+'/'+p.name+' matches retained result',detail['passed'],detail)
            elif p.suffix == '.json':
                ck(name+'/'+p.name+' matches retained result',original.exists() and compare_json(load(original),load(p)))
            else:
                ck(name+'/'+p.name+' matches retained result',original.exists() and sha(p)==sha(original))
    # Regenerate old prompts in isolation. Historical CRLF bytes stay untouched.
    maintenance=work/'maintenance/studies';maintenance.mkdir(parents=True)
    shutil.copy2(ROOT/'inherited-v0.5/studies/prepare_maintain.py',maintenance/'prepare_maintain.py')
    (maintenance/'maintain').mkdir()
    shutil.copy2(ROOT/'inherited-v0.5/studies/maintain/fixtures.json',maintenance/'maintain/fixtures.json')
    run=subprocess.run([sys.executable,str(maintenance/'prepare_maintain.py')],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=120)
    (work/'maintenance-stdout.txt').write_text(run.stdout,encoding='utf-8')
    (work/'maintenance-stderr.txt').write_text(run.stderr,encoding='utf-8')
    ck('Historical pilot preparation exit',run.returncode==0)
    ck('Historical pilot own-byte manifests and parsed records match',compare_prompt_tree(ROOT/'inherited-v0.5/studies/maintain',maintenance/'maintain'))
    review=work/'review';(review/'tools').mkdir(parents=True)
    shutil.copy2(ROOT/'tools/review_computations.py',review/'tools/review_computations.py')
    chain=review/'inherited-v0.5/evidence/foundation/run-002/chains.csv';chain.parent.mkdir(parents=True)
    shutil.copy2(ROOT/'inherited-v0.5/evidence/foundation/run-002/chains.csv',chain)
    rerun=subprocess.run([sys.executable,str(review/'tools/review_computations.py')],cwd=ROOT,capture_output=True,text=True,encoding='utf-8',timeout=120)
    (work/'review-stdout.txt').write_text(rerun.stdout,encoding='utf-8');(work/'review-stderr.txt').write_text(rerun.stderr,encoding='utf-8')
    ck('New review computations replay',rerun.returncode==0)
    for name in ['channel-counterexamples.json','paired-chains.json']:
        a,b=load(review/'evidence/review'/name),load(ROOT/'evidence/review'/name)
        a.pop('time',None);b.pop('time',None)
        allowed={('information','bits_symmetric'),('information','bits_asymmetric')} if name=='channel-counterexamples.json' else set()
        ck(name+' replay matches substantive values',compare_json(a,b,allowed))
    rec=load(work/'records/summary.json')
    ck('93 finite checks and 64 comparator agreements',rec['passed']==93 and rec['ordinary_baseline_agreements']==64)
    # The archived record-check script's NOT_RUN field describes that suite only.
    frozen=ROOT/'studies/maintain02';pins=load(frozen/'FREEZE.json')['sha256']
    ck('Frozen scientific inputs unchanged',all(sha(frozen/p)==h for p,h in pins.items()))
    prompts=records(frozen/'prompts.jsonl');byid={p['id']:p for p in prompts};pairs=collections.defaultdict(dict)
    for p in prompts:pairs[(p['case'],p['carry'],p['phrase'])][p['arm']]=p
    match=True
    for pair in pairs.values():
        if set(pair)!={'plain','frame'}:match=False;continue
        a,b=pair['plain'],pair['frame'];x,y=json.loads(a['input']),json.loads(b['input'])
        x.pop('guidance');y.pop('guidance')
        match &= x==y and a['system']==b['system'] and a['reference_choice']==b['reference_choice']
    ck('72 matched pairs differ only in declared guidance',len(pairs)==72 and match)
    ck('Experimental metadata stays outside all model inputs',all(not ({'arm','case','phrase','reference_choice','reference_text','option_flags','support_coverage','id'} & set(json.loads(p['input']))) for p in prompts))
    scored=load(ROOT/'evidence/model/scored.json');analysis=load(ROOT/'evidence/model/analysis.json')
    outcome={}
    for tag,expected in [('qwen4b',140),('qwen9b',144),('qwen32b',0)]:
        raw=records(ROOT/f'evidence/model/{tag}.jsonl');rows=[r for r in scored if r['tag']==tag]
        ck(tag+' complete 144 request identities',len(raw)==len(rows)==144 and {r['id'] for r in raw}==set(byid))
        ck(tag+' no transport retry or failure',all(e['final'] and e['attempt']==0 and not e.get('error') for e in raw))
        matches=True;caps=[];endings=[]
        for event in raw:
            p=byid[event['id']];r=event['request']
            if tag=='qwen32b':
                matches &= r['messages']==[{'role':'system','content':p['system']},{'role':'user','content':p['input']}]
                caps.append(event['response']['usage']['completion_tokens'])
                endings.append(event['response']['choices'][0]['finish_reason'])
            else:
                matches &= r['input']==p['input'] and r['system_prompt']==p['system']
                caps.append(event['response']['stats']['total_output_tokens'])
        ck(tag+' transmitted frozen material',matches)
        ck(tag+' below output cap and no reported length stop',max(caps)<256 and all(x=='stop' for x in endings),{'max_output_tokens':max(caps),'finish_reasons':sorted(set(endings)) or 'Native endpoint does not report finish reason'})
        ck(tag+' strict score matches',sum(r['correct'] for r in rows)==expected)
        pairchoices=collections.defaultdict(dict)
        for r in rows:pairchoices[(r['case'],r['carry'],r['phrase'])][r['arm']]=r['posthoc_choice']
        equal=sum(p['plain']==p['frame'] for p in pairchoices.values())
        ck(tag+' 72 matched posthoc choices identical',equal==72)
        ck(tag+' raw hash matches analysis',sha(ROOT/f'evidence/model/{tag}.jsonl')==analysis['raw_sha256'][f'{tag}.jsonl'])
        outcome[tag]={'strict_correct':sum(r['correct'] for r in rows),'posthoc_correct':sum(r['posthoc_correct'] for r in rows),'pairs_same_choice':equal}
    ledger={r['id']:r for r in records(ROOT/'evidence/model/runpod-ledger.jsonl')}
    ck('All 145 paid requests settled',len(ledger)==145 and all(r['status']=='RETURNED' for r in ledger.values()))
    ck('Cost 0.54451 below total 10 ceiling',abs(sum(r['accounted_usd'] for r in ledger.values())-.54451)<1e-10 and analysis['spend']['unresolved_reserved_usd']==0)
    if args.check_originals:
        orig=ROOT.parent/'v0.6-key';pin=load(ROOT/'audit/KEY_SOURCE_IDENTITIES.json')
        failures=[r['path'] for r in pin['inputs'] if not (orig/r['path']).exists() or sha(orig/r['path'])!=r['sha256']]
        ck('167 original key inputs preserved',len(pin['inputs'])==167 and not failures,failures)
    report={'status':'PASS' if all(c['passed'] for c in checks) else 'FAIL','checked_utc':datetime.now(timezone.utc).isoformat(),
       'runtime':{'python':platform.python_version(),'platform':platform.platform()},
       'comparison_policy':'Archive hashes remain exact. Replay JSON is parsed; manifests validate their own prompt bytes. CSV values remain exact except the two declared log-derived information columns, absolute tolerance 1e-12 bits, zero relative tolerance, nonfinite rejected. The new channel JSON uses the same tolerance only for its two information fields. No other numerical relaxation.',
       'checks':checks,'results':outcome,'replay_dir':str(work.relative_to(ROOT)),
       'scope':'Offline artifact and finite replay; no model reruns, Lean proof or independent scientific review.'}
    args.report.write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps({'status':report['status'],'checks':len(checks),'failed':[c for c in checks if not c['passed']],'outcomes':outcome}))
    return 0 if report['status']=='PASS' else 1
if __name__=='__main__':raise SystemExit(main())
