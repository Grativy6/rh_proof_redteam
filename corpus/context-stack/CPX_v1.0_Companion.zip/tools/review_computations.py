"""Independent finite constructions and paired summaries requested by review."""
from pathlib import Path
from fractions import Fraction as F
from itertools import product
import csv, hashlib, json, math, random, statistics, datetime
ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/'evidence/review';OUT.mkdir(parents=True,exist_ok=True)
def accuracy(prior,K):return sum(prior[x]*K[x][x] for x in range(2))
def info(prior,K):
 joint=[[prior[x]*K[x][y] for y in range(2)] for x in range(2)]
 marg=[sum(joint[x][y] for x in range(2)) for y in range(2)]
 return sum(float(joint[x][y])*math.log2(float(joint[x][y]/(prior[x]*marg[y]))) for x in range(2) for y in range(2) if joint[x][y])
sym=[[F(3,4),F(1,4)],[F(1,4),F(3,4)]]
asym=[[F(1,2),F(1,2)],[F(0),F(1)]]
unif=[F(1,2),F(1,2)]; prior=[F(3,4),F(1,4)]
assert accuracy(unif,sym)==accuracy(unif,asym)==F(3,4)
i_sym,i_asym=info(unif,sym),info(unif,asym)
assert abs(i_sym-0.18872187554086717)<1e-12
assert abs(i_asym-0.31127812445913283)<1e-12
def utility(fault,revise):return F(19,10)-int(revise)-3*int(not(revise and fault))
def decision(K):
 blind=[sum(prior[x]*utility(x,a) for x in range(2)) for a in [0,1]]
 policies=[{'policy':p,'value':sum(prior[x]*K[x][y]*utility(x,p[y]) for x in range(2) for y in range(2))} for p in product([0,1],repeat=2)]
 return {'without':max(blind),'with':max(r['value'] for r in policies),'gross_value':max(r['value'] for r in policies)-max(blind),'policies':policies}
constant=[[F(1),F(0)],[F(1),F(0)]]
assert accuracy(prior,sym)==accuracy(prior,constant)==F(3,4)
ds,dc=decision(sym),decision(constant)
assert ds['gross_value']==F(3,16) and dc['gross_value']==0
# Exhaustive rational controls for optional-information non-decrease.
checks=0
for pn,a,b in product(range(5),repeat=3):
 p=[F(4-pn,4),F(pn,4)];K=[[F(a,4),F(4-a,4)],[F(b,4),F(4-b,4)]]
 blind=max(sum(p[x]*utility(x,act) for x in range(2)) for act in [0,1])
 informed=max(sum(p[x]*K[x][y]*utility(x,policy[y]) for x in range(2) for y in range(2)) for policy in product([0,1],repeat=2))
 assert informed>=blind;checks+=1
results={'attribution':'Counterexamples proposed in Chat Hearthline v0.5 manuscript review; independently reimplemented here, not a rerun of a supplied reviewer script.',
 'matrix_convention':'Rows true binary state 0,1; columns observed signal 0,1. q is diagonal probability in symmetric channel.',
 'information':{'prior':unif,'symmetric':sym,'asymmetric':asym,'accuracy':F(3,4),'bits_symmetric':i_sym,'bits_asymmetric':i_asym,'log_values':'floating point approximations; exact rational joint probabilities'},
 'decision':{'prior_external_fault':prior,'symmetric':ds,'constant_external':dc,'accuracy_both':F(3,4),'revision_cost':1,'harm_weight':1,'harm':3,'inspection_cost':0},
 'controls':{'rational_optional_information_instances':checks},'time':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'channel-counterexamples.json').write_text(json.dumps(results,indent=2,default=str),encoding='utf-8')
source=ROOT/'inherited-v0.5/evidence/foundation/run-002/chains.csv'
rows=list(csv.DictReader(source.open(newline='',encoding='utf-8-sig')))
end={(r['learner'],r['arm'],int(r['draws']),int(r['seed'])):r for r in rows if int(r['generation'])==40}
assert len(rows)==38400 and len(end)==960
def percentile(a,p):
 a=sorted(a);v=(len(a)-1)*p; lo=int(v);hi=min(lo+1,len(a)-1)
 return a[lo]+(a[hi]-a[lo])*(v-lo)
def summary(d,seed):
 rng=random.Random(seed)
 means=[statistics.mean(rng.choices(d,k=len(d))) for _ in range(3000)]
 return {'n_paired_chains':len(d),'mean':statistics.mean(d),'median':statistics.median(d),'q25':percentile(d,.25),'q75':percentile(d,.75),'min':min(d),'max':max(d),
 'positive':sum(x>1e-10 for x in d),'negative':sum(x< -1e-10 for x in d),'ties':sum(abs(x)<=1e-10 for x in d),
 'bootstrap_95_percentile':[percentile(means,.025),percentile(means,.975)]}
paired=[]
for learner,draws,comp,metric in product(['pooled','bijective'],[2,4,8,16],['none','repeat'],['distinctions','original_match']):
 d=[float(end[(learner,'targeted',draws,s)][metric])-float(end[(learner,comp,draws,s)][metric]) for s in range(40)]
 paired.append({'learner':learner,'draws':draws,'contrast':'targeted - '+comp,'metric':metric,**summary(d,1011+len(paired))})
# Read real arm names from retained evidence; abort on any mismatch rather than invent rows.
totals={}
for r in rows:
 key=(r['learner'],r['arm'],int(r['draws']),int(r['seed']))
 entry=totals.setdefault(key,[0.,0.]);entry[0]+=float(r['optimal_accuracy']);entry[1]+=float(r['queries'])
net=[]
for s in range(40):
 t=totals[('pooled','targeted',8,s)];n=totals[('pooled','none',8,s)]
 net.append((t[0]-.2*t[1]-n[0])/40)
cost_summary=summary(net,202611)
assert cost_summary['negative']==21
obj={'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'method':'Within-condition paired seed differences at generation 40. Descriptive percentile bootstrap of 40 paired differences, 3000 resamples, seed 1011+row index; no multiplicity adjustment or empirical population claim. Cost uses whole-chain mean, seed 202611.',
 'generation_rows':len(rows),'independent_simulated_chains':len(end),'contrasts':paired,'pooled8_cost02':cost_summary}
(OUT/'paired-chains.json').write_text(json.dumps(obj,indent=2),encoding='utf-8')
print(json.dumps({'information_bits':[i_sym,i_asym],'gross_value':[str(ds['gross_value']),str(dc['gross_value'])],'rational_controls':checks,'paired_contrasts':len(paired),'cost':cost_summary}))
