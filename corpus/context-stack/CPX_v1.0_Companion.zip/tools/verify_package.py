"""Verify the portable CPX v1.0 companion with Python's standard library.

The default executes only local finite computations and re-scores retained
responses. It never calls a model, reads credentials or initiates Lean.
"""
from pathlib import Path, PurePosixPath
from datetime import datetime, timezone
import argparse, hashlib, json, os, platform, shutil, subprocess, sys

ROOT=Path(__file__).resolve().parents[1]
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def load(path): return json.loads(Path(path).read_text(encoding='utf-8-sig'))
def payload():
    return {p.relative_to(ROOT).as_posix():p for p in ROOT.rglob('*') if p.is_file()
            and 'tmp' not in p.relative_to(ROOT).parts and '__pycache__' not in p.relative_to(ROOT).parts
            and p.relative_to(ROOT).as_posix()!='MANIFEST.json'}

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--integrity-only',action='store_true',help='Skip finite replay and re-scoring')
    args=parser.parse_args();checks=[]
    def check(name,okay,detail=None):checks.append({'check':name,'passed':bool(okay),'detail':detail})
    manifest=load(ROOT/'MANIFEST.json');files=payload();listed=[r['path'] for r in manifest['files']]
    check('Complete unique inventory',len(listed)==len(set(listed)) and set(listed)==set(files))
    failures=[]
    for row in manifest['files']:
        rel=PurePosixPath(row['path'])
        if rel.is_absolute() or '..' in rel.parts:raise ValueError('Unsafe manifest path')
        p=ROOT/row['path']
        if not p.is_file() or p.stat().st_size!=row['bytes'] or sha(p)!=row['sha256']:failures.append(row['path'])
    check('Payload hashes and sizes',not failures,failures)
    cross=load(ROOT/'audit/CLAIM_CROSSWALK.json')
    new=ROOT/cross['v10_source'];old=ROOT/cross['v06_source']
    check('Both manuscript identities',sha(new)==cross['v10_sha256'] and sha(old)==cross['v06_sha256'])
    a,b=old.read_text(encoding='utf-8'),new.read_text(encoding='utf-8')
    check('Five controlling passages remain verbatim',len(cross['passages'])==5 and all(
        r['verbatim'] in a and r['verbatim'] in b and hashlib.sha256(r['verbatim'].encode()).hexdigest()==r['passage_sha256']
        for r in cross['passages']))
    result=load(ROOT/'formal/audit/RESULT.json')
    sourcepins={**result['proof_source_sha256'],**result['report_source_sha256']}
    check('Nine checked proof and report source files unchanged',len(sourcepins)==9 and all(sha(ROOT/'formal'/p)==h for p,h in sourcepins.items()))
    lock=load(ROOT/'formal/PORTABLE_SOURCE_LOCK.json')
    check('Portable lock resolves all three original inputs',len(lock['inputs'])==3 and all(sha((ROOT/'formal'/r['path']).resolve())==r['sha256'] for r in lock['inputs']))
    run_dir=ROOT/'tmp'/('verification-'+datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%f'))
    run_dir.mkdir(parents=True,exist_ok=False)
    commands=[]
    env=os.environ.copy();env['PYTHONNOUSERSITE']='1';env['PYTHONDONTWRITEBYTECODE']='1'
    def run(label,argv,timeout):
        p=subprocess.run(argv,cwd=ROOT,env=env,capture_output=True,text=True,encoding='utf-8',timeout=timeout)
        for stream,data in [('stdout',p.stdout),('stderr',p.stderr)]:
            (run_dir/(label+'.'+stream+'.txt')).write_text(data,encoding='utf-8')
        commands.append({'label':label,'argv':list(map(str,argv)),'exit_code':p.returncode,
                         'stdout_sha256':sha(run_dir/(label+'.stdout.txt')),'stderr_sha256':sha(run_dir/(label+'.stderr.txt'))})
        check(label+' exited successfully',p.returncode==0)
        return p
    if all(r['passed'] for r in checks) and not args.integrity_only:
        run('portability-guards',[sys.executable,'-s',str(ROOT/'tools/test_portable_replay.py')],30)
        run('finite-evidence',[sys.executable,'-s',str(ROOT/'tools/verify_evidence.py'),'--report',str(run_dir/'FINITE_REPLAY.json')],240)
        score=run_dir/'rescore'
        for rel in ['tools/analyze_model_study.py','studies/maintain02/FREEZE.json','studies/maintain02/contract.json',
                    'studies/maintain02/prompts.jsonl','studies/maintain02/pair_checks.json',
                    'evidence/model/qwen4b.jsonl','evidence/model/qwen9b.jsonl','evidence/model/qwen32b.jsonl','evidence/model/runpod-ledger.jsonl']:
            p=ROOT/rel
            if p.is_file():
                target=score/rel;target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,target)
        # Copy every frozen input named by the original contract, without
        # changing its bytes or guessing which files a future freeze needs.
        for rel in load(ROOT/'studies/maintain02/FREEZE.json')['sha256']:
            source=ROOT/'studies/maintain02'/rel;target=score/'studies/maintain02'/rel
            target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,target)
        run('retained-response-scoring',[sys.executable,'-s',str(score/'tools/analyze_model_study.py')],45)
        for name in ['scored.json','analysis.json','explanation-review-key.json']:
            check(name+' re-scored values identical',load(score/'evidence/model'/name)==load(ROOT/'evidence/model'/name))
        check('Explanation review unchanged',(score/'evidence/model/explanation-review.txt').read_text(encoding='utf-8')==(ROOT/'evidence/model/explanation-review.txt').read_text(encoding='utf-8'))
        finite=load(run_dir/'FINITE_REPLAY.json')
        check('All retained finite assertions reproduced',finite['status']=='PASS',{'checks':len(finite['checks']),'results':finite['results']})
    # Replays must not mutate frozen evidence or the manuscript.
    check('Payload unchanged during verification',all(p.is_file() and sha(p)==next(r['sha256'] for r in manifest['files'] if r['path']==name) for name,p in files.items()))
    report={'status':'PASS' if all(r['passed'] for r in checks) else 'FAIL','time_utc':datetime.now(timezone.utc).isoformat(),
            'python':platform.python_version(),'platform':platform.platform(),'manifest_files':len(listed),
            'checks':checks,'commands':commands,'integrity_only':args.integrity_only,'model_calls':0,'network_calls':0,'lean_processes':0,
            'scope':'Exact package and proof-source identity; unchanged source crosswalk; bounded finite replay with inherited tolerances; re-scoring retained outputs. No independent scientific replication or new model experiment.'}
    out=run_dir/'PACKAGE_VERIFICATION.json';out.write_text(json.dumps(report,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({'status':report['status'],'checks':len(checks),'failed':[r for r in checks if not r['passed']],'report':str(out)}))
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
