"""Typed replay comparisons; archive integrity always remains byte-exact."""
from pathlib import Path, PurePosixPath
import csv, hashlib, json, math

LOG_TOLERANCE_BITS = 1e-12
INFORMATION_COLUMNS = frozenset({'state_signal_bits', 'state_action_bits'})

def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))

def finite_close(a, b):
    try:
        x, y = float(a), float(b)
    except (TypeError, ValueError):
        return False
    return math.isfinite(x) and math.isfinite(y) and abs(x-y) <= LOG_TOLERANCE_BITS

def compare_csv(original, replay, information_columns=()):
    """Exact headers, row order and other cells; only named log fields tolerate drift."""
    with Path(original).open(newline='', encoding='utf-8-sig') as f:
        a = list(csv.reader(f))
    with Path(replay).open(newline='', encoding='utf-8-sig') as f:
        b = list(csv.reader(f))
    errors, changed = [], []
    if not a or not b or a[0] != b[0] or len(a) != len(b):
        return {'passed': False, 'errors': ['Headers or row count differ'], 'log_differences': []}
    if not set(information_columns) <= set(a[0]):
        return {'passed': False, 'errors': ['Missing declared information column'], 'log_differences': []}
    for i, (x, y) in enumerate(zip(a[1:], b[1:]), start=2):
        if len(x) != len(a[0]) or len(y) != len(a[0]):
            errors.append({'row': i, 'reason': 'Invalid column count'})
            continue
        for col, v, w in zip(a[0], x, y):
            if col in information_columns:
                if not finite_close(v, w):
                    errors.append({'row': i, 'column': col, 'original': v, 'replay': w})
                elif v != w:
                    changed.append({'row': i, 'column': col, 'original': v, 'replay': w,
                                    'absolute_difference_bits': abs(float(v)-float(w))})
            elif v != w:
                errors.append({'row': i, 'column': col, 'original': v, 'replay': w})
    return {'passed': not errors, 'errors': errors, 'log_differences': changed,
            'rows': len(a)-1, 'absolute_tolerance_bits': LOG_TOLERANCE_BITS if information_columns else 0,
            'relative_tolerance': 0}

def compare_json(a, b, approximate_paths=(), path=()):
    """Parsed JSON equality; numerical tolerance requires an exact explicit path."""
    if path in approximate_paths:
        return isinstance(a, (int, float)) and not isinstance(a, bool) and isinstance(b, (int, float)) and not isinstance(b, bool) and finite_close(a, b)
    if type(a) is not type(b):
        return False
    if isinstance(a, dict):
        return a.keys() == b.keys() and all(compare_json(v, b[k], approximate_paths, path+(k,)) for k,v in a.items())
    if isinstance(a, list):
        return len(a) == len(b) and all(compare_json(v, b[i], approximate_paths, path+(i,)) for i,v in enumerate(a))
    if isinstance(a, float) and (not math.isfinite(a) or not math.isfinite(b)):
        return False
    return a == b

def prompt_manifest_valid(root):
    """Each historical or regenerated manifest must describe its own exact bytes."""
    root = Path(root)
    try:
        entries = load(root/'prompt_manifest.json')
        names = [r['file'] for r in entries]
        expected = {p.relative_to(root).as_posix() for p in (root/'prompts').glob('*.json')}
        if len(names) != len(set(names)) or set(names) != expected:
            return False
        for row in entries:
            rel = PurePosixPath(row['file'])
            if rel.is_absolute() or '..' in rel.parts or len(rel.parts) != 2 or rel.parts[0] != 'prompts' or '\\' in row['file']:
                return False
            p = root/row['file']
            if hashlib.sha256(p.read_bytes()).hexdigest() != row['sha256']:
                return False
        return True
    except (KeyError, TypeError, ValueError, OSError):
        return False

def compare_prompt_tree(original, replay):
    a, b = Path(original), Path(replay)
    names_a = {p.relative_to(a).as_posix() for p in a.rglob('*.json')}
    names_b = {p.relative_to(b).as_posix() for p in b.rglob('*.json')}
    if names_a != names_b or not prompt_manifest_valid(a) or not prompt_manifest_valid(b):
        return False
    return all(compare_json(load(a/p), load(b/p)) for p in names_a if p != 'prompt_manifest.json')
