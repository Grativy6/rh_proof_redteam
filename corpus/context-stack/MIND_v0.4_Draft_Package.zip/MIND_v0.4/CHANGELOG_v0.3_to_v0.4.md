# MIND v0.4 — Changes from v0.3

The delivered v0.3 package remains unchanged. Version 0.4 is a source-grounded successor draft that retains Results 1–7, the question/fork and reorientation construction, the wake triad, the two boundaries, and the BLA interface.

| Area | v0.4 disposition |
|---|---|
| Identity and DOI | MIND name and subtitle retained. Author-supplied DOI 10.5281/zenodo.22882309 added; status is publication-candidate draft, not public-deposit confirmation. |
| Local meaning | Locality becomes explicit scope, not a gap requiring universal significance. Cross-context use retains conditions and reopening handles. |
| Reinforcement | Account influence remains distinct from evidential warrant; repeated use or copying does not create independent corroboration. |
| CHARTER | Adds [14] as a source for protected carriage, join checks, typed ambiguity, serviceability lifetime, and release sufficiency. No source framework is revised. |
| MIND adapter | Specifies paired protected queries, receiving-context applicability, and visible withheld joins; mapping selection remains supplied and contestable. |
| Example | Adds historical-sample reclassification, loss and ambiguity cases, independent queries, same-source repetition, and re-entry. |
| Formal results and checks | Results 1–7 unchanged. All 38 inherited assertions retained; twelve finite adapter assertions added. No empirical comparison is reported. |
| Obligations | Replaces the universal-meaning demand with local transfer validation; separates publication blockers from future research. |
| Source integrity | Uses the completed packaged Markdown, not the interrupted standalone copy; records the distinction and leaves both untouched. |
| Publication preparation | Adds a draft citation, posting description, and a concise preparation checklist; license and final deposit remain author decisions. |

