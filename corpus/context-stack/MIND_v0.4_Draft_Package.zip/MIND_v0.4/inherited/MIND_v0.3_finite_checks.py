#!/usr/bin/env python3
"""Finite illustrations for MIND v0.3 (Christopher D. Pang, 2026).

Uses only the Python standard library. This is not an agent benchmark,
consciousness test, PAL conformance suite, or proof of empirical benefit.
Run: python MIND_v0.3_finite_checks.py --output fresh_receipt.json
The script refuses to overwrite a receipt.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path
import platform
from typing import Hashable, Sequence


def kernel(values: Sequence[Hashable]) -> frozenset[tuple[int, int]]:
    return frozenset((i, j) for i in range(len(values))
                     for j in range(len(values)) if values[i] == values[j])


def paired(left: Sequence[Hashable], right: Sequence[Hashable]) -> tuple[Hashable, ...]:
    if len(left) != len(right):
        raise ValueError("Readouts must cover the same alternatives in the same order.")
    return tuple(zip(left, right))


def distinguished_pairs(values: Sequence[Hashable]) -> int:
    return sum(values[i] != values[j] for i, j in itertools.combinations(range(len(values)), 2))


def recoverable(code: Sequence[Hashable], answers: Sequence[Hashable]) -> bool:
    """Whether a decoder exists on the reachable code values for this finite fixture."""
    if len(code) != len(answers):
        raise ValueError("Code and query must cover the same domain.")
    return kernel(code).issubset(kernel(answers))


def verify() -> dict:
    initial = (0, 0, 0, 0)
    x = (0, 0, 1, 1)
    y = (0, 1, 0, 1)
    first = paired(initial, x)
    joint = paired(x, y)
    results: list[dict] = []

    def check(name: str, condition: bool, detail: object) -> None:
        if not condition:
            raise AssertionError(f"Finite check failed: {name}; detail={detail!r}")
        results.append({"name": name, "verdict": "PASS", "detail": detail})

    counts = [distinguished_pairs(v) for v in (initial, first, joint)]
    check("distinguished_unordered_pairs", counts == [0, 4, 6], counts)
    check("paired_readout_kernel", kernel(joint) == kernel(x) & kernel(y),
          "K(x,y) = K(x) intersect K(y)")
    check("retained_observation_refines", kernel(first).issubset(kernel(initial)),
          "The initial observation is retained.")
    check("repeat_idempotence", kernel(paired(joint, y)) == kernel(joint),
          "Repeating the same exact y adds no partition distinction.")
    renamed = tuple({(0, 0): "north", (0, 1): "east", (1, 0): "south", (1, 1): "west"}[p]
                    for p in joint)
    check("bijective_recoding", kernel(renamed) == kernel(joint),
          "Names change; the kernel does not.")
    check("y_only_cannot_recover_x", not recoverable(y, x),
          {"witness_pair": ["a", "c"], "same_y": 0, "different_x": [0, 1]})
    check("joint_recovers_both", recoverable(joint, x) and recoverable(joint, y),
          "Both component queries factor through the joint readout.")
    check("candidate_counts_for_a", [4, sum(v == 0 for v in x),
          sum(v == (0, 0) for v in joint)] == [4, 2, 1], [4, 2, 1])

    readouts = list(itertools.product(range(4), repeat=4))
    check("all_256_refinement_identities",
          all(kernel(paired(f, x)) == kernel(f) & kernel(x) for f in readouts),
          {"enumerated_readouts": len(readouts), "domain_size": 4, "codomain_size": 4})
    # The joint readout has four reachable values. Enumerate every map from
    # those values to a binary codomain; all 16 are valid closed postprocessings.
    postprocessings = list(itertools.product(range(2), repeat=4))
    check("all_16_postprocessing_inclusions",
          all(kernel(joint).issubset(kernel(c)) for c in postprocessings),
          {"enumerated_postprocessings": len(postprocessings)})
    # Additional nontrivial alias check: postprocess x, whose fibers contain pairs.
    binary_maps = list(itertools.product(range(2), repeat=2))
    check("aliased_input_postprocessing",
          all(kernel(x).issubset(kernel(tuple(c[v] for v in x))) for c in binary_maps),
          {"enumerated_binary_maps": len(binary_maps), "input": list(x)})

    # v0.2 fixture: the source class, result and recorded age are independent.
    # These are stipulated labels, not measured properties of a live system.
    histories = tuple(itertools.product(("observed", "simulated"),
                                        ("ready", "not_ready"),
                                        ("fresh", "stale")))
    source = tuple(h[0] for h in histories)
    content = tuple(h[1] for h in histories)
    age = tuple(h[2] for h in histories)
    all_answers = histories
    check("v02_eight_histories", len(histories) == 8, {"histories": histories})
    check("v02_content_query_preserved", recoverable(content, content),
          "The result can be recovered from result-only storage.")
    check("v02_source_and_age_not_recovered",
          not recoverable(content, source) and not recoverable(content, age),
          "Histories that agree on result can disagree on source and age.")
    repeated = tuple((v,) * 100 for v in content)
    check("v02_repetition_adds_no_distinction", kernel(repeated) == kernel(content),
          {"repetitions_per_value": 100, "reachable_values": len(set(repeated))})
    check("v02_tuple_recovers_three_queries",
          all(recoverable(histories, q) for q in (source, content, age)),
          "Every coordinate is available from the tuple.")
    recoded = tuple(range(len(histories)))
    check("v02_recoding_preserves_kernel", kernel(recoded) == kernel(histories),
          "A bijection of eight capsule values does not change exact preservation.")
    duplicate_query = tuple((*h, h[0]) for h in histories)
    check("v02_duplicate_question_does_not_inflate_capacity",
          kernel(duplicate_query) == kernel(histories)
          and len(set(duplicate_query)) == len(set(histories)),
          {"original_answer_classes": 8, "after_duplicate_query": 8})
    n = len(set(all_answers))
    check("v02_joint_answer_class_count", n == 8, {"N_P": n})
    required_bits = (n - 1).bit_length()
    check("v02_fixed_length_lower_bound", required_bits == 3
          and 2 ** (required_bits - 1) < n <= 2 ** required_bits,
          {"required_bits": required_bits, "basis": "finite pigeonhole bound"})
    codes = tuple(itertools.product(range(2), repeat=len(histories)))
    check("v02_all_256_binary_capsules_fail_joint_recovery",
          len(codes) == 256 and all(not recoverable(code, all_answers) for code in codes),
          {"encoders_enumerated": len(codes), "reachable_output_alphabet": 2})
    two_bit_example = tuple((h[0], h[1]) for h in histories)
    check("v02_two_bit_example_loses_age",
          len(set(two_bit_example)) == 4 and not recoverable(two_bit_example, age),
          "This specific four-value capsule omits the third coordinate.")
    check("v02_joint_factorization_matches_component_factorizations",
          all(recoverable(code, all_answers) ==
              all(recoverable(code, q) for q in (source, content, age))
              for code in (*codes, histories, recoded)),
          {"encoders_checked": len(codes) + 2})
    bad_decoder = tuple("observed" for _ in histories)
    check("v02_information_available_is_not_decoder_competence",
          recoverable(histories, source) and bad_decoder != source,
          "A sufficient capsule does not guarantee that the implemented decoder uses it.")
    extended = tuple((*h, z) for h in histories for z in (0, 1))
    old_capsule = tuple(h[:3] for h in extended)
    new_question = tuple(h[3] for h in extended)
    check("v02_new_question_can_break_old_sufficiency",
          all(recoverable(old_capsule, tuple(h[j] for h in extended)) for j in range(3))
          and not recoverable(old_capsule, new_question),
          {"extended_histories": 16, "new_protected_coordinate": 3})

    # Toy construction space; these labels are NOT bridge engineering advice.
    options = tuple(itertools.product(("A", "B"), ("short", "long"), ("light", "heavy")))
    prohibited = {("A", "long", "heavy")}
    actual_admitted = set(options) - prohibited
    broad_admitted = {o for o in options if o[0] != "A"}
    refined_admitted = {o for o in options if o not in prohibited}
    check("v02_more_precise_constraint_admits_more_arrangements",
          [len(broad_admitted), len(refined_admitted)] == [4, 7],
          {"broad": 4, "refined": 7})
    errors = [len(actual_admitted - broad_admitted),
              len(actual_admitted - refined_admitted)]
    check("v02_false_exclusions_decrease", errors == [3, 0],
          {"false_exclusions": errors})
    check("v02_actual_exclusion_still_preserved",
          not (refined_admitted & prohibited) and refined_admitted == actual_admitted,
          "The finer rule has not discarded the stipulated exclusion.")

    # Pure data/state fixture for the moving-world example. It takes no actions.
    purpose = "reach opposite bank"
    before = {"purpose": purpose, "epoch": 0, "route_state": "available"}
    after = {"purpose": purpose, "epoch": 1, "route_state": "unavailable"}
    candidate = {"id": "route-1", "basis_epoch": 0, "status": "excluded_under_basis"}
    consideration = {"kind": "consideration", "candidate_id": candidate["id"],
                     "before_epoch": 0, "after_epoch": 1}
    ledger = [consideration]
    check("v02_same_purpose_different_history",
          before != after and before["purpose"] == after["purpose"],
          {"before": before, "after": after})
    recheck_required = candidate["basis_epoch"] != after["epoch"]
    check("v02_environment_change_reopens_evaluation", recheck_required,
          "The old context epoch is not promoted to the current one.")
    check("v02_consideration_is_not_execution",
          any(x["kind"] == "consideration" for x in ledger)
          and not any(x["kind"] == "execution" for x in ledger),
          {"ledger": ledger})
    registry = {candidate["id"]: candidate}
    check("v02_excluded_candidate_remains_addressable",
          candidate["id"] in registry and registry[candidate["id"]]["status"] ==
          "excluded_under_basis",
          "Exclusion from the toy selection is not deletion from the account.")

    # v0.3: six bounded illustrations of the new conceptual distinctions.
    # These do not test a biological or deployed agent system.
    comparison_worlds = (("morning", "on"), ("evening", "on"), ("evening", "off"))
    framed_answers = tuple(w[1] == "on" for w in comparison_worlds)
    check("v03_question_fork_is_frame_relative",
          len(set(framed_answers)) == 2 and len(set(comparison_worlds)) == 3,
          {"world_states": comparison_worlds,
           "question": "Is the switch on?", "answer_classes": 2,
           "consequence": "Two answers partition this readout, not the complete states."})
    check("v03_exact_answer_does_not_identify_the_frame_or_world",
          framed_answers[0] == framed_answers[1] and comparison_worlds[0] != comparison_worlds[1],
          {"equal_answer": True, "different_time_contexts": ["morning", "evening"],
           "consequence": "An exact local answer does not identify the whole physical history."})
    items_before = frozenset(("route-A", "route-B"))
    old_orientation = {"route-A": "favored", "route-B": "retained_alternative"}
    new_orientation = {"route-A": "deferred", "route-B": "favored"}
    orientation_receipt = {"before": "orientation-0", "after": "orientation-1",
                           "basis": "stipulated change in comparison result"}
    check("v03_reorientation_without_item_creation",
          frozenset(old_orientation) == frozenset(new_orientation) == items_before
          and old_orientation != new_orientation
          and orientation_receipt["before"] != orientation_receipt["after"],
          {"before": old_orientation, "after": new_orientation, "receipt": orientation_receipt,
           "consequence": "Orientation can change while represented alternatives remain available."})
    def has_wake_roles(record: dict) -> bool:
        # Structural validation only: this predicate does not authenticate a source.
        return all(record.get(k) is not None for k in ("before", "relation", "after"))
    wake = {"before": "account-0", "relation": "comparison r1 changed orientation",
            "after": "account-1"}
    missing_roles = [{k: v for k, v in wake.items() if k != omitted} for omitted in wake]
    check("v03_wake_triad_has_three_logical_roles",
          has_wake_roles(wake) and all(not has_wake_roles(r) for r in missing_roles),
          {"record": wake, "missing_role_records_rejected": len(missing_roles),
           "consequence": "This tests the proposed record contract, not a universal minimality theorem."})
    def comparison_route(predicted: int, observed: int | None, tolerance: int,
                         *, observed_kind: str, route_relevant: bool) -> str:
        # Stipulated interval/tolerance comparator, not a statistical test.
        if observed is None or observed_kind != "observed":
            return "UNRESOLVED_COMPARISON"
        if not route_relevant or abs(predicted-observed) <= tolerance:
            return "NO_BOUNDARY_REPAIR_TRIGGER"
        return "OPEN_PROVISIONAL_LEDGER"
    outcomes = [comparison_route(10, 12, 1, observed_kind="observed", route_relevant=True),
                comparison_route(10, 11, 1, observed_kind="observed", route_relevant=True),
                comparison_route(10, 12, 1, observed_kind="simulated", route_relevant=True),
                comparison_route(10, None, 1, observed_kind="observed", route_relevant=True),
                comparison_route(10, 12, 1, observed_kind="observed", route_relevant=False)]
    check("v03_bla_trigger_preserves_source_and_comparison_boundary",
          outcomes == ["OPEN_PROVISIONAL_LEDGER", "NO_BOUNDARY_REPAIR_TRIGGER",
                       "UNRESOLVED_COMPARISON", "UNRESOLVED_COMPARISON",
                       "NO_BOUNDARY_REPAIR_TRIGGER"],
          {"outcomes": outcomes, "tolerance": 1,
           "consequence": "In this profile, only sourced, route-relevant mismatch beyond tolerance triggers repair."})
    def predicted_readout(candidate: str) -> int:
        return {"mechanism-A": 8, "mechanism-B": 8}[candidate]
    candidate_explanations = ("mechanism-A", "mechanism-B")
    matching = tuple(c for c in candidate_explanations if predicted_readout(c) == 8)
    check("v03_residual_does_not_select_its_explanation",
          len(matching) == 2 and matching[0] != matching[1],
          {"observation": 8, "candidate_matches": matching,
           "consequence": "A common fit leaves the competing mechanisms unresolved; no grant or law is minted."})

    script = Path(__file__).read_bytes()
    return {
        "artifact": "MIND v0.3 finite illustrative checks",
        "author": "Christopher D. Pang",
        "run_utc": datetime.now(timezone.utc).isoformat(),
        "python": platform.python_version(),
        "script_sha256": hashlib.sha256(script).hexdigest(),
        "predecessor_core": "All 32 v0.2 checks retained; six v0.3 fixture checks added",
        "fixture": {"alternatives": ["a", "b", "c", "d"],
                    "initial": list(initial), "x": list(x), "y": list(y)},
        "status": "PASS_IN_THE_STATED_FINITE_FIXTURES",
        "checks_passed": len(results),
        "checks": results,
        "limitations": [
            "Elementary finite set checks; not empirical validation of MIND.",
            "No agent, neural, biological, or quantum experiment was run.",
            "Constructed finite fixtures, not independent scientific corroboration.",
            "No empirical context-budget comparison was run.",
            "The bound is for exact fixed-length classical encoding, not intelligence.",
            "Runtime timestamp is the execution environment clock, not a trusted attestation.",
            "No claim of full PAL conformance or global research priority."
        ]
    }


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write a new JSON receipt; never overwrite.")
    args = parser.parse_args()
    receipt = verify()
    text = json.dumps(receipt, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        with args.output.open("x", encoding="utf-8") as handle:
            handle.write(text)
        print(f"{receipt['checks_passed']} finite checks passed; receipt: {args.output}")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
