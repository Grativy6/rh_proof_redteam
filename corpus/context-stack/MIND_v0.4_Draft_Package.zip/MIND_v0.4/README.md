# MIND v0.4
## Matrix of Information, Negation, and Distinction
*A trace-based framework for meaning, attention, and open-ended understanding*

Author: **Christopher D. Pang**  
Editorial date: **21 September 2026**  
Status: **Publication-candidate draft for final author review; not peer reviewed**  
Author-supplied DOI: **10.5281/zenodo.22882309**

This package does not confirm a public deposit or select a license. Earlier MIND editions, BLA, CHARTER and PAL remain unchanged.

## Read
- `MIND_v0.4_Draft.pdf`: 36-page reading edition, rendered from the delivered DOCX.
- `MIND_v0.4_Draft.docx`: editable manuscript with native equations and tables.
- `MIND_v0.4_Draft.md`: complete editable text source; keep the included figure beside it.
- `CHANGELOG_v0.3_to_v0.4.md`: the edition's change record.
- `OPEN_OBLIGATIONS.md`: declared scope, adapter status, remaining research and publication sufficiency.
- `PUBLICATION_NOTES.md` and `ZENODO_DESCRIPTION.md`: author-facing preparation notes and posting copy.

## What changed
Meaning remains local even when its use travels. Reinforcement is separated from independent evidence. A bounded CHARTER-based adapter distinguishes protected historical carriage from receiving-context applicability and from action authority. Unresolved joins remain visible instead of being silently dropped; independently answerable questions do not make an incomplete bundle complete.

The seven elementary results remain unchanged. Fifty named finite assertions passed: all 38 inherited checks and 12 locality/transfer fixtures. The empirical context-transfer pilot remains unrun. The adapter is not a deployed CHARTER implementation or a general semantic-equivalence solver.

## Reproduce the finite checks
Use Python 3.10 or later, standard library only, from this folder:

```sh
python MIND_v0.4_finite_checks.py --output MIND_v0.4_replay_receipt.json
```

Choose a new output path for each run; the command refuses to overwrite an existing receipt. `inherited/` contains the exact v0.3 companion and its original receipt. The v0.4 script pins its source hash and checks that all 38 inherited result records match before adding the new checks. A timestamp is execution-environment metadata, not trusted time attestation.

## Integrity and source selection
`SOURCE_PROVENANCE.json` records the exact predecessor and CHARTER source identities. The completed v0.3 ZIP Markdown, not an earlier interrupted standalone Markdown, supplied the text for this revision. Both originals remain unchanged. `MANIFEST.json` lists payload hashes and roles; `SHA256SUMS.txt` also includes the manifest. Hashes identify bytes, not truth or authorization.

The inherited fork/BLA schematic retains its original `MIND_v0.3_question_fork_bla.png` filename and bytes. Source documents are identified, not redistributed here. No fonts, working renders or temporary files are included.

AI assistance is disclosed in Appendix A. Christopher D. Pang remains the sole author and accountable publication steward.
