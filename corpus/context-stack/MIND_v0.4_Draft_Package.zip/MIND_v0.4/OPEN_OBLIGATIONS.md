# MIND v0.4 — Obligations and publication scope

Version 0.4 separates adopted scope commitments, draft definitions, source-based adapter proposals, and unperformed research. A clarified definition does not close its empirical or implementation burden. The dispositions below do not amend PAL, BLA, or CHARTER.

**Negation beyond ordinary update — REFINED / EMPIRICAL DISTINCTIVENESS OPEN.** Negation’s proposed role remains reorientation rather than adding a special object. Existing methods may realize the same function. Equivalent performance under matched source, retention, and resource conditions would support MIND as an organizing synthesis rather than a uniquely effective mechanism.

**Minimum wake — WORKING DEFINITION SUPPLIED.** The triad $(b,\Delta,a)$ supplies the three logical roles. Attribution, the comparison rule, and task-specific protected retrieval remain required. It is not a universal minimum of storage or a sufficient account of personal identity.

**Two boundaries — REFINED / REALIZATION OPEN.** Embodied coupling and event-like account admission remain different roles in one realized system. A realization must show what keeping them distinct explains or enables.

**Meaning across contexts — LOCALITY EXPLICIT / ADAPTER SPECIFIED / VALIDATION OPEN.** Local significance is the scope commitment, not a missing universal quantity. Section 8.7 specifies a first CHARTER-based adapter for protected carriage, receiving-context applicability, and unresolved joins. Particular mappings, protected-query selection, conflict judgments, and their usefulness still require realization-specific evidence. No context-free significance or universal semantic reconciliation is claimed.

**Recursive reinforcement — SOURCE SEPARATION EXPLICIT.** Repeated use can change an account without supplying another observation or independent corroboration. New warrant must have an identifiable basis. Reliable tracking of source dependence and costs in deployed systems remains open; the finite fixture only checks the declared record behavior.

**Improved understanding — REFINED / UNIVERSAL ORDER NOT CLAIMED.** A warranted, traceable reorientation that preserves unaffected distinctions is a candidate local criterion. A change from no to yes or yes to no is not sufficient by itself. Evaluation still needs declared questions and costs.

**Effective distinction capacity — ABSOLUTE SCALAR REJECTED / PROFILE COMPARISON OPEN.** Capacity remains relative to a supplied question family, aperture, decoder, and resource budget. The exact finite encoding results do not settle efficient use, approximate recovery, or fair cross-system comparison.

**Prospective exclusion and deliberation — REFINED / DOMAIN RULES OPEN.** A simulated consequence, proof, preference, and refusal remain different bases. A pause suspends commitment, not consequence. Applicability, freshness, stopping, fallback, and action authority must be supplied for the actual use; no universal deliberation interval is proposed.

**MIND–BLA interface — PROPOSED.** Prediction and sourced observation must share a comparison domain and uncertainty rule before a route-relevant residual motivates a provisional ledger. A ledger does not select its explanation. BLA v0.9.1 is not revised or designated v1.0 here.

**MIND–CHARTER interface — BOUNDED ADAPTER / FINITE FIXTURE ONLY.** Protected-query preservation, typed unsuccessful returns, and join obligations are source mechanisms. MIND’s mapping of its meaning-bearing items into those roles is the new proposal. The script is not the full CHARTER implementation, a formal conformance certificate, or a general conflict-resolution algorithm.

The draft should reopen when it confuses missing evidence with evidence of difference; promotes an answer outside its aperture; counts repetition as independent support; treats unknown substantive answers as exact preservation; silently discards a required conflict; reuses stale serviceability; erases historical interpretation; or claims an empirical benefit that disappears under matched resources. A proposed correction appends its basis rather than rewriting the earlier warrant.

## Publication sufficiency is not research finality

This edition is prepared as a **publication-candidate draft**, not an already deposited or independently reviewed release. The declared publication claim is a conceptual synthesis, seven bounded elementary results, and reproducible finite illustrations. Comparative cognitive benefit, deployed CHARTER behavior, universal meaning, and a substrate theory are not claims a reader must accept in order to inspect that contribution.

For that scope, inconsistent definitions, an unsupported source attribution, an incorrect stated result, a failing claimed fixture, or missing disclosure of a known material limitation would block presenting the affected claim as ready. Unperformed empirical studies and later refinements remain explicit research obligations rather than being concealed or used to require endless polishing. This distinction follows CHARTER’s release-sufficiency discussion without borrowing publication authority from it. [14, §15.5.2]

Final adoption of the manuscript, license selection, and deposit metadata belong to Christopher D. Pang. The author supplied DOI **10.5281/zenodo.22882309**; this package uses it as the intended publication identifier, not evidence that a deposit has occurred. The open-obligation and preparation notes accompany the manuscript so that a final publication decision can name its exact scope.

