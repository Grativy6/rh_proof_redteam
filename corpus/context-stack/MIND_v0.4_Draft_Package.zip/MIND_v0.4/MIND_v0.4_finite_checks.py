#!/usr/bin/env python3
"""Finite illustrations for MIND v0.4, Christopher D. Pang (2026).

Runs the unchanged v0.3 companion and twelve added locality/transfer assertions.
Python 3.10+; standard library only. This is neither an agent benchmark nor
CHARTER/PAL conformance. No external actions or network access are performed.
Use --output with a new path to write an execution receipt; never overwrite one.
"""
from __future__ import annotations
import argparse
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import importlib.util
import itertools
import json
from pathlib import Path
import platform
from typing import Any, Mapping, Sequence

INHERITED_SHA256 = "991a67d232a703164d9a1777d78f3cd8725692f2f49dbc9b57aee81b9b3d0e45"


def compare_field(source: Mapping[str, Any], target: Mapping[str, Any], key: str) -> str:
    """Exact query for this fixture. None/missing means no substantive answer.

    A recorded string 'unknown' may separately answer an uncertainty-status query;
    it does not answer a different query about the missing value or source.
    """
    left, right = source.get(key), target.get(key)
    if left is None or right is None:
        return "UNKNOWN"
    return "PRESERVED" if left == right else "MISMATCH"


def join_admitted(outcomes: Sequence[str], *, target_ready: bool,
                  mapping_current: bool, dependency_ready: bool = True) -> bool:
    """Stipulated all-required fixture gate; not execution authorization."""
    legal = {"PRESERVED", "MISMATCH", "UNKNOWN"}
    if not outcomes or any(o not in legal for o in outcomes):
        raise ValueError("Require a nonempty sequence of declared preservation outcomes.")
    return (all(o == "PRESERVED" for o in outcomes) and target_ready
            and mapping_current and dependency_ready)


def classification(value: int, bounds: tuple[int, int]) -> str:
    low, high = bounds
    if low > high:
        raise ValueError("Invalid interval")
    return "inside" if low <= value <= high else "outside"


def verify() -> dict[str, Any]:
    here = Path(__file__).resolve().parent
    inherited_path = here / "inherited/MIND_v0.3_finite_checks.py"
    if hashlib.sha256(inherited_path.read_bytes()).hexdigest() != INHERITED_SHA256:
        raise RuntimeError("Inherited companion differs from the pinned v0.3 source.")
    spec = importlib.util.spec_from_file_location("mind_v03_inherited", inherited_path)
    if spec is None or spec.loader is None:
        raise RuntimeError("Cannot load the inherited companion.")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    inherited = module.verify()
    reference = json.loads((here / "inherited/MIND_v0.3_finite_receipt.json").read_text())
    # JSON normalization handles tuples in runtime results vs arrays in stored JSON.
    normalized = json.loads(json.dumps(inherited["checks"], ensure_ascii=False))
    if normalized != reference["checks"] or inherited["checks_passed"] != 38:
        raise AssertionError("Inherited result records differ from the delivered v0.3 receipt.")
    results = list(inherited["checks"])

    def check(name: str, condition: bool, detail: Any) -> None:
        if not condition:
            raise AssertionError(f"Finite check failed: {name}; detail={detail!r}")
        results.append({"name": name, "verdict": "PASS", "detail": detail})

    original = {"value": 7, "source": "sensor-A", "epoch": 0,
                "rule": "lab-v1", "source_classification": "inside"}
    original_frozen = deepcopy(original)
    target = deepcopy(original)
    keys = ("value", "source", "epoch", "rule", "source_classification")
    outcomes = tuple(compare_field(original, target, k) for k in keys)
    check("v04_preservation_does_not_require_same_target_meaning",
          all(o == "PRESERVED" for o in outcomes)
          and classification(7, (4, 8)) == "inside"
          and classification(7, (4, 6)) == "outside"
          and join_admitted(outcomes, target_ready=True, mapping_current=True),
          {"source_rule": "lab-v1 [4,8]", "target_rule": "target-v2 [4,6]",
           "sample": 7, "source": "inside", "target": "outside",
           "scope": "reclassify a historical sample, not measure a fresh event"})

    missing = {k: v for k, v in target.items() if k != "source"}
    missing_outcomes = tuple(compare_field(original, missing, k) for k in keys)
    check("v04_missing_source_blocks_required_carriage",
          compare_field(original, missing, "source") == "UNKNOWN"
          and not join_admitted(missing_outcomes, target_ready=True, mapping_current=True),
          {"outcomes": missing_outcomes})

    changed = {**target, "value": 8}
    changed_outcomes = tuple(compare_field(original, changed, k) for k in keys)
    check("v04_changed_protected_value_is_mismatch",
          changed_outcomes[0] == "MISMATCH"
          and not join_admitted(changed_outcomes, target_ready=True, mapping_current=True),
          {"outcomes": changed_outcomes})

    check("v04_two_missing_values_do_not_establish_preservation",
          compare_field({"source": None}, {"source": None}, "source") == "UNKNOWN",
          "Neither carrier can answer the substantive source query.")
    status_source = {"source_status": "unknown", "source": None}
    status_target = deepcopy(status_source)
    check("v04_uncertainty_status_can_be_preserved_without_resolving_source",
          compare_field(status_source, status_target, "source_status") == "PRESERVED"
          and compare_field(status_source, status_target, "source") == "UNKNOWN",
          "The preserved status answers a different query from the missing source identity.")

    patterns = tuple(itertools.product(("PRESERVED", "MISMATCH", "UNKNOWN"), repeat=3))
    accepted = tuple(p for p in patterns if join_admitted(
        p, target_ready=True, mapping_current=True))
    check("v04_all_required_join_enumerates_27_patterns",
          len(patterns) == 27 and accepted == (("PRESERVED",) * 3,),
          {"patterns": 27, "admitted": 1, "withheld": 26})

    check("v04_unresolved_target_rule_blocks_classification_join",
          not join_admitted(outcomes, target_ready=False, mapping_current=True),
          {"target_candidates": ["target-v2 [4,6]", "target-v3 [4,8]"],
           "active_version": "unresolved", "historical_carriage": "preserved"})

    # Dependency declarations are fixed before evaluation, not inferred from failure.
    dependencies = {"historical_value": ("value",),
                    "target_classification": ("value", "active_target_rule")}
    available = {"value": True, "active_target_rule": False}
    query_ready = {q: all(available[k] for k in needs)
                   for q, needs in dependencies.items()}
    check("v04_independent_query_does_not_certify_blocked_bundle",
          query_ready["historical_value"] and not query_ready["target_classification"]
          and not all(query_ready.values()),
          {"dependencies": dependencies, "query_ready": query_ready,
           "bundle_complete": False})

    source_ids = {"observation-A"}
    uses = 0
    for _ in range(100):
        uses += 1
        source_ids.add("observation-A")
    check("v04_reinforcement_count_is_not_source_count",
          uses == 100 and len(source_ids) == 1,
          {"uses": uses, "source_dependencies": sorted(source_ids)})
    second_source = {"id": "report-B", "independence": "UNASSESSED",
                     "authenticity": "UNASSESSED"}
    source_ids.add(second_source["id"])
    check("v04_second_identifier_does_not_assess_independence",
          len(source_ids) == 2 and second_source["independence"] == "UNASSESSED"
          and second_source["authenticity"] == "UNASSESSED",
          {"source_dependencies": sorted(source_ids), "second_source": second_source})

    check("v04_mapping_generation_mismatch_blocks_required_join",
          not join_admitted(outcomes, target_ready=True, mapping_current=False),
          {"required_mapping_generation": "g2", "provided_generation": "g1"})

    evaluations = [{"id": "evaluation-0", "target_epoch": 0, "classification": "outside"}]
    first_evaluation = deepcopy(evaluations[0])
    current_epoch = 1
    stale = evaluations[0]["target_epoch"] != current_epoch
    held = not join_admitted(outcomes, target_ready=not stale, mapping_current=True)
    evaluations.append({"id": "evaluation-1", "target_epoch": 1,
                        "classification": "unresolved", "prior": "evaluation-0"})
    check("v04_stale_applicability_reopens_without_rewriting_history",
          stale and held and evaluations[0] == first_evaluation
          and original == original_frozen and len(evaluations) == 2,
          {"historical_record": original, "evaluations": evaluations,
           "old_evaluation_reused_as_current": False})

    if len(results) != 50:
        raise AssertionError(f"Expected 50 named results; got {len(results)}")
    return {"artifact": "MIND v0.4 finite illustrative checks",
            "author": "Christopher D. Pang", "version": "0.4",
            "run_utc": datetime.now(timezone.utc).isoformat(),
            "python": platform.python_version(),
            "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
            "inherited_script_sha256": INHERITED_SHA256,
            "inherited_result_records_match": True,
            "inherited_assertions": 38, "added_assertions": 12,
            "checks_passed": len(results), "status": "PASS_IN_STATED_FINITE_FIXTURES",
            "checks": results,
            "limitations": ["No cognitive comparison or context-budget pilot was run.",
                            "No complete PAL or CHARTER conformance claim.",
                            "Paired queries and dependency rules are stipulated, not automatically learned.",
                            "No general semantic equivalence or conflict-resolution theorem.",
                            "Source IDs and digests do not establish authenticity or independence.",
                            "Execution timestamp is not a trusted attestation."]}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output", type=Path, help="Write a new receipt, never overwrite.")
    args = parser.parse_args()
    if args.output and args.output.exists():
        parser.error("Output already exists; choose a new receipt path.")
    result = verify()
    text = json.dumps(result, indent=2, ensure_ascii=False) + "\n"
    if args.output:
        with args.output.open("x", encoding="utf-8") as f:
            f.write(text)
        print(f"{result['checks_passed']} finite assertions passed (38 inherited, 12 added).")
    else:
        print(text, end="")


if __name__ == "__main__":
    main()
